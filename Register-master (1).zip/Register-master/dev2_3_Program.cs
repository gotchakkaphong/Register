From: <Saved by Blink>
Snapshot-Content-Location: https://gist.github.com/cclough2/a707f54cbfa54fe833b47eb38ee00cac#file-dev2_3_program-cs
Subject: dev2_3_Program.cs
Date: Fri, 2 Nov 2018 13:19:30 -0000
MIME-Version: 1.0
Content-Type: multipart/related;
	type="text/html";
	boundary="----MultipartBoundary--kTQgBUfc6f4BLSFiT9rvMhqXUu6noRxQRXYfZgCqVt----"


------MultipartBoundary--kTQgBUfc6f4BLSFiT9rvMhqXUu6noRxQRXYfZgCqVt----
Content-Type: text/html
Content-ID: <frame-30A87880152FC9011697CDCB3717ED73@mhtml.blink>
Content-Transfer-Encoding: binary
Content-Location: https://gist.github.com/cclough2/a707f54cbfa54fe833b47eb38ee00cac#file-dev2_3_program-cs

<!DOCTYPE html><html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
  <link rel="dns-prefetch" href="https://assets-cdn.github.com/">
  <link rel="dns-prefetch" href="https://avatars0.githubusercontent.com/">
  <link rel="dns-prefetch" href="https://avatars1.githubusercontent.com/">
  <link rel="dns-prefetch" href="https://avatars2.githubusercontent.com/">
  <link rel="dns-prefetch" href="https://avatars3.githubusercontent.com/">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com/">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">



  <meta name="viewport" content="initial-scale=1.0,user-scalable=no,maximum-scale=1,width=device-width">
  <meta name="viewport" content="initial-scale=1.0,user-scalable=no,maximum-scale=1" media="(device-height: 568px)">
  <meta name="selected-link" value="/cclough2/a707f54cbfa54fe833b47eb38ee00cac">

  
<meta name="octolytics-dimension-device" content="mobile">



<meta name="octolytics-host" content="collector.githubapp.com"><meta name="octolytics-app-id" content="gist"><meta name="octolytics-event-url" content="https://collector.githubapp.com/github-external/browser_event"><meta name="octolytics-dimension-request_id" content="F5ED:199A:4089:5B57:5BDC4EE1"><meta name="octolytics-dimension-region_edge" content="ap-southeast-1"><meta name="octolytics-dimension-region_render" content="iad"><meta name="octolytics-actor-id" content="44693518"><meta name="octolytics-actor-login" content="gotchakkaphong"><meta name="octolytics-actor-hash" content="b7b8256cb76554010bb3a61b8c809ce48f4748d6906020ee7dad4d7ce02b7cd6">
<meta name="analytics-location" content="/<user-name>/<gist-id>" data-pjax-transient="true">



    <meta name="google-analytics" content="UA-3769691-4">

  <meta class="js-ga-set" name="userId" content="f1ca2a65fdaad35c0c19cf6bfdcb2ed2" %="">

<meta class="js-ga-set" name="dimension1" content="Logged In">

  <meta class="js-ga-set" name="dimension3" content="mobile">


    <meta name="octolytics-dimension-public" content="true"><meta name="octolytics-dimension-gist_id" content="92808638"><meta name="octolytics-dimension-gist_name" content="a707f54cbfa54fe833b47eb38ee00cac"><meta name="octolytics-dimension-anonymous" content="false"><meta name="octolytics-dimension-owner_id" content="2905849"><meta name="octolytics-dimension-owner_login" content="cclough2"><meta name="octolytics-dimension-forked" content="false">

  <meta class="js-ga-set" name="dimension5" content="public">
  <meta class="js-ga-set" name="dimension6" content="owned">


  <title>dev2_3_Program.cs</title>

  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://assets-cdn.github.com/assets/mobile-12ee12914455b324ccd998f066240022.css">


  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <link rel="mask-icon" href="https://assets-cdn.github.com/pinned-octocat.svg" color="#000000">
  <link rel="icon" type="image/x-icon" class="js-site-favicon" href="https://assets-cdn.github.com/favicon.ico">

<meta name="theme-color" content="#1e2327">




  </head>

  <body class="page-responsive">
    


  <header class="Header f5 lh-default clearfix">
    <div class="p-responsive flex-justify-between">
        <div class="d-flex flex-justify-between flex-items-center position-absolute right-0 left-0 px-3 mt-1">
          <div class="d-flex mx-2"><!-- placeholder for hamburger --></div>
          <div class="px-3 overflow-hidden">
                <div class="css-truncate css-truncate-target width-fit py-1">
    <strong><a class="url fn text-white" rel="author" href="https://gist.github.com/cclough2"><span itemprop="author">cclough2</span></a></strong>
    /
    <strong><a class="text-white" href="https://gist.github.com/cclough2/a707f54cbfa54fe833b47eb38ee00cac">dev2_3_Program.cs</a></strong>
  </div>

          </div>

          <div class="d-flex">
            
          </div>
        </div>


        <details class="details-reset">
          <summary class="mt-1 float-left position-relative user-select-none" data-ga-click="Mobile, tap, location:header; text:Hamburger">
            <svg height="24" class="octicon octicon-three-bars notification-indicator" viewBox="0 0 12 16" version="1.1" width="18" aria-hidden="true"><path fill-rule="evenodd" d="M11.41 9H.59C0 9 0 8.59 0 8c0-.59 0-1 .59-1H11.4c.59 0 .59.41.59 1 0 .59 0 1-.59 1h.01zm0-4H.59C0 5 0 4.59 0 4c0-.59 0-1 .59-1H11.4c.59 0 .59.41.59 1 0 .59 0 1-.59 1h.01zM.59 11H11.4c.59 0 .59.41.59 1 0 .59 0 1-.59 1H.59C0 13 0 12.59 0 12c0-.59 0-1 .59-1z"></path></svg>
          </summary>
              <div style="clear: both;">
      <ul class="text-bold list-style-none p-0 m-0">
            <li>
              <a href="https://gist.github.com/gotchakkaphong" class="js-selected-navigation-item HeaderNavlink py-2 mt-3">
                <img class="avatar avatar-small" src="https://avatars1.githubusercontent.com/u/44693518?s=40&amp;v=4" width="20" height="20" alt="@gotchakkaphong">
                gotchakkaphong
              </a>
            </li>
            <li>
              <!-- '"` --><!-- </textarea></xmp> --><form class="" action="https://gist.github.com/auth/github/logout" accept-charset="UTF-8" method="post">
                <button type="submit" data-ga-click="Mobile, tap, location:header; text:Sign out" class="HeaderNavlink py-2 d-block width-full text-left" style="padding-left: 2px;">
                  <svg style="margin-right: 2px;" class="octicon octicon-sign-out v-align-middle" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M11.992 8.994V6.996H7.995v-2h3.997V2.999l3.998 2.998-3.998 2.998zm-1.998 2.998H5.996V2.998L2 1h7.995v2.998h1V1c0-.55-.45-.999-1-.999H.999A1.001 1.001 0 0 0 0 1v11.372c0 .39.22.73.55.91L5.996 16v-3.008h3.998c.55 0 1-.45 1-1V7.995h-1v3.997z"></path></svg>
                  Sign out
                </button>
</form>            </li>
      </ul>
    </div>

        </details>
    </div>
  </header>

    


    <div id="js-flash-container">


</div>


      



  <div class="gist-mobile-blob blob-file-content js-file-line-container" id="file-dev2_3_program-cs">
    <div class="breadcrumb blob-breadcrumb">
      <span class="filetype-icon"><svg class="octicon octicon-file" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M6 5H2V4h4v1zM2 8h7V7H2v1zm0 2h7V9H2v1zm0 2h7v-1H2v1zm10-7.5V14c0 .55-.45 1-1 1H1c-.55 0-1-.45-1-1V2c0-.55.45-1 1-1h7.5L12 4.5zM11 5L8 2H1v12h10V5z"></path></svg></span>
      <a aria-label="Permalink" href="https://gist.github.com/cclough2/a707f54cbfa54fe833b47eb38ee00cac#file-dev2_3_program-cs">dev2_3_Program.cs</a>
    </div>

    <div class="highlighted-blob tab-size" data-tab-size="8"><div class="code-body highlight"><pre><div class="line js-file-line" id="LC1"><span class="pl-k">using</span> <span class="pl-en">System</span>;</div><div class="line js-file-line" id="LC2"><span class="pl-k">using</span> <span class="pl-en">System</span>.<span class="pl-en">Text</span>;</div><div class="line js-file-line" id="LC3"><span class="pl-k">using</span> <span class="pl-en">System</span>.<span class="pl-en">Collections</span>.<span class="pl-en">Generic</span>;</div><div class="line js-file-line" id="LC4"><span class="pl-k">using</span> <span class="pl-en">System</span>.<span class="pl-en">Net</span>.<span class="pl-en">Http</span>;</div><div class="line js-file-line" id="LC5"><br></div><div class="line js-file-line" id="LC6"><span class="pl-k">using</span> <span class="pl-en">MySql</span>.<span class="pl-en">Data</span>.<span class="pl-en">MySqlClient</span>;</div><div class="line js-file-line" id="LC7"><span class="pl-k">using</span> <span class="pl-en">Newtonsoft</span>.<span class="pl-en">Json</span>;</div><div class="line js-file-line" id="LC8"><br></div><div class="line js-file-line" id="LC9"><span class="pl-k">namespace</span> <span class="pl-en">dresser</span></div><div class="line js-file-line" id="LC10">{</div><div class="line js-file-line" id="LC11">&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-k">enum</span> <span class="pl-en">Season</span> {</div><div class="line js-file-line" id="LC12">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-en">Winter</span>,</div><div class="line js-file-line" id="LC13">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-en">Spring_Fall</span>,</div><div class="line js-file-line" id="LC14">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-en">Summer</span></div><div class="line js-file-line" id="LC15">&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC16"><br></div><div class="line js-file-line" id="LC17">&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-k">class</span> <span class="pl-en">Clothing</span> {</div><div class="line js-file-line" id="LC18">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-en">String</span> <span class="pl-smi">Id</span> { <span class="pl-k">get</span>; <span class="pl-k">set</span>; }</div><div class="line js-file-line" id="LC19">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-en">String</span> <span class="pl-smi">Description</span> { <span class="pl-k">get</span>; <span class="pl-k">set</span>; }</div><div class="line js-file-line" id="LC20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-en">String</span> <span class="pl-smi">Type</span> { <span class="pl-k">get</span>; <span class="pl-k">set</span>; }</div><div class="line js-file-line" id="LC21">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-en">String</span> <span class="pl-smi">Color</span> { <span class="pl-k">get</span>; <span class="pl-k">set</span>; }</div><div class="line js-file-line" id="LC22">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-en">Season</span> <span class="pl-smi">Season</span> { <span class="pl-k">get</span>; <span class="pl-k">set</span>; }</div><div class="line js-file-line" id="LC23">&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC24"><br></div><div class="line js-file-line" id="LC25">&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-k">interface</span> <span class="pl-en">ITempRetriver</span> {</div><div class="line js-file-line" id="LC26">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">double</span>[] <span class="pl-en">GetFiveDayTempForecast</span>();</div><div class="line js-file-line" id="LC27">&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC28"><br></div><div class="line js-file-line" id="LC29">&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-k">interface</span> <span class="pl-en">IClothRetriver</span> {</div><div class="line js-file-line" id="LC30">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-en">Clothing</span> <span class="pl-en">GetRandomClothing</span>(<span class="pl-k">bool</span> <span class="pl-smi">isTop</span>, <span class="pl-en">Season</span> <span class="pl-smi">season</span>);</div><div class="line js-file-line" id="LC31">&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC32"><br></div><div class="line js-file-line" id="LC33">&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-k">class</span> <span class="pl-en">WeatherApiTempRetriever</span> : <span class="pl-en">ITempRetriver</span> {</div><div class="line js-file-line" id="LC34">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-en">String</span> <span class="pl-smi">endpointUrl</span>;</div><div class="line js-file-line" id="LC35"><br></div><div class="line js-file-line" id="LC36">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-en">WeatherApiTempRetriever</span>(<span class="pl-en">String</span> <span class="pl-smi">endpointUrl</span>) {</div><div class="line js-file-line" id="LC37">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">this</span>.<span class="pl-smi">endpointUrl</span> <span class="pl-k">=</span> <span class="pl-smi">endpointUrl</span>;</div><div class="line js-file-line" id="LC38">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC39"><br></div><div class="line js-file-line" id="LC40">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-k">double</span>[] <span class="pl-en">GetFiveDayTempForecast</span>() {</div><div class="line js-file-line" id="LC41">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">double</span>[] <span class="pl-smi">fiveDayTemps</span> <span class="pl-k">=</span> <span class="pl-k">new</span> <span class="pl-k">double</span>[<span class="pl-c1">5</span>];</div><div class="line js-file-line" id="LC42"><br></div><div class="line js-file-line" id="LC43">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-en">HttpClient</span> <span class="pl-smi">client</span> <span class="pl-k">=</span> <span class="pl-k">new</span> <span class="pl-en">HttpClient</span>();</div><div class="line js-file-line" id="LC44">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-en">String</span> <span class="pl-smi">response</span> <span class="pl-k">=</span> <span class="pl-smi">client</span>.<span class="pl-en">GetStringAsync</span>(<span class="pl-smi">endpointUrl</span>).<span class="pl-smi">Result</span>;</div><div class="line js-file-line" id="LC45"><br></div><div class="line js-file-line" id="LC46">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">dynamic</span> <span class="pl-smi">jsonObject</span> <span class="pl-k">=</span> <span class="pl-smi">JsonConvert</span>.<span class="pl-en">DeserializeObject</span>(<span class="pl-smi">response</span>);</div><div class="line js-file-line" id="LC47"><br></div><div class="line js-file-line" id="LC48">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-en">DateTime</span> <span class="pl-smi">currentDayCursor</span> <span class="pl-k">=</span> <span class="pl-smi">DateTime</span>.<span class="pl-smi">Now</span>;</div><div class="line js-file-line" id="LC49">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">int</span> <span class="pl-smi">index</span> <span class="pl-k">=</span> <span class="pl-c1">0</span>;</div><div class="line js-file-line" id="LC50">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="line js-file-line" id="LC51">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">foreach</span>(<span class="pl-k">dynamic</span> <span class="pl-smi">forcastJson</span> <span class="pl-k">in</span> <span class="pl-smi">jsonObject</span>.<span class="pl-smi">list</span>) {</div><div class="line js-file-line" id="LC52"><br></div><div class="line js-file-line" id="LC53">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-en">DateTime</span> <span class="pl-smi">forcastTime</span> <span class="pl-k">=</span> <span class="pl-smi">DateTimeOffset</span>.<span class="pl-en">FromUnixTimeSeconds</span>((<span class="pl-k">long</span>)<span class="pl-smi">forcastJson</span>.<span class="pl-smi">dt</span>).<span class="pl-smi">Date</span>;</div><div class="line js-file-line" id="LC54">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">int</span> <span class="pl-smi">temp</span> <span class="pl-k">=</span> <span class="pl-smi">forcastJson</span>.<span class="pl-smi">main</span>.<span class="pl-smi">temp</span>;</div><div class="line js-file-line" id="LC55"><br></div><div class="line js-file-line" id="LC56">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">if</span>(<span class="pl-smi">currentDayCursor</span> <span class="pl-k">&lt;=</span> <span class="pl-smi">forcastTime</span>) {</div><div class="line js-file-line" id="LC57">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">currentDayCursor</span> <span class="pl-k">=</span> <span class="pl-smi">currentDayCursor</span>.<span class="pl-en">AddDays</span>(<span class="pl-c1">1</span>);</div><div class="line js-file-line" id="LC58">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">fiveDayTemps</span>[<span class="pl-smi">index</span><span class="pl-k">++</span>] <span class="pl-k">=</span> <span class="pl-smi">temp</span>;</div><div class="line js-file-line" id="LC59">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">if</span>(<span class="pl-smi">index</span> <span class="pl-k">&gt;</span> <span class="pl-c1">4</span>) { <span class="pl-k">break</span>; }</div><div class="line js-file-line" id="LC60">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC61"><br></div><div class="line js-file-line" id="LC62">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC63"><br></div><div class="line js-file-line" id="LC64">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">return</span> <span class="pl-smi">fiveDayTemps</span>;</div><div class="line js-file-line" id="LC65">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC66">&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC67"><br></div><div class="line js-file-line" id="LC68">&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-k">class</span> <span class="pl-en">MySqlWardrobeDBRetriever</span> : <span class="pl-en">IClothRetriver</span> {</div><div class="line js-file-line" id="LC69">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-en">String</span> <span class="pl-smi">connectionString</span>;</div><div class="line js-file-line" id="LC70"><br></div><div class="line js-file-line" id="LC71">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-en">MySqlWardrobeDBRetriever</span>(<span class="pl-en">String</span> <span class="pl-smi">connectionString</span>) {</div><div class="line js-file-line" id="LC72">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">this</span>.<span class="pl-smi">connectionString</span> <span class="pl-k">=</span> <span class="pl-smi">connectionString</span>;</div><div class="line js-file-line" id="LC73">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC74"><br></div><div class="line js-file-line" id="LC75">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-en">Clothing</span> <span class="pl-en">GetRandomClothing</span>(<span class="pl-k">bool</span> <span class="pl-smi">isTop</span>, <span class="pl-en">Season</span> <span class="pl-smi">season</span>) {</div><div class="line js-file-line" id="LC76">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-en">Clothing</span> <span class="pl-smi">clothing</span> <span class="pl-k">=</span> <span class="pl-c1">null</span>;</div><div class="line js-file-line" id="LC77"><br></div><div class="line js-file-line" id="LC78">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">using</span> (<span class="pl-en">MySqlConnection</span> <span class="pl-smi">conn</span> <span class="pl-k">=</span> <span class="pl-k">new</span> <span class="pl-en">MySqlConnection</span>(<span class="pl-smi">connectionString</span>))</div><div class="line js-file-line" id="LC79">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{  </div><div class="line js-file-line" id="LC80">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">conn</span>.<span class="pl-en">Open</span>();  </div><div class="line js-file-line" id="LC81">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-en">MySqlCommand</span> <span class="pl-smi">cmd</span> <span class="pl-k">=</span> <span class="pl-k">new</span> <span class="pl-en">MySqlCommand</span>(<span class="pl-s"><span class="pl-pds">"</span>select id, description, type, color, season from <span class="pl-pds">"</span></span> <span class="pl-k">+</span> </div><div class="line js-file-line" id="LC82">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-s"><span class="pl-pds">"</span>WARDROBE where type = '<span class="pl-pds">"</span></span> <span class="pl-k">+</span> (<span class="pl-smi">isTop</span> <span class="pl-k">?</span> <span class="pl-s"><span class="pl-pds">"</span>top<span class="pl-pds">"</span></span> <span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">"</span>bottom<span class="pl-pds">"</span></span>) <span class="pl-k">+</span> </div><div class="line js-file-line" id="LC83">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-s"><span class="pl-pds">"</span>' and season = '<span class="pl-pds">"</span></span> <span class="pl-k">+</span> <span class="pl-en">ToSeasonString</span>(<span class="pl-smi">season</span>) <span class="pl-k">+</span> <span class="pl-s"><span class="pl-pds">"</span>' order by rand() limit 1<span class="pl-pds">"</span></span>, <span class="pl-smi">conn</span>);</div><div class="line js-file-line" id="LC84"><br></div><div class="line js-file-line" id="LC85">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">using</span> (<span class="pl-k">var</span> <span class="pl-smi">reader</span> <span class="pl-k">=</span> <span class="pl-smi">cmd</span>.<span class="pl-en">ExecuteReader</span>())  </div><div class="line js-file-line" id="LC86">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{  </div><div class="line js-file-line" id="LC87">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">if</span> (<span class="pl-smi">reader</span>.<span class="pl-en">Read</span>())  </div><div class="line js-file-line" id="LC88">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{  </div><div class="line js-file-line" id="LC89">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">clothing</span> <span class="pl-k">=</span> <span class="pl-k">new</span> <span class="pl-en">Clothing</span>() {</div><div class="line js-file-line" id="LC90">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">Id</span> <span class="pl-k">=</span> <span class="pl-smi">reader</span>.<span class="pl-en">GetString</span>(<span class="pl-s"><span class="pl-pds">"</span>id<span class="pl-pds">"</span></span>),</div><div class="line js-file-line" id="LC91">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">Description</span> <span class="pl-k">=</span> <span class="pl-smi">reader</span>.<span class="pl-en">GetString</span>(<span class="pl-s"><span class="pl-pds">"</span>description<span class="pl-pds">"</span></span>),</div><div class="line js-file-line" id="LC92">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">Type</span> <span class="pl-k">=</span> <span class="pl-smi">reader</span>.<span class="pl-en">GetString</span>(<span class="pl-s"><span class="pl-pds">"</span>type<span class="pl-pds">"</span></span>),</div><div class="line js-file-line" id="LC93">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">Color</span> <span class="pl-k">=</span> <span class="pl-smi">reader</span>.<span class="pl-en">GetString</span>(<span class="pl-s"><span class="pl-pds">"</span>color<span class="pl-pds">"</span></span>),</div><div class="line js-file-line" id="LC94">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">Season</span> <span class="pl-k">=</span> <span class="pl-en">ToSeasonEnum</span>(<span class="pl-smi">reader</span>.<span class="pl-en">GetString</span>(<span class="pl-s"><span class="pl-pds">"</span>season<span class="pl-pds">"</span></span>))</div><div class="line js-file-line" id="LC95">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;};</div><div class="line js-file-line" id="LC96">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC97">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC98">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC99"><br></div><div class="line js-file-line" id="LC100">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">return</span> <span class="pl-smi">clothing</span>;</div><div class="line js-file-line" id="LC101">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC102"><br></div><div class="line js-file-line" id="LC103">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">private</span> <span class="pl-k">string</span> <span class="pl-en">ToSeasonString</span>(<span class="pl-en">Season</span> <span class="pl-smi">season</span>) {</div><div class="line js-file-line" id="LC104">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">switch</span>(<span class="pl-smi">season</span>) {</div><div class="line js-file-line" id="LC105">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">case</span> <span class="pl-smi">Season</span>.<span class="pl-smi">Winter</span>:</div><div class="line js-file-line" id="LC106">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">return</span> <span class="pl-s"><span class="pl-pds">"</span>winter<span class="pl-pds">"</span></span>;</div><div class="line js-file-line" id="LC107">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">case</span> <span class="pl-smi">Season</span>.<span class="pl-smi">Summer</span>:</div><div class="line js-file-line" id="LC108">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">return</span> <span class="pl-s"><span class="pl-pds">"</span>summer<span class="pl-pds">"</span></span>;</div><div class="line js-file-line" id="LC109">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">default</span>:</div><div class="line js-file-line" id="LC110">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">return</span> <span class="pl-s"><span class="pl-pds">"</span>spring/fall<span class="pl-pds">"</span></span>;</div><div class="line js-file-line" id="LC111">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC112">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC113"><br></div><div class="line js-file-line" id="LC114">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">private</span> <span class="pl-en">Season</span> <span class="pl-en">ToSeasonEnum</span>(<span class="pl-en">String</span> <span class="pl-smi">seasonString</span>) {</div><div class="line js-file-line" id="LC115">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">switch</span> (<span class="pl-smi">seasonString</span>)</div><div class="line js-file-line" id="LC116">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</div><div class="line js-file-line" id="LC117">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">case</span> <span class="pl-s"><span class="pl-pds">"</span>winter<span class="pl-pds">"</span></span>:</div><div class="line js-file-line" id="LC118">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">return</span> <span class="pl-smi">Season</span>.<span class="pl-smi">Winter</span>;</div><div class="line js-file-line" id="LC119">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">case</span> <span class="pl-s"><span class="pl-pds">"</span>summer<span class="pl-pds">"</span></span>:</div><div class="line js-file-line" id="LC120">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">return</span> <span class="pl-smi">Season</span>.<span class="pl-smi">Summer</span>;</div><div class="line js-file-line" id="LC121">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">default</span>:</div><div class="line js-file-line" id="LC122">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">return</span> <span class="pl-smi">Season</span>.<span class="pl-smi">Spring_Fall</span>;</div><div class="line js-file-line" id="LC123">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC124">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC125">&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC126"><br></div><div class="line js-file-line" id="LC127">&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-k">class</span> <span class="pl-en">DressPicker</span> {</div><div class="line js-file-line" id="LC128">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-en">ITempRetriver</span> <span class="pl-smi">tempRetriever</span>;</div><div class="line js-file-line" id="LC129">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-en">IClothRetriver</span> <span class="pl-smi">clothRetriever</span>;</div><div class="line js-file-line" id="LC130"><br></div><div class="line js-file-line" id="LC131">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-en">DressPicker</span>(<span class="pl-en">ITempRetriver</span> <span class="pl-smi">tempRetriever</span>, <span class="pl-en">IClothRetriver</span> <span class="pl-smi">clothRetriever</span>) {</div><div class="line js-file-line" id="LC132">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">this</span>.<span class="pl-smi">tempRetriever</span> <span class="pl-k">=</span> <span class="pl-smi">tempRetriever</span>;</div><div class="line js-file-line" id="LC133">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">this</span>.<span class="pl-smi">clothRetriever</span> <span class="pl-k">=</span> <span class="pl-smi">clothRetriever</span>;</div><div class="line js-file-line" id="LC134">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC135">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="line js-file-line" id="LC136">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">public</span> <span class="pl-k">string</span> <span class="pl-en">Pick</span>() {</div><div class="line js-file-line" id="LC137">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-en">StringBuilder</span> <span class="pl-smi">output</span> <span class="pl-k">=</span> <span class="pl-k">new</span> <span class="pl-en">StringBuilder</span>();</div><div class="line js-file-line" id="LC138"><br></div><div class="line js-file-line" id="LC139">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">var</span> <span class="pl-smi">temps</span> <span class="pl-k">=</span> <span class="pl-smi">tempRetriever</span>.<span class="pl-en">GetFiveDayTempForecast</span>();</div><div class="line js-file-line" id="LC140"><br></div><div class="line js-file-line" id="LC141">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">foreach</span>(<span class="pl-k">double</span> <span class="pl-smi">temp</span> <span class="pl-k">in</span> <span class="pl-smi">temps</span>) {</div><div class="line js-file-line" id="LC142">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">output</span>.<span class="pl-en">Append</span>(<span class="pl-smi">String</span>.<span class="pl-en">Format</span>(<span class="pl-s"><span class="pl-pds">"</span>{0:0.#}F - <span class="pl-pds">"</span></span>, <span class="pl-smi">temp</span>));</div><div class="line js-file-line" id="LC143"><br></div><div class="line js-file-line" id="LC144">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">if</span>(<span class="pl-smi">temp</span> <span class="pl-k">&lt;=</span> <span class="pl-c1">40.0f</span>) {</div><div class="line js-file-line" id="LC145">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">output</span>.<span class="pl-en">Append</span>(<span class="pl-smi">clothRetriever</span>.<span class="pl-en">GetRandomClothing</span>(<span class="pl-c1">true</span>, <span class="pl-smi">Season</span>.<span class="pl-smi">Winter</span>).<span class="pl-smi">Description</span>);</div><div class="line js-file-line" id="LC146">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">output</span>.<span class="pl-en">Append</span>(<span class="pl-s"><span class="pl-pds">"</span>/<span class="pl-pds">"</span></span>);</div><div class="line js-file-line" id="LC147">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">output</span>.<span class="pl-en">AppendLine</span>(<span class="pl-smi">clothRetriever</span>.<span class="pl-en">GetRandomClothing</span>(<span class="pl-c1">false</span>, <span class="pl-smi">Season</span>.<span class="pl-smi">Winter</span>).<span class="pl-smi">Description</span>);</div><div class="line js-file-line" id="LC148">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;} <span class="pl-k">else</span> <span class="pl-k">if</span>(<span class="pl-smi">temp</span> <span class="pl-k">&lt;=</span> <span class="pl-c1">67.0f</span>) {</div><div class="line js-file-line" id="LC149">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">output</span>.<span class="pl-en">Append</span>(<span class="pl-smi">clothRetriever</span>.<span class="pl-en">GetRandomClothing</span>(<span class="pl-c1">true</span>, <span class="pl-smi">Season</span>.<span class="pl-smi">Spring_Fall</span>).<span class="pl-smi">Description</span>);</div><div class="line js-file-line" id="LC150">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">output</span>.<span class="pl-en">Append</span>(<span class="pl-s"><span class="pl-pds">"</span>/<span class="pl-pds">"</span></span>);</div><div class="line js-file-line" id="LC151">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">output</span>.<span class="pl-en">AppendLine</span>(<span class="pl-smi">clothRetriever</span>.<span class="pl-en">GetRandomClothing</span>(<span class="pl-c1">false</span>, <span class="pl-smi">Season</span>.<span class="pl-smi">Spring_Fall</span>).<span class="pl-smi">Description</span>);</div><div class="line js-file-line" id="LC152">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;} <span class="pl-k">else</span> {</div><div class="line js-file-line" id="LC153">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">output</span>.<span class="pl-en">Append</span>(<span class="pl-smi">clothRetriever</span>.<span class="pl-en">GetRandomClothing</span>(<span class="pl-c1">true</span>, <span class="pl-smi">Season</span>.<span class="pl-smi">Summer</span>).<span class="pl-smi">Description</span>);</div><div class="line js-file-line" id="LC154">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">output</span>.<span class="pl-en">Append</span>(<span class="pl-s"><span class="pl-pds">"</span>/<span class="pl-pds">"</span></span>);</div><div class="line js-file-line" id="LC155">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">output</span>.<span class="pl-en">AppendLine</span>(<span class="pl-smi">clothRetriever</span>.<span class="pl-en">GetRandomClothing</span>(<span class="pl-c1">false</span>, <span class="pl-smi">Season</span>.<span class="pl-smi">Summer</span>).<span class="pl-smi">Description</span>);</div><div class="line js-file-line" id="LC156">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC157">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC158"><br></div><div class="line js-file-line" id="LC159">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">return</span> <span class="pl-smi">output</span>.<span class="pl-en">ToString</span>();</div><div class="line js-file-line" id="LC160">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC161">&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC162"><br></div><div class="line js-file-line" id="LC163">&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">class</span> <span class="pl-en">Program</span></div><div class="line js-file-line" id="LC164">&nbsp;&nbsp;&nbsp;&nbsp;{</div><div class="line js-file-line" id="LC165">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">static</span> <span class="pl-en">String</span> <span class="pl-smi">connectionString</span> <span class="pl-k">=</span> <span class="pl-s"><span class="pl-pds">"</span>Server=localhost;Database=wardrobe;Uid=wardrobe_user;Pwd=password;<span class="pl-pds">"</span></span>;</div><div class="line js-file-line" id="LC166">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">static</span> <span class="pl-en">String</span> <span class="pl-smi">weatherApiEndpoint</span> <span class="pl-k">=</span> <span class="pl-s"><span class="pl-pds">"</span>https://api.openweathermap.org/data/2.5/forecast?zip=02210&amp;units=imperial&amp;appid=d2dbdf07d935480877804756c57fdadf<span class="pl-pds">"</span></span>;</div><div class="line js-file-line" id="LC167"><br></div><div class="line js-file-line" id="LC168">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">Main</span>(<span class="pl-k">string</span>[] <span class="pl-smi">args</span>)</div><div class="line js-file-line" id="LC169">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</div><div class="line js-file-line" id="LC170">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-en">DressPicker</span> <span class="pl-smi">dressPicker</span> <span class="pl-k">=</span> <span class="pl-k">new</span> <span class="pl-en">DressPicker</span>(</div><div class="line js-file-line" id="LC171">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">new</span> <span class="pl-en">WeatherApiTempRetriever</span>(<span class="pl-smi">weatherApiEndpoint</span>), </div><div class="line js-file-line" id="LC172">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-k">new</span> <span class="pl-en">MySqlWardrobeDBRetriever</span>(<span class="pl-smi">connectionString</span>));</div><div class="line js-file-line" id="LC173">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="line js-file-line" id="LC174">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="pl-smi">Console</span>.<span class="pl-en">Write</span>(<span class="pl-smi">dressPicker</span>.<span class="pl-en">Pick</span>());</div><div class="line js-file-line" id="LC175">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC176"><br></div><div class="line js-file-line" id="LC177">&nbsp;&nbsp;&nbsp;&nbsp;}</div><div class="line js-file-line" id="LC178">}</div></pre></div></div>
</div>






<div class="discussion-block-header">
  Comment on gist
</div>
<div class="discussion-reply-container">
      <!-- '"` --><!-- </textarea></xmp> --><form action="https://gist.github.com/cclough2/a707f54cbfa54fe833b47eb38ee00cac/comments" accept-charset="UTF-8" method="post">
        <div class="discussion-reply">
          <textarea class="form-control input-block js-comment-and-field" name="comment[body]" placeholder="Leave a comment" rows="5"></textarea>

          <div class="button-container">
            <button type="submit" class="btn btn-primary" data-disable-with="Commenting…">Comment</button>
          </div>
        </div>
</form></div>




  <footer class="clearfix">
    <div class="container">
      <a href="https://gist.github.com/cclough2/a707f54cbfa54fe833b47eb38ee00cac#"><svg height="32" class="octicon octicon-mark-github" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"></path></svg></a>

      <ul class="clearfix">
        <li>
          <!-- '"` --><!-- </textarea></xmp> --><form class="js-mobile-preference-form" action="https://gist.github.com/site/mobile_preference" accept-charset="UTF-8" method="post">
            
            

            <button type="submit" class="switch-to-desktop" data-ga-click="Mobile, switch to desktop, switch button">
              Desktop version
            </button>
</form>        </li>
        <li>
          <!-- '"` --><!-- </textarea></xmp> --><form class="" action="https://gist.github.com/auth/github/logout" accept-charset="UTF-8" method="post">
            <button type="submit" data-ga-click="Mobile, tap, location:header; text:Sign out" class="btn-link">
              Sign out
            </button>
</form>        </li>
      </ul>
    </div>
  </footer>
  
    

  


</body></html>
------MultipartBoundary--kTQgBUfc6f4BLSFiT9rvMhqXUu6noRxQRXYfZgCqVt----
Content-Type: text/css
Content-Transfer-Encoding: binary
Content-Location: https://assets-cdn.github.com/assets/mobile-12ee12914455b324ccd998f066240022.css

@charset "utf-8";

.anim-fade-in { animation-duration: 1s; animation-name: fade-in; animation-timing-function: ease-in-out; }

.anim-fade-in.fast { animation-duration: 0.3s; }

@keyframes fade-in { 
  0% { opacity: 0; }
  100% { opacity: 1; }
}

.anim-fade-out { animation-duration: 1s; animation-name: fade-out; animation-timing-function: ease-out; }

.anim-fade-out.fast { animation-duration: 0.3s; }

@keyframes fade-out { 
  0% { opacity: 1; }
  100% { opacity: 0; }
}

.anim-fade-up { animation-delay: 1s; animation-duration: 0.3s; animation-fill-mode: forwards; animation-name: fade-up; animation-timing-function: ease-out; opacity: 0; }

@keyframes fade-up { 
  0% { opacity: 0.8; transform: translateY(100%); }
  100% { opacity: 1; transform: translateY(0px); }
}

.anim-fade-down { animation-duration: 0.3s; animation-fill-mode: forwards; animation-name: fade-down; animation-timing-function: ease-in; }

@keyframes fade-down { 
  0% { opacity: 1; transform: translateY(0px); }
  100% { opacity: 0.5; transform: translateY(100%); }
}

.anim-grow-x { animation-delay: 0.5s; animation-duration: 0.3s; animation-fill-mode: forwards; animation-name: grow-x; animation-timing-function: ease; width: 0px; }

@keyframes grow-x { 
  100% { width: 100%; }
}

.anim-shrink-x { animation-delay: 0.5s; animation-duration: 0.3s; animation-fill-mode: forwards; animation-name: shrink-x; animation-timing-function: ease-in-out; }

@keyframes shrink-x { 
  100% { width: 0px; }
}

.anim-scale-in { animation-duration: 0.15s; animation-name: scale-in; animation-timing-function: cubic-bezier(0.2, 0, 0.13, 1.5); }

@keyframes scale-in { 
  0% { opacity: 0; transform: scale(0.5); }
  100% { opacity: 1; transform: scale(1); }
}

.anim-pulse { animation-duration: 2s; animation-iteration-count: infinite; animation-name: pulse; animation-timing-function: linear; }

@keyframes pulse { 
  0% { opacity: 0.3; }
  10% { opacity: 1; }
  100% { opacity: 0.3; }
}

.anim-pulse-in { animation-duration: 0.5s; animation-name: pulse-in; }

@keyframes pulse-in { 
  0% { transform: scaleX(1); }
  50% { transform: scale3d(1.1, 1.1, 1.1); }
  100% { transform: scaleX(1); }
}

.hover-grow { backface-visibility: hidden; transition: transform 0.3s ease 0s; }

.hover-grow:hover { transform: scale(1.025); }

.border { border: 1px solid rgb(225, 228, 232) !important; }

.border-y { border-bottom: 1px solid rgb(225, 228, 232) !important; border-top: 1px solid rgb(225, 228, 232) !important; }

.border-0 { border: 0px !important; }

.border-dashed { border-style: dashed !important; }

.border-blue { border-color: rgb(3, 102, 214) !important; }

.border-blue-light { border-color: rgb(200, 225, 255) !important; }

.border-green { border-color: rgb(52, 208, 88) !important; }

.border-green-light { border-color: rgb(162, 203, 172) !important; }

.border-red { border-color: rgb(215, 58, 73) !important; }

.border-red-light { border-color: rgb(206, 160, 165) !important; }

.border-purple { border-color: rgb(111, 66, 193) !important; }

.border-yellow { border-color: rgb(217, 208, 165) !important; }

.border-gray-light { border-color: rgb(234, 236, 239) !important; }

.border-gray-dark { border-color: rgb(209, 213, 218) !important; }

.border-black-fade { border-color: rgba(27, 31, 35, 0.15) !important; }

.border-top { border-top: 1px solid rgb(225, 228, 232) !important; }

.border-right { border-right: 1px solid rgb(225, 228, 232) !important; }

.border-bottom { border-bottom: 1px solid rgb(225, 228, 232) !important; }

.border-left { border-left: 1px solid rgb(225, 228, 232) !important; }

.border-top-0 { border-top: 0px !important; }

.border-right-0 { border-right: 0px !important; }

.border-bottom-0 { border-bottom: 0px !important; }

.border-left-0 { border-left: 0px !important; }

.rounded-0 { border-radius: 0px !important; }

.rounded-1 { border-radius: 3px !important; }

.rounded-2 { border-radius: 6px !important; }

.rounded-top-0 { border-top-left-radius: 0px; border-top-right-radius: 0px; }

.rounded-top-1 { border-top-left-radius: 3px; border-top-right-radius: 3px; }

.rounded-top-2 { border-top-left-radius: 6px; border-top-right-radius: 6px; }

.rounded-right-0 { border-bottom-right-radius: 0px; border-top-right-radius: 0px; }

.rounded-right-1 { border-bottom-right-radius: 3px; border-top-right-radius: 3px; }

.rounded-right-2 { border-bottom-right-radius: 6px; border-top-right-radius: 6px; }

.rounded-bottom-0 { border-bottom-left-radius: 0px; border-bottom-right-radius: 0px; }

.rounded-bottom-1 { border-bottom-left-radius: 3px; border-bottom-right-radius: 3px; }

.rounded-bottom-2 { border-bottom-left-radius: 6px; border-bottom-right-radius: 6px; }

.rounded-left-0 { border-bottom-left-radius: 0px; border-top-left-radius: 0px; }

.rounded-left-1 { border-bottom-left-radius: 3px; border-top-left-radius: 3px; }

.rounded-left-2 { border-bottom-left-radius: 6px; border-top-left-radius: 6px; }

@media (min-width: 544px) {
  .border-sm-top { border-top: 1px solid rgb(225, 228, 232) !important; }
  .border-sm-right { border-right: 1px solid rgb(225, 228, 232) !important; }
  .border-sm-bottom { border-bottom: 1px solid rgb(225, 228, 232) !important; }
  .border-sm-left { border-left: 1px solid rgb(225, 228, 232) !important; }
  .border-sm-top-0 { border-top: 0px !important; }
  .border-sm-right-0 { border-right: 0px !important; }
  .border-sm-bottom-0 { border-bottom: 0px !important; }
  .border-sm-left-0 { border-left: 0px !important; }
  .rounded-sm-0 { border-radius: 0px !important; }
  .rounded-sm-1 { border-radius: 3px !important; }
  .rounded-sm-2 { border-radius: 6px !important; }
  .rounded-sm-top-0 { border-top-left-radius: 0px; border-top-right-radius: 0px; }
  .rounded-sm-top-1 { border-top-left-radius: 3px; border-top-right-radius: 3px; }
  .rounded-sm-top-2 { border-top-left-radius: 6px; border-top-right-radius: 6px; }
  .rounded-sm-right-0 { border-bottom-right-radius: 0px; border-top-right-radius: 0px; }
  .rounded-sm-right-1 { border-bottom-right-radius: 3px; border-top-right-radius: 3px; }
  .rounded-sm-right-2 { border-bottom-right-radius: 6px; border-top-right-radius: 6px; }
  .rounded-sm-bottom-0 { border-bottom-left-radius: 0px; border-bottom-right-radius: 0px; }
  .rounded-sm-bottom-1 { border-bottom-left-radius: 3px; border-bottom-right-radius: 3px; }
  .rounded-sm-bottom-2 { border-bottom-left-radius: 6px; border-bottom-right-radius: 6px; }
  .rounded-sm-left-0 { border-bottom-left-radius: 0px; border-top-left-radius: 0px; }
  .rounded-sm-left-1 { border-bottom-left-radius: 3px; border-top-left-radius: 3px; }
  .rounded-sm-left-2 { border-bottom-left-radius: 6px; border-top-left-radius: 6px; }
}

@media (min-width: 768px) {
  .border-md-top { border-top: 1px solid rgb(225, 228, 232) !important; }
  .border-md-right { border-right: 1px solid rgb(225, 228, 232) !important; }
  .border-md-bottom { border-bottom: 1px solid rgb(225, 228, 232) !important; }
  .border-md-left { border-left: 1px solid rgb(225, 228, 232) !important; }
  .border-md-top-0 { border-top: 0px !important; }
  .border-md-right-0 { border-right: 0px !important; }
  .border-md-bottom-0 { border-bottom: 0px !important; }
  .border-md-left-0 { border-left: 0px !important; }
  .rounded-md-0 { border-radius: 0px !important; }
  .rounded-md-1 { border-radius: 3px !important; }
  .rounded-md-2 { border-radius: 6px !important; }
  .rounded-md-top-0 { border-top-left-radius: 0px; border-top-right-radius: 0px; }
  .rounded-md-top-1 { border-top-left-radius: 3px; border-top-right-radius: 3px; }
  .rounded-md-top-2 { border-top-left-radius: 6px; border-top-right-radius: 6px; }
  .rounded-md-right-0 { border-bottom-right-radius: 0px; border-top-right-radius: 0px; }
  .rounded-md-right-1 { border-bottom-right-radius: 3px; border-top-right-radius: 3px; }
  .rounded-md-right-2 { border-bottom-right-radius: 6px; border-top-right-radius: 6px; }
  .rounded-md-bottom-0 { border-bottom-left-radius: 0px; border-bottom-right-radius: 0px; }
  .rounded-md-bottom-1 { border-bottom-left-radius: 3px; border-bottom-right-radius: 3px; }
  .rounded-md-bottom-2 { border-bottom-left-radius: 6px; border-bottom-right-radius: 6px; }
  .rounded-md-left-0 { border-bottom-left-radius: 0px; border-top-left-radius: 0px; }
  .rounded-md-left-1 { border-bottom-left-radius: 3px; border-top-left-radius: 3px; }
  .rounded-md-left-2 { border-bottom-left-radius: 6px; border-top-left-radius: 6px; }
}

@media (min-width: 1012px) {
  .border-lg-top { border-top: 1px solid rgb(225, 228, 232) !important; }
  .border-lg-right { border-right: 1px solid rgb(225, 228, 232) !important; }
  .border-lg-bottom { border-bottom: 1px solid rgb(225, 228, 232) !important; }
  .border-lg-left { border-left: 1px solid rgb(225, 228, 232) !important; }
  .border-lg-top-0 { border-top: 0px !important; }
  .border-lg-right-0 { border-right: 0px !important; }
  .border-lg-bottom-0 { border-bottom: 0px !important; }
  .border-lg-left-0 { border-left: 0px !important; }
  .rounded-lg-0 { border-radius: 0px !important; }
  .rounded-lg-1 { border-radius: 3px !important; }
  .rounded-lg-2 { border-radius: 6px !important; }
  .rounded-lg-top-0 { border-top-left-radius: 0px; border-top-right-radius: 0px; }
  .rounded-lg-top-1 { border-top-left-radius: 3px; border-top-right-radius: 3px; }
  .rounded-lg-top-2 { border-top-left-radius: 6px; border-top-right-radius: 6px; }
  .rounded-lg-right-0 { border-bottom-right-radius: 0px; border-top-right-radius: 0px; }
  .rounded-lg-right-1 { border-bottom-right-radius: 3px; border-top-right-radius: 3px; }
  .rounded-lg-right-2 { border-bottom-right-radius: 6px; border-top-right-radius: 6px; }
  .rounded-lg-bottom-0 { border-bottom-left-radius: 0px; border-bottom-right-radius: 0px; }
  .rounded-lg-bottom-1 { border-bottom-left-radius: 3px; border-bottom-right-radius: 3px; }
  .rounded-lg-bottom-2 { border-bottom-left-radius: 6px; border-bottom-right-radius: 6px; }
  .rounded-lg-left-0 { border-bottom-left-radius: 0px; border-top-left-radius: 0px; }
  .rounded-lg-left-1 { border-bottom-left-radius: 3px; border-top-left-radius: 3px; }
  .rounded-lg-left-2 { border-bottom-left-radius: 6px; border-top-left-radius: 6px; }
}

@media (min-width: 1280px) {
  .border-xl-top { border-top: 1px solid rgb(225, 228, 232) !important; }
  .border-xl-right { border-right: 1px solid rgb(225, 228, 232) !important; }
  .border-xl-bottom { border-bottom: 1px solid rgb(225, 228, 232) !important; }
  .border-xl-left { border-left: 1px solid rgb(225, 228, 232) !important; }
  .border-xl-top-0 { border-top: 0px !important; }
  .border-xl-right-0 { border-right: 0px !important; }
  .border-xl-bottom-0 { border-bottom: 0px !important; }
  .border-xl-left-0 { border-left: 0px !important; }
  .rounded-xl-0 { border-radius: 0px !important; }
  .rounded-xl-1 { border-radius: 3px !important; }
  .rounded-xl-2 { border-radius: 6px !important; }
  .rounded-xl-top-0 { border-top-left-radius: 0px; border-top-right-radius: 0px; }
  .rounded-xl-top-1 { border-top-left-radius: 3px; border-top-right-radius: 3px; }
  .rounded-xl-top-2 { border-top-left-radius: 6px; border-top-right-radius: 6px; }
  .rounded-xl-right-0 { border-bottom-right-radius: 0px; border-top-right-radius: 0px; }
  .rounded-xl-right-1 { border-bottom-right-radius: 3px; border-top-right-radius: 3px; }
  .rounded-xl-right-2 { border-bottom-right-radius: 6px; border-top-right-radius: 6px; }
  .rounded-xl-bottom-0 { border-bottom-left-radius: 0px; border-bottom-right-radius: 0px; }
  .rounded-xl-bottom-1 { border-bottom-left-radius: 3px; border-bottom-right-radius: 3px; }
  .rounded-xl-bottom-2 { border-bottom-left-radius: 6px; border-bottom-right-radius: 6px; }
  .rounded-xl-left-0 { border-bottom-left-radius: 0px; border-top-left-radius: 0px; }
  .rounded-xl-left-1 { border-bottom-left-radius: 3px; border-top-left-radius: 3px; }
  .rounded-xl-left-2 { border-bottom-left-radius: 6px; border-top-left-radius: 6px; }
}

.circle { border-radius: 50% !important; }

.box-shadow { box-shadow: rgba(27, 31, 35, 0.1) 0px 1px 1px !important; }

.box-shadow-medium { box-shadow: rgba(27, 31, 35, 0.15) 0px 1px 5px !important; }

.box-shadow-large { box-shadow: rgba(27, 31, 35, 0.15) 0px 1px 15px !important; }

.box-shadow-extra-large { box-shadow: rgba(27, 31, 35, 0.07) 0px 10px 50px !important; }

.box-shadow-none { box-shadow: none !important; }

.bg-white { background-color: rgb(255, 255, 255) !important; }

.bg-blue { background-color: rgb(3, 102, 214) !important; }

.bg-blue-light { background-color: rgb(241, 248, 255) !important; }

.bg-gray-dark { background-color: rgb(36, 41, 46) !important; }

.bg-gray { background-color: rgb(246, 248, 250) !important; }

.bg-gray-light { background-color: rgb(250, 251, 252) !important; }

.bg-green { background-color: rgb(40, 167, 69) !important; }

.bg-green-light { background-color: rgb(220, 255, 228) !important; }

.bg-red { background-color: rgb(215, 58, 73) !important; }

.bg-red-light { background-color: rgb(255, 220, 224) !important; }

.bg-yellow { background-color: rgb(255, 211, 61) !important; }

.bg-yellow-light { background-color: rgb(255, 245, 177) !important; }

.bg-purple { background-color: rgb(111, 66, 193) !important; }

.bg-purple-light { background-color: rgb(245, 240, 255) !important; }

.bg-shade-gradient { background-image: linear-gradient(rgba(27, 31, 35, 0.067), rgba(27, 31, 35, 0)) !important; background-repeat: no-repeat !important; background-size: 100% 200px !important; }

.text-blue { color: rgb(3, 102, 214) !important; }

.text-red { color: rgb(203, 36, 49) !important; }

.text-gray-light { color: rgb(106, 115, 125) !important; }

.text-gray { color: rgb(88, 96, 105) !important; }

.text-gray-dark { color: rgb(36, 41, 46) !important; }

.text-green { color: rgb(40, 167, 69) !important; }

.text-orange { color: rgb(160, 65, 0) !important; }

.text-orange-light { color: rgb(227, 98, 9) !important; }

.text-purple { color: rgb(111, 66, 193) !important; }

.text-white { color: rgb(255, 255, 255) !important; }

.text-inherit { color: inherit !important; }

.text-pending { color: rgb(176, 136, 0) !important; }

.bg-pending { color: rgb(219, 171, 9) !important; }

.link-gray { color: rgb(88, 96, 105) !important; }

.link-gray:hover { color: rgb(3, 102, 214) !important; }

.link-gray-dark { color: rgb(36, 41, 46) !important; }

.link-gray-dark:hover, .link-hover-blue:hover { color: rgb(3, 102, 214) !important; }

.muted-link { color: rgb(88, 96, 105) !important; }

.muted-link:hover { text-decoration: none; color: rgb(3, 102, 214) !important; }

.details-overlay[open] > summary::before { background: transparent; bottom: 0px; content: " "; cursor: default; display: block; left: 0px; position: fixed; right: 0px; top: 0px; z-index: 80; }

.details-overlay-dark[open] > summary::before { background: rgba(27, 31, 35, 0.5); z-index: 99; }

.flex-row { flex-direction: row !important; }

.flex-row-reverse { flex-direction: row-reverse !important; }

.flex-column { flex-direction: column !important; }

.flex-wrap { flex-wrap: wrap !important; }

.flex-nowrap { flex-wrap: nowrap !important; }

.flex-justify-start { justify-content: flex-start !important; }

.flex-justify-end { justify-content: flex-end !important; }

.flex-justify-center { justify-content: center !important; }

.flex-justify-between { justify-content: space-between !important; }

.flex-justify-around { justify-content: space-around !important; }

.flex-items-start { align-items: flex-start !important; }

.flex-items-end { align-items: flex-end !important; }

.flex-items-center { align-items: center !important; }

.flex-items-baseline { align-items: baseline !important; }

.flex-items-stretch { align-items: stretch !important; }

.flex-content-start { align-content: flex-start !important; }

.flex-content-end { align-content: flex-end !important; }

.flex-content-center { align-content: center !important; }

.flex-content-between { align-content: space-between !important; }

.flex-content-around { align-content: space-around !important; }

.flex-content-stretch { align-content: stretch !important; }

.flex-auto { flex: 1 1 auto !important; }

.flex-shrink-0 { flex-shrink: 0 !important; }

.flex-self-auto { align-self: auto !important; }

.flex-self-start { align-self: flex-start !important; }

.flex-self-end { align-self: flex-end !important; }

.flex-self-center { align-self: center !important; }

.flex-self-baseline { align-self: baseline !important; }

.flex-self-stretch { align-self: stretch !important; }

.flex-item-equal { flex-basis: 0px; flex-grow: 1; }

@media (min-width: 544px) {
  .flex-sm-row { flex-direction: row !important; }
  .flex-sm-row-reverse { flex-direction: row-reverse !important; }
  .flex-sm-column { flex-direction: column !important; }
  .flex-sm-wrap { flex-wrap: wrap !important; }
  .flex-sm-nowrap { flex-wrap: nowrap !important; }
  .flex-sm-justify-start { justify-content: flex-start !important; }
  .flex-sm-justify-end { justify-content: flex-end !important; }
  .flex-sm-justify-center { justify-content: center !important; }
  .flex-sm-justify-between { justify-content: space-between !important; }
  .flex-sm-justify-around { justify-content: space-around !important; }
  .flex-sm-items-start { align-items: flex-start !important; }
  .flex-sm-items-end { align-items: flex-end !important; }
  .flex-sm-items-center { align-items: center !important; }
  .flex-sm-items-baseline { align-items: baseline !important; }
  .flex-sm-items-stretch { align-items: stretch !important; }
  .flex-sm-content-start { align-content: flex-start !important; }
  .flex-sm-content-end { align-content: flex-end !important; }
  .flex-sm-content-center { align-content: center !important; }
  .flex-sm-content-between { align-content: space-between !important; }
  .flex-sm-content-around { align-content: space-around !important; }
  .flex-sm-content-stretch { align-content: stretch !important; }
  .flex-sm-auto { flex: 1 1 auto !important; }
  .flex-sm-shrink-0 { flex-shrink: 0 !important; }
  .flex-sm-self-auto { align-self: auto !important; }
  .flex-sm-self-start { align-self: flex-start !important; }
  .flex-sm-self-end { align-self: flex-end !important; }
  .flex-sm-self-center { align-self: center !important; }
  .flex-sm-self-baseline { align-self: baseline !important; }
  .flex-sm-self-stretch { align-self: stretch !important; }
  .flex-sm-item-equal { flex-basis: 0px; flex-grow: 1; }
}

@media (min-width: 768px) {
  .flex-md-row { flex-direction: row !important; }
  .flex-md-row-reverse { flex-direction: row-reverse !important; }
  .flex-md-column { flex-direction: column !important; }
  .flex-md-wrap { flex-wrap: wrap !important; }
  .flex-md-nowrap { flex-wrap: nowrap !important; }
  .flex-md-justify-start { justify-content: flex-start !important; }
  .flex-md-justify-end { justify-content: flex-end !important; }
  .flex-md-justify-center { justify-content: center !important; }
  .flex-md-justify-between { justify-content: space-between !important; }
  .flex-md-justify-around { justify-content: space-around !important; }
  .flex-md-items-start { align-items: flex-start !important; }
  .flex-md-items-end { align-items: flex-end !important; }
  .flex-md-items-center { align-items: center !important; }
  .flex-md-items-baseline { align-items: baseline !important; }
  .flex-md-items-stretch { align-items: stretch !important; }
  .flex-md-content-start { align-content: flex-start !important; }
  .flex-md-content-end { align-content: flex-end !important; }
  .flex-md-content-center { align-content: center !important; }
  .flex-md-content-between { align-content: space-between !important; }
  .flex-md-content-around { align-content: space-around !important; }
  .flex-md-content-stretch { align-content: stretch !important; }
  .flex-md-auto { flex: 1 1 auto !important; }
  .flex-md-shrink-0 { flex-shrink: 0 !important; }
  .flex-md-self-auto { align-self: auto !important; }
  .flex-md-self-start { align-self: flex-start !important; }
  .flex-md-self-end { align-self: flex-end !important; }
  .flex-md-self-center { align-self: center !important; }
  .flex-md-self-baseline { align-self: baseline !important; }
  .flex-md-self-stretch { align-self: stretch !important; }
  .flex-md-item-equal { flex-basis: 0px; flex-grow: 1; }
}

@media (min-width: 1012px) {
  .flex-lg-row { flex-direction: row !important; }
  .flex-lg-row-reverse { flex-direction: row-reverse !important; }
  .flex-lg-column { flex-direction: column !important; }
  .flex-lg-wrap { flex-wrap: wrap !important; }
  .flex-lg-nowrap { flex-wrap: nowrap !important; }
  .flex-lg-justify-start { justify-content: flex-start !important; }
  .flex-lg-justify-end { justify-content: flex-end !important; }
  .flex-lg-justify-center { justify-content: center !important; }
  .flex-lg-justify-between { justify-content: space-between !important; }
  .flex-lg-justify-around { justify-content: space-around !important; }
  .flex-lg-items-start { align-items: flex-start !important; }
  .flex-lg-items-end { align-items: flex-end !important; }
  .flex-lg-items-center { align-items: center !important; }
  .flex-lg-items-baseline { align-items: baseline !important; }
  .flex-lg-items-stretch { align-items: stretch !important; }
  .flex-lg-content-start { align-content: flex-start !important; }
  .flex-lg-content-end { align-content: flex-end !important; }
  .flex-lg-content-center { align-content: center !important; }
  .flex-lg-content-between { align-content: space-between !important; }
  .flex-lg-content-around { align-content: space-around !important; }
  .flex-lg-content-stretch { align-content: stretch !important; }
  .flex-lg-auto { flex: 1 1 auto !important; }
  .flex-lg-shrink-0 { flex-shrink: 0 !important; }
  .flex-lg-self-auto { align-self: auto !important; }
  .flex-lg-self-start { align-self: flex-start !important; }
  .flex-lg-self-end { align-self: flex-end !important; }
  .flex-lg-self-center { align-self: center !important; }
  .flex-lg-self-baseline { align-self: baseline !important; }
  .flex-lg-self-stretch { align-self: stretch !important; }
  .flex-lg-item-equal { flex-basis: 0px; flex-grow: 1; }
}

@media (min-width: 1280px) {
  .flex-xl-row { flex-direction: row !important; }
  .flex-xl-row-reverse { flex-direction: row-reverse !important; }
  .flex-xl-column { flex-direction: column !important; }
  .flex-xl-wrap { flex-wrap: wrap !important; }
  .flex-xl-nowrap { flex-wrap: nowrap !important; }
  .flex-xl-justify-start { justify-content: flex-start !important; }
  .flex-xl-justify-end { justify-content: flex-end !important; }
  .flex-xl-justify-center { justify-content: center !important; }
  .flex-xl-justify-between { justify-content: space-between !important; }
  .flex-xl-justify-around { justify-content: space-around !important; }
  .flex-xl-items-start { align-items: flex-start !important; }
  .flex-xl-items-end { align-items: flex-end !important; }
  .flex-xl-items-center { align-items: center !important; }
  .flex-xl-items-baseline { align-items: baseline !important; }
  .flex-xl-items-stretch { align-items: stretch !important; }
  .flex-xl-content-start { align-content: flex-start !important; }
  .flex-xl-content-end { align-content: flex-end !important; }
  .flex-xl-content-center { align-content: center !important; }
  .flex-xl-content-between { align-content: space-between !important; }
  .flex-xl-content-around { align-content: space-around !important; }
  .flex-xl-content-stretch { align-content: stretch !important; }
  .flex-xl-auto { flex: 1 1 auto !important; }
  .flex-xl-shrink-0 { flex-shrink: 0 !important; }
  .flex-xl-self-auto { align-self: auto !important; }
  .flex-xl-self-start { align-self: flex-start !important; }
  .flex-xl-self-end { align-self: flex-end !important; }
  .flex-xl-self-center { align-self: center !important; }
  .flex-xl-self-baseline { align-self: baseline !important; }
  .flex-xl-self-stretch { align-self: stretch !important; }
  .flex-xl-item-equal { flex-basis: 0px; flex-grow: 1; }
}

.position-static { position: static !important; }

.position-relative { position: relative !important; }

.position-absolute { position: absolute !important; }

.position-fixed { position: fixed !important; }

.top-0 { top: 0px !important; }

.right-0 { right: 0px !important; }

.bottom-0 { bottom: 0px !important; }

.left-0 { left: 0px !important; }

.v-align-middle { vertical-align: middle !important; }

.v-align-top { vertical-align: top !important; }

.v-align-bottom { vertical-align: bottom !important; }

.v-align-text-top { vertical-align: text-top !important; }

.v-align-text-bottom { vertical-align: text-bottom !important; }

.v-align-baseline { vertical-align: initial !important; }

.overflow-hidden { overflow: hidden !important; }

.overflow-scroll { overflow: scroll !important; }

.overflow-auto { overflow: auto !important; }

.clearfix::after, .clearfix::before { content: ""; display: table; }

.float-left { float: left !important; }

.float-right { float: right !important; }

.float-none { float: none !important; }

@media (min-width: 544px) {
  .float-sm-left { float: left !important; }
  .float-sm-right { float: right !important; }
  .float-sm-none { float: none !important; }
}

@media (min-width: 768px) {
  .float-md-left { float: left !important; }
  .float-md-right { float: right !important; }
  .float-md-none { float: none !important; }
}

@media (min-width: 1012px) {
  .float-lg-left { float: left !important; }
  .float-lg-right { float: right !important; }
  .float-lg-none { float: none !important; }
}

@media (min-width: 1280px) {
  .float-xl-left { float: left !important; }
  .float-xl-right { float: right !important; }
  .float-xl-none { float: none !important; }
}

.width-fit { max-width: 100% !important; }

.width-full { width: 100% !important; }

.height-fit { max-height: 100% !important; }

.height-full { height: 100% !important; }

.min-width-0 { min-width: 0px !important; }

.direction-rtl { direction: rtl !important; }

.direction-ltr { direction: ltr !important; }

@media (min-width: 544px) {
  .direction-sm-rtl { direction: rtl !important; }
  .direction-sm-ltr { direction: ltr !important; }
}

@media (min-width: 768px) {
  .direction-md-rtl { direction: rtl !important; }
  .direction-md-ltr { direction: ltr !important; }
}

@media (min-width: 1012px) {
  .direction-lg-rtl { direction: rtl !important; }
  .direction-lg-ltr { direction: ltr !important; }
}

@media (min-width: 1280px) {
  .direction-xl-rtl { direction: rtl !important; }
  .direction-xl-ltr { direction: ltr !important; }
}

.m-0 { margin: 0px !important; }

.mt-0 { margin-top: 0px !important; }

.mr-0 { margin-right: 0px !important; }

.mb-0 { margin-bottom: 0px !important; }

.ml-0, .mx-0 { margin-left: 0px !important; }

.mx-0 { margin-right: 0px !important; }

.my-0 { margin-bottom: 0px !important; margin-top: 0px !important; }

.m-1 { margin: 4px !important; }

.mt-1 { margin-top: 4px !important; }

.mr-1 { margin-right: 4px !important; }

.mb-1 { margin-bottom: 4px !important; }

.ml-1 { margin-left: 4px !important; }

.mt-n1 { margin-top: -4px !important; }

.mr-n1 { margin-right: -4px !important; }

.mb-n1 { margin-bottom: -4px !important; }

.ml-n1 { margin-left: -4px !important; }

.mx-1 { margin-left: 4px !important; margin-right: 4px !important; }

.my-1 { margin-bottom: 4px !important; margin-top: 4px !important; }

.m-2 { margin: 8px !important; }

.mt-2 { margin-top: 8px !important; }

.mr-2 { margin-right: 8px !important; }

.mb-2 { margin-bottom: 8px !important; }

.ml-2 { margin-left: 8px !important; }

.mt-n2 { margin-top: -8px !important; }

.mr-n2 { margin-right: -8px !important; }

.mb-n2 { margin-bottom: -8px !important; }

.ml-n2 { margin-left: -8px !important; }

.mx-2 { margin-left: 8px !important; margin-right: 8px !important; }

.my-2 { margin-bottom: 8px !important; margin-top: 8px !important; }

.m-3 { margin: 16px !important; }

.mt-3 { margin-top: 16px !important; }

.mr-3 { margin-right: 16px !important; }

.mb-3 { margin-bottom: 16px !important; }

.ml-3 { margin-left: 16px !important; }

.mt-n3 { margin-top: -16px !important; }

.mr-n3 { margin-right: -16px !important; }

.mb-n3 { margin-bottom: -16px !important; }

.ml-n3 { margin-left: -16px !important; }

.mx-3 { margin-left: 16px !important; margin-right: 16px !important; }

.my-3 { margin-bottom: 16px !important; margin-top: 16px !important; }

.m-4 { margin: 24px !important; }

.mt-4 { margin-top: 24px !important; }

.mr-4 { margin-right: 24px !important; }

.mb-4 { margin-bottom: 24px !important; }

.ml-4 { margin-left: 24px !important; }

.mt-n4 { margin-top: -24px !important; }

.mr-n4 { margin-right: -24px !important; }

.mb-n4 { margin-bottom: -24px !important; }

.ml-n4 { margin-left: -24px !important; }

.mx-4 { margin-left: 24px !important; margin-right: 24px !important; }

.my-4 { margin-bottom: 24px !important; margin-top: 24px !important; }

.m-5 { margin: 32px !important; }

.mt-5 { margin-top: 32px !important; }

.mr-5 { margin-right: 32px !important; }

.mb-5 { margin-bottom: 32px !important; }

.ml-5 { margin-left: 32px !important; }

.mt-n5 { margin-top: -32px !important; }

.mr-n5 { margin-right: -32px !important; }

.mb-n5 { margin-bottom: -32px !important; }

.ml-n5 { margin-left: -32px !important; }

.mx-5 { margin-left: 32px !important; margin-right: 32px !important; }

.my-5 { margin-bottom: 32px !important; margin-top: 32px !important; }

.m-6 { margin: 40px !important; }

.mt-6 { margin-top: 40px !important; }

.mr-6 { margin-right: 40px !important; }

.mb-6 { margin-bottom: 40px !important; }

.ml-6 { margin-left: 40px !important; }

.mt-n6 { margin-top: -40px !important; }

.mr-n6 { margin-right: -40px !important; }

.mb-n6 { margin-bottom: -40px !important; }

.ml-n6 { margin-left: -40px !important; }

.mx-6 { margin-left: 40px !important; margin-right: 40px !important; }

.my-6 { margin-bottom: 40px !important; margin-top: 40px !important; }

.mx-auto { margin-left: auto !important; margin-right: auto !important; }

@media (min-width: 544px) {
  .m-sm-0 { margin: 0px !important; }
  .mt-sm-0 { margin-top: 0px !important; }
  .mr-sm-0 { margin-right: 0px !important; }
  .mb-sm-0 { margin-bottom: 0px !important; }
  .ml-sm-0, .mx-sm-0 { margin-left: 0px !important; }
  .mx-sm-0 { margin-right: 0px !important; }
  .my-sm-0 { margin-bottom: 0px !important; margin-top: 0px !important; }
  .m-sm-1 { margin: 4px !important; }
  .mt-sm-1 { margin-top: 4px !important; }
  .mr-sm-1 { margin-right: 4px !important; }
  .mb-sm-1 { margin-bottom: 4px !important; }
  .ml-sm-1 { margin-left: 4px !important; }
  .mt-sm-n1 { margin-top: -4px !important; }
  .mr-sm-n1 { margin-right: -4px !important; }
  .mb-sm-n1 { margin-bottom: -4px !important; }
  .ml-sm-n1 { margin-left: -4px !important; }
  .mx-sm-1 { margin-left: 4px !important; margin-right: 4px !important; }
  .my-sm-1 { margin-bottom: 4px !important; margin-top: 4px !important; }
  .m-sm-2 { margin: 8px !important; }
  .mt-sm-2 { margin-top: 8px !important; }
  .mr-sm-2 { margin-right: 8px !important; }
  .mb-sm-2 { margin-bottom: 8px !important; }
  .ml-sm-2 { margin-left: 8px !important; }
  .mt-sm-n2 { margin-top: -8px !important; }
  .mr-sm-n2 { margin-right: -8px !important; }
  .mb-sm-n2 { margin-bottom: -8px !important; }
  .ml-sm-n2 { margin-left: -8px !important; }
  .mx-sm-2 { margin-left: 8px !important; margin-right: 8px !important; }
  .my-sm-2 { margin-bottom: 8px !important; margin-top: 8px !important; }
  .m-sm-3 { margin: 16px !important; }
  .mt-sm-3 { margin-top: 16px !important; }
  .mr-sm-3 { margin-right: 16px !important; }
  .mb-sm-3 { margin-bottom: 16px !important; }
  .ml-sm-3 { margin-left: 16px !important; }
  .mt-sm-n3 { margin-top: -16px !important; }
  .mr-sm-n3 { margin-right: -16px !important; }
  .mb-sm-n3 { margin-bottom: -16px !important; }
  .ml-sm-n3 { margin-left: -16px !important; }
  .mx-sm-3 { margin-left: 16px !important; margin-right: 16px !important; }
  .my-sm-3 { margin-bottom: 16px !important; margin-top: 16px !important; }
  .m-sm-4 { margin: 24px !important; }
  .mt-sm-4 { margin-top: 24px !important; }
  .mr-sm-4 { margin-right: 24px !important; }
  .mb-sm-4 { margin-bottom: 24px !important; }
  .ml-sm-4 { margin-left: 24px !important; }
  .mt-sm-n4 { margin-top: -24px !important; }
  .mr-sm-n4 { margin-right: -24px !important; }
  .mb-sm-n4 { margin-bottom: -24px !important; }
  .ml-sm-n4 { margin-left: -24px !important; }
  .mx-sm-4 { margin-left: 24px !important; margin-right: 24px !important; }
  .my-sm-4 { margin-bottom: 24px !important; margin-top: 24px !important; }
  .m-sm-5 { margin: 32px !important; }
  .mt-sm-5 { margin-top: 32px !important; }
  .mr-sm-5 { margin-right: 32px !important; }
  .mb-sm-5 { margin-bottom: 32px !important; }
  .ml-sm-5 { margin-left: 32px !important; }
  .mt-sm-n5 { margin-top: -32px !important; }
  .mr-sm-n5 { margin-right: -32px !important; }
  .mb-sm-n5 { margin-bottom: -32px !important; }
  .ml-sm-n5 { margin-left: -32px !important; }
  .mx-sm-5 { margin-left: 32px !important; margin-right: 32px !important; }
  .my-sm-5 { margin-bottom: 32px !important; margin-top: 32px !important; }
  .m-sm-6 { margin: 40px !important; }
  .mt-sm-6 { margin-top: 40px !important; }
  .mr-sm-6 { margin-right: 40px !important; }
  .mb-sm-6 { margin-bottom: 40px !important; }
  .ml-sm-6 { margin-left: 40px !important; }
  .mt-sm-n6 { margin-top: -40px !important; }
  .mr-sm-n6 { margin-right: -40px !important; }
  .mb-sm-n6 { margin-bottom: -40px !important; }
  .ml-sm-n6 { margin-left: -40px !important; }
  .mx-sm-6 { margin-left: 40px !important; margin-right: 40px !important; }
  .my-sm-6 { margin-bottom: 40px !important; margin-top: 40px !important; }
  .mx-sm-auto { margin-left: auto !important; margin-right: auto !important; }
}

@media (min-width: 768px) {
  .m-md-0 { margin: 0px !important; }
  .mt-md-0 { margin-top: 0px !important; }
  .mr-md-0 { margin-right: 0px !important; }
  .mb-md-0 { margin-bottom: 0px !important; }
  .ml-md-0, .mx-md-0 { margin-left: 0px !important; }
  .mx-md-0 { margin-right: 0px !important; }
  .my-md-0 { margin-bottom: 0px !important; margin-top: 0px !important; }
  .m-md-1 { margin: 4px !important; }
  .mt-md-1 { margin-top: 4px !important; }
  .mr-md-1 { margin-right: 4px !important; }
  .mb-md-1 { margin-bottom: 4px !important; }
  .ml-md-1 { margin-left: 4px !important; }
  .mt-md-n1 { margin-top: -4px !important; }
  .mr-md-n1 { margin-right: -4px !important; }
  .mb-md-n1 { margin-bottom: -4px !important; }
  .ml-md-n1 { margin-left: -4px !important; }
  .mx-md-1 { margin-left: 4px !important; margin-right: 4px !important; }
  .my-md-1 { margin-bottom: 4px !important; margin-top: 4px !important; }
  .m-md-2 { margin: 8px !important; }
  .mt-md-2 { margin-top: 8px !important; }
  .mr-md-2 { margin-right: 8px !important; }
  .mb-md-2 { margin-bottom: 8px !important; }
  .ml-md-2 { margin-left: 8px !important; }
  .mt-md-n2 { margin-top: -8px !important; }
  .mr-md-n2 { margin-right: -8px !important; }
  .mb-md-n2 { margin-bottom: -8px !important; }
  .ml-md-n2 { margin-left: -8px !important; }
  .mx-md-2 { margin-left: 8px !important; margin-right: 8px !important; }
  .my-md-2 { margin-bottom: 8px !important; margin-top: 8px !important; }
  .m-md-3 { margin: 16px !important; }
  .mt-md-3 { margin-top: 16px !important; }
  .mr-md-3 { margin-right: 16px !important; }
  .mb-md-3 { margin-bottom: 16px !important; }
  .ml-md-3 { margin-left: 16px !important; }
  .mt-md-n3 { margin-top: -16px !important; }
  .mr-md-n3 { margin-right: -16px !important; }
  .mb-md-n3 { margin-bottom: -16px !important; }
  .ml-md-n3 { margin-left: -16px !important; }
  .mx-md-3 { margin-left: 16px !important; margin-right: 16px !important; }
  .my-md-3 { margin-bottom: 16px !important; margin-top: 16px !important; }
  .m-md-4 { margin: 24px !important; }
  .mt-md-4 { margin-top: 24px !important; }
  .mr-md-4 { margin-right: 24px !important; }
  .mb-md-4 { margin-bottom: 24px !important; }
  .ml-md-4 { margin-left: 24px !important; }
  .mt-md-n4 { margin-top: -24px !important; }
  .mr-md-n4 { margin-right: -24px !important; }
  .mb-md-n4 { margin-bottom: -24px !important; }
  .ml-md-n4 { margin-left: -24px !important; }
  .mx-md-4 { margin-left: 24px !important; margin-right: 24px !important; }
  .my-md-4 { margin-bottom: 24px !important; margin-top: 24px !important; }
  .m-md-5 { margin: 32px !important; }
  .mt-md-5 { margin-top: 32px !important; }
  .mr-md-5 { margin-right: 32px !important; }
  .mb-md-5 { margin-bottom: 32px !important; }
  .ml-md-5 { margin-left: 32px !important; }
  .mt-md-n5 { margin-top: -32px !important; }
  .mr-md-n5 { margin-right: -32px !important; }
  .mb-md-n5 { margin-bottom: -32px !important; }
  .ml-md-n5 { margin-left: -32px !important; }
  .mx-md-5 { margin-left: 32px !important; margin-right: 32px !important; }
  .my-md-5 { margin-bottom: 32px !important; margin-top: 32px !important; }
  .m-md-6 { margin: 40px !important; }
  .mt-md-6 { margin-top: 40px !important; }
  .mr-md-6 { margin-right: 40px !important; }
  .mb-md-6 { margin-bottom: 40px !important; }
  .ml-md-6 { margin-left: 40px !important; }
  .mt-md-n6 { margin-top: -40px !important; }
  .mr-md-n6 { margin-right: -40px !important; }
  .mb-md-n6 { margin-bottom: -40px !important; }
  .ml-md-n6 { margin-left: -40px !important; }
  .mx-md-6 { margin-left: 40px !important; margin-right: 40px !important; }
  .my-md-6 { margin-bottom: 40px !important; margin-top: 40px !important; }
  .mx-md-auto { margin-left: auto !important; margin-right: auto !important; }
}

@media (min-width: 1012px) {
  .m-lg-0 { margin: 0px !important; }
  .mt-lg-0 { margin-top: 0px !important; }
  .mr-lg-0 { margin-right: 0px !important; }
  .mb-lg-0 { margin-bottom: 0px !important; }
  .ml-lg-0, .mx-lg-0 { margin-left: 0px !important; }
  .mx-lg-0 { margin-right: 0px !important; }
  .my-lg-0 { margin-bottom: 0px !important; margin-top: 0px !important; }
  .m-lg-1 { margin: 4px !important; }
  .mt-lg-1 { margin-top: 4px !important; }
  .mr-lg-1 { margin-right: 4px !important; }
  .mb-lg-1 { margin-bottom: 4px !important; }
  .ml-lg-1 { margin-left: 4px !important; }
  .mt-lg-n1 { margin-top: -4px !important; }
  .mr-lg-n1 { margin-right: -4px !important; }
  .mb-lg-n1 { margin-bottom: -4px !important; }
  .ml-lg-n1 { margin-left: -4px !important; }
  .mx-lg-1 { margin-left: 4px !important; margin-right: 4px !important; }
  .my-lg-1 { margin-bottom: 4px !important; margin-top: 4px !important; }
  .m-lg-2 { margin: 8px !important; }
  .mt-lg-2 { margin-top: 8px !important; }
  .mr-lg-2 { margin-right: 8px !important; }
  .mb-lg-2 { margin-bottom: 8px !important; }
  .ml-lg-2 { margin-left: 8px !important; }
  .mt-lg-n2 { margin-top: -8px !important; }
  .mr-lg-n2 { margin-right: -8px !important; }
  .mb-lg-n2 { margin-bottom: -8px !important; }
  .ml-lg-n2 { margin-left: -8px !important; }
  .mx-lg-2 { margin-left: 8px !important; margin-right: 8px !important; }
  .my-lg-2 { margin-bottom: 8px !important; margin-top: 8px !important; }
  .m-lg-3 { margin: 16px !important; }
  .mt-lg-3 { margin-top: 16px !important; }
  .mr-lg-3 { margin-right: 16px !important; }
  .mb-lg-3 { margin-bottom: 16px !important; }
  .ml-lg-3 { margin-left: 16px !important; }
  .mt-lg-n3 { margin-top: -16px !important; }
  .mr-lg-n3 { margin-right: -16px !important; }
  .mb-lg-n3 { margin-bottom: -16px !important; }
  .ml-lg-n3 { margin-left: -16px !important; }
  .mx-lg-3 { margin-left: 16px !important; margin-right: 16px !important; }
  .my-lg-3 { margin-bottom: 16px !important; margin-top: 16px !important; }
  .m-lg-4 { margin: 24px !important; }
  .mt-lg-4 { margin-top: 24px !important; }
  .mr-lg-4 { margin-right: 24px !important; }
  .mb-lg-4 { margin-bottom: 24px !important; }
  .ml-lg-4 { margin-left: 24px !important; }
  .mt-lg-n4 { margin-top: -24px !important; }
  .mr-lg-n4 { margin-right: -24px !important; }
  .mb-lg-n4 { margin-bottom: -24px !important; }
  .ml-lg-n4 { margin-left: -24px !important; }
  .mx-lg-4 { margin-left: 24px !important; margin-right: 24px !important; }
  .my-lg-4 { margin-bottom: 24px !important; margin-top: 24px !important; }
  .m-lg-5 { margin: 32px !important; }
  .mt-lg-5 { margin-top: 32px !important; }
  .mr-lg-5 { margin-right: 32px !important; }
  .mb-lg-5 { margin-bottom: 32px !important; }
  .ml-lg-5 { margin-left: 32px !important; }
  .mt-lg-n5 { margin-top: -32px !important; }
  .mr-lg-n5 { margin-right: -32px !important; }
  .mb-lg-n5 { margin-bottom: -32px !important; }
  .ml-lg-n5 { margin-left: -32px !important; }
  .mx-lg-5 { margin-left: 32px !important; margin-right: 32px !important; }
  .my-lg-5 { margin-bottom: 32px !important; margin-top: 32px !important; }
  .m-lg-6 { margin: 40px !important; }
  .mt-lg-6 { margin-top: 40px !important; }
  .mr-lg-6 { margin-right: 40px !important; }
  .mb-lg-6 { margin-bottom: 40px !important; }
  .ml-lg-6 { margin-left: 40px !important; }
  .mt-lg-n6 { margin-top: -40px !important; }
  .mr-lg-n6 { margin-right: -40px !important; }
  .mb-lg-n6 { margin-bottom: -40px !important; }
  .ml-lg-n6 { margin-left: -40px !important; }
  .mx-lg-6 { margin-left: 40px !important; margin-right: 40px !important; }
  .my-lg-6 { margin-bottom: 40px !important; margin-top: 40px !important; }
  .mx-lg-auto { margin-left: auto !important; margin-right: auto !important; }
}

@media (min-width: 1280px) {
  .m-xl-0 { margin: 0px !important; }
  .mt-xl-0 { margin-top: 0px !important; }
  .mr-xl-0 { margin-right: 0px !important; }
  .mb-xl-0 { margin-bottom: 0px !important; }
  .ml-xl-0, .mx-xl-0 { margin-left: 0px !important; }
  .mx-xl-0 { margin-right: 0px !important; }
  .my-xl-0 { margin-bottom: 0px !important; margin-top: 0px !important; }
  .m-xl-1 { margin: 4px !important; }
  .mt-xl-1 { margin-top: 4px !important; }
  .mr-xl-1 { margin-right: 4px !important; }
  .mb-xl-1 { margin-bottom: 4px !important; }
  .ml-xl-1 { margin-left: 4px !important; }
  .mt-xl-n1 { margin-top: -4px !important; }
  .mr-xl-n1 { margin-right: -4px !important; }
  .mb-xl-n1 { margin-bottom: -4px !important; }
  .ml-xl-n1 { margin-left: -4px !important; }
  .mx-xl-1 { margin-left: 4px !important; margin-right: 4px !important; }
  .my-xl-1 { margin-bottom: 4px !important; margin-top: 4px !important; }
  .m-xl-2 { margin: 8px !important; }
  .mt-xl-2 { margin-top: 8px !important; }
  .mr-xl-2 { margin-right: 8px !important; }
  .mb-xl-2 { margin-bottom: 8px !important; }
  .ml-xl-2 { margin-left: 8px !important; }
  .mt-xl-n2 { margin-top: -8px !important; }
  .mr-xl-n2 { margin-right: -8px !important; }
  .mb-xl-n2 { margin-bottom: -8px !important; }
  .ml-xl-n2 { margin-left: -8px !important; }
  .mx-xl-2 { margin-left: 8px !important; margin-right: 8px !important; }
  .my-xl-2 { margin-bottom: 8px !important; margin-top: 8px !important; }
  .m-xl-3 { margin: 16px !important; }
  .mt-xl-3 { margin-top: 16px !important; }
  .mr-xl-3 { margin-right: 16px !important; }
  .mb-xl-3 { margin-bottom: 16px !important; }
  .ml-xl-3 { margin-left: 16px !important; }
  .mt-xl-n3 { margin-top: -16px !important; }
  .mr-xl-n3 { margin-right: -16px !important; }
  .mb-xl-n3 { margin-bottom: -16px !important; }
  .ml-xl-n3 { margin-left: -16px !important; }
  .mx-xl-3 { margin-left: 16px !important; margin-right: 16px !important; }
  .my-xl-3 { margin-bottom: 16px !important; margin-top: 16px !important; }
  .m-xl-4 { margin: 24px !important; }
  .mt-xl-4 { margin-top: 24px !important; }
  .mr-xl-4 { margin-right: 24px !important; }
  .mb-xl-4 { margin-bottom: 24px !important; }
  .ml-xl-4 { margin-left: 24px !important; }
  .mt-xl-n4 { margin-top: -24px !important; }
  .mr-xl-n4 { margin-right: -24px !important; }
  .mb-xl-n4 { margin-bottom: -24px !important; }
  .ml-xl-n4 { margin-left: -24px !important; }
  .mx-xl-4 { margin-left: 24px !important; margin-right: 24px !important; }
  .my-xl-4 { margin-bottom: 24px !important; margin-top: 24px !important; }
  .m-xl-5 { margin: 32px !important; }
  .mt-xl-5 { margin-top: 32px !important; }
  .mr-xl-5 { margin-right: 32px !important; }
  .mb-xl-5 { margin-bottom: 32px !important; }
  .ml-xl-5 { margin-left: 32px !important; }
  .mt-xl-n5 { margin-top: -32px !important; }
  .mr-xl-n5 { margin-right: -32px !important; }
  .mb-xl-n5 { margin-bottom: -32px !important; }
  .ml-xl-n5 { margin-left: -32px !important; }
  .mx-xl-5 { margin-left: 32px !important; margin-right: 32px !important; }
  .my-xl-5 { margin-bottom: 32px !important; margin-top: 32px !important; }
  .m-xl-6 { margin: 40px !important; }
  .mt-xl-6 { margin-top: 40px !important; }
  .mr-xl-6 { margin-right: 40px !important; }
  .mb-xl-6 { margin-bottom: 40px !important; }
  .ml-xl-6 { margin-left: 40px !important; }
  .mt-xl-n6 { margin-top: -40px !important; }
  .mr-xl-n6 { margin-right: -40px !important; }
  .mb-xl-n6 { margin-bottom: -40px !important; }
  .ml-xl-n6 { margin-left: -40px !important; }
  .mx-xl-6 { margin-left: 40px !important; margin-right: 40px !important; }
  .my-xl-6 { margin-bottom: 40px !important; margin-top: 40px !important; }
  .mx-xl-auto { margin-left: auto !important; margin-right: auto !important; }
}

.p-0 { padding: 0px !important; }

.pt-0 { padding-top: 0px !important; }

.pr-0 { padding-right: 0px !important; }

.pb-0 { padding-bottom: 0px !important; }

.pl-0, .px-0 { padding-left: 0px !important; }

.px-0 { padding-right: 0px !important; }

.py-0 { padding-bottom: 0px !important; padding-top: 0px !important; }

.p-1 { padding: 4px !important; }

.pt-1 { padding-top: 4px !important; }

.pr-1 { padding-right: 4px !important; }

.pb-1 { padding-bottom: 4px !important; }

.pl-1, .px-1 { padding-left: 4px !important; }

.px-1 { padding-right: 4px !important; }

.py-1 { padding-bottom: 4px !important; padding-top: 4px !important; }

.p-2 { padding: 8px !important; }

.pt-2 { padding-top: 8px !important; }

.pr-2 { padding-right: 8px !important; }

.pb-2 { padding-bottom: 8px !important; }

.pl-2, .px-2 { padding-left: 8px !important; }

.px-2 { padding-right: 8px !important; }

.py-2 { padding-bottom: 8px !important; padding-top: 8px !important; }

.p-3 { padding: 16px !important; }

.pt-3 { padding-top: 16px !important; }

.pr-3 { padding-right: 16px !important; }

.pb-3 { padding-bottom: 16px !important; }

.pl-3, .px-3 { padding-left: 16px !important; }

.px-3 { padding-right: 16px !important; }

.py-3 { padding-bottom: 16px !important; padding-top: 16px !important; }

.p-4 { padding: 24px !important; }

.pt-4 { padding-top: 24px !important; }

.pr-4 { padding-right: 24px !important; }

.pb-4 { padding-bottom: 24px !important; }

.pl-4, .px-4 { padding-left: 24px !important; }

.px-4 { padding-right: 24px !important; }

.py-4 { padding-bottom: 24px !important; padding-top: 24px !important; }

.p-5 { padding: 32px !important; }

.pt-5 { padding-top: 32px !important; }

.pr-5 { padding-right: 32px !important; }

.pb-5 { padding-bottom: 32px !important; }

.pl-5, .px-5 { padding-left: 32px !important; }

.px-5 { padding-right: 32px !important; }

.py-5 { padding-bottom: 32px !important; padding-top: 32px !important; }

.p-6 { padding: 40px !important; }

.pt-6 { padding-top: 40px !important; }

.pr-6 { padding-right: 40px !important; }

.pb-6 { padding-bottom: 40px !important; }

.pl-6, .px-6 { padding-left: 40px !important; }

.px-6 { padding-right: 40px !important; }

.py-6 { padding-bottom: 40px !important; padding-top: 40px !important; }

@media (min-width: 544px) {
  .p-sm-0 { padding: 0px !important; }
  .pt-sm-0 { padding-top: 0px !important; }
  .pr-sm-0 { padding-right: 0px !important; }
  .pb-sm-0 { padding-bottom: 0px !important; }
  .pl-sm-0, .px-sm-0 { padding-left: 0px !important; }
  .px-sm-0 { padding-right: 0px !important; }
  .py-sm-0 { padding-bottom: 0px !important; padding-top: 0px !important; }
  .p-sm-1 { padding: 4px !important; }
  .pt-sm-1 { padding-top: 4px !important; }
  .pr-sm-1 { padding-right: 4px !important; }
  .pb-sm-1 { padding-bottom: 4px !important; }
  .pl-sm-1, .px-sm-1 { padding-left: 4px !important; }
  .px-sm-1 { padding-right: 4px !important; }
  .py-sm-1 { padding-bottom: 4px !important; padding-top: 4px !important; }
  .p-sm-2 { padding: 8px !important; }
  .pt-sm-2 { padding-top: 8px !important; }
  .pr-sm-2 { padding-right: 8px !important; }
  .pb-sm-2 { padding-bottom: 8px !important; }
  .pl-sm-2, .px-sm-2 { padding-left: 8px !important; }
  .px-sm-2 { padding-right: 8px !important; }
  .py-sm-2 { padding-bottom: 8px !important; padding-top: 8px !important; }
  .p-sm-3 { padding: 16px !important; }
  .pt-sm-3 { padding-top: 16px !important; }
  .pr-sm-3 { padding-right: 16px !important; }
  .pb-sm-3 { padding-bottom: 16px !important; }
  .pl-sm-3, .px-sm-3 { padding-left: 16px !important; }
  .px-sm-3 { padding-right: 16px !important; }
  .py-sm-3 { padding-bottom: 16px !important; padding-top: 16px !important; }
  .p-sm-4 { padding: 24px !important; }
  .pt-sm-4 { padding-top: 24px !important; }
  .pr-sm-4 { padding-right: 24px !important; }
  .pb-sm-4 { padding-bottom: 24px !important; }
  .pl-sm-4, .px-sm-4 { padding-left: 24px !important; }
  .px-sm-4 { padding-right: 24px !important; }
  .py-sm-4 { padding-bottom: 24px !important; padding-top: 24px !important; }
  .p-sm-5 { padding: 32px !important; }
  .pt-sm-5 { padding-top: 32px !important; }
  .pr-sm-5 { padding-right: 32px !important; }
  .pb-sm-5 { padding-bottom: 32px !important; }
  .pl-sm-5, .px-sm-5 { padding-left: 32px !important; }
  .px-sm-5 { padding-right: 32px !important; }
  .py-sm-5 { padding-bottom: 32px !important; padding-top: 32px !important; }
  .p-sm-6 { padding: 40px !important; }
  .pt-sm-6 { padding-top: 40px !important; }
  .pr-sm-6 { padding-right: 40px !important; }
  .pb-sm-6 { padding-bottom: 40px !important; }
  .pl-sm-6, .px-sm-6 { padding-left: 40px !important; }
  .px-sm-6 { padding-right: 40px !important; }
  .py-sm-6 { padding-bottom: 40px !important; padding-top: 40px !important; }
}

@media (min-width: 768px) {
  .p-md-0 { padding: 0px !important; }
  .pt-md-0 { padding-top: 0px !important; }
  .pr-md-0 { padding-right: 0px !important; }
  .pb-md-0 { padding-bottom: 0px !important; }
  .pl-md-0, .px-md-0 { padding-left: 0px !important; }
  .px-md-0 { padding-right: 0px !important; }
  .py-md-0 { padding-bottom: 0px !important; padding-top: 0px !important; }
  .p-md-1 { padding: 4px !important; }
  .pt-md-1 { padding-top: 4px !important; }
  .pr-md-1 { padding-right: 4px !important; }
  .pb-md-1 { padding-bottom: 4px !important; }
  .pl-md-1, .px-md-1 { padding-left: 4px !important; }
  .px-md-1 { padding-right: 4px !important; }
  .py-md-1 { padding-bottom: 4px !important; padding-top: 4px !important; }
  .p-md-2 { padding: 8px !important; }
  .pt-md-2 { padding-top: 8px !important; }
  .pr-md-2 { padding-right: 8px !important; }
  .pb-md-2 { padding-bottom: 8px !important; }
  .pl-md-2, .px-md-2 { padding-left: 8px !important; }
  .px-md-2 { padding-right: 8px !important; }
  .py-md-2 { padding-bottom: 8px !important; padding-top: 8px !important; }
  .p-md-3 { padding: 16px !important; }
  .pt-md-3 { padding-top: 16px !important; }
  .pr-md-3 { padding-right: 16px !important; }
  .pb-md-3 { padding-bottom: 16px !important; }
  .pl-md-3, .px-md-3 { padding-left: 16px !important; }
  .px-md-3 { padding-right: 16px !important; }
  .py-md-3 { padding-bottom: 16px !important; padding-top: 16px !important; }
  .p-md-4 { padding: 24px !important; }
  .pt-md-4 { padding-top: 24px !important; }
  .pr-md-4 { padding-right: 24px !important; }
  .pb-md-4 { padding-bottom: 24px !important; }
  .pl-md-4, .px-md-4 { padding-left: 24px !important; }
  .px-md-4 { padding-right: 24px !important; }
  .py-md-4 { padding-bottom: 24px !important; padding-top: 24px !important; }
  .p-md-5 { padding: 32px !important; }
  .pt-md-5 { padding-top: 32px !important; }
  .pr-md-5 { padding-right: 32px !important; }
  .pb-md-5 { padding-bottom: 32px !important; }
  .pl-md-5, .px-md-5 { padding-left: 32px !important; }
  .px-md-5 { padding-right: 32px !important; }
  .py-md-5 { padding-bottom: 32px !important; padding-top: 32px !important; }
  .p-md-6 { padding: 40px !important; }
  .pt-md-6 { padding-top: 40px !important; }
  .pr-md-6 { padding-right: 40px !important; }
  .pb-md-6 { padding-bottom: 40px !important; }
  .pl-md-6, .px-md-6 { padding-left: 40px !important; }
  .px-md-6 { padding-right: 40px !important; }
  .py-md-6 { padding-bottom: 40px !important; padding-top: 40px !important; }
}

@media (min-width: 1012px) {
  .p-lg-0 { padding: 0px !important; }
  .pt-lg-0 { padding-top: 0px !important; }
  .pr-lg-0 { padding-right: 0px !important; }
  .pb-lg-0 { padding-bottom: 0px !important; }
  .pl-lg-0, .px-lg-0 { padding-left: 0px !important; }
  .px-lg-0 { padding-right: 0px !important; }
  .py-lg-0 { padding-bottom: 0px !important; padding-top: 0px !important; }
  .p-lg-1 { padding: 4px !important; }
  .pt-lg-1 { padding-top: 4px !important; }
  .pr-lg-1 { padding-right: 4px !important; }
  .pb-lg-1 { padding-bottom: 4px !important; }
  .pl-lg-1, .px-lg-1 { padding-left: 4px !important; }
  .px-lg-1 { padding-right: 4px !important; }
  .py-lg-1 { padding-bottom: 4px !important; padding-top: 4px !important; }
  .p-lg-2 { padding: 8px !important; }
  .pt-lg-2 { padding-top: 8px !important; }
  .pr-lg-2 { padding-right: 8px !important; }
  .pb-lg-2 { padding-bottom: 8px !important; }
  .pl-lg-2, .px-lg-2 { padding-left: 8px !important; }
  .px-lg-2 { padding-right: 8px !important; }
  .py-lg-2 { padding-bottom: 8px !important; padding-top: 8px !important; }
  .p-lg-3 { padding: 16px !important; }
  .pt-lg-3 { padding-top: 16px !important; }
  .pr-lg-3 { padding-right: 16px !important; }
  .pb-lg-3 { padding-bottom: 16px !important; }
  .pl-lg-3, .px-lg-3 { padding-left: 16px !important; }
  .px-lg-3 { padding-right: 16px !important; }
  .py-lg-3 { padding-bottom: 16px !important; padding-top: 16px !important; }
  .p-lg-4 { padding: 24px !important; }
  .pt-lg-4 { padding-top: 24px !important; }
  .pr-lg-4 { padding-right: 24px !important; }
  .pb-lg-4 { padding-bottom: 24px !important; }
  .pl-lg-4, .px-lg-4 { padding-left: 24px !important; }
  .px-lg-4 { padding-right: 24px !important; }
  .py-lg-4 { padding-bottom: 24px !important; padding-top: 24px !important; }
  .p-lg-5 { padding: 32px !important; }
  .pt-lg-5 { padding-top: 32px !important; }
  .pr-lg-5 { padding-right: 32px !important; }
  .pb-lg-5 { padding-bottom: 32px !important; }
  .pl-lg-5, .px-lg-5 { padding-left: 32px !important; }
  .px-lg-5 { padding-right: 32px !important; }
  .py-lg-5 { padding-bottom: 32px !important; padding-top: 32px !important; }
  .p-lg-6 { padding: 40px !important; }
  .pt-lg-6 { padding-top: 40px !important; }
  .pr-lg-6 { padding-right: 40px !important; }
  .pb-lg-6 { padding-bottom: 40px !important; }
  .pl-lg-6, .px-lg-6 { padding-left: 40px !important; }
  .px-lg-6 { padding-right: 40px !important; }
  .py-lg-6 { padding-bottom: 40px !important; padding-top: 40px !important; }
}

@media (min-width: 1280px) {
  .p-xl-0 { padding: 0px !important; }
  .pt-xl-0 { padding-top: 0px !important; }
  .pr-xl-0 { padding-right: 0px !important; }
  .pb-xl-0 { padding-bottom: 0px !important; }
  .pl-xl-0, .px-xl-0 { padding-left: 0px !important; }
  .px-xl-0 { padding-right: 0px !important; }
  .py-xl-0 { padding-bottom: 0px !important; padding-top: 0px !important; }
  .p-xl-1 { padding: 4px !important; }
  .pt-xl-1 { padding-top: 4px !important; }
  .pr-xl-1 { padding-right: 4px !important; }
  .pb-xl-1 { padding-bottom: 4px !important; }
  .pl-xl-1, .px-xl-1 { padding-left: 4px !important; }
  .px-xl-1 { padding-right: 4px !important; }
  .py-xl-1 { padding-bottom: 4px !important; padding-top: 4px !important; }
  .p-xl-2 { padding: 8px !important; }
  .pt-xl-2 { padding-top: 8px !important; }
  .pr-xl-2 { padding-right: 8px !important; }
  .pb-xl-2 { padding-bottom: 8px !important; }
  .pl-xl-2, .px-xl-2 { padding-left: 8px !important; }
  .px-xl-2 { padding-right: 8px !important; }
  .py-xl-2 { padding-bottom: 8px !important; padding-top: 8px !important; }
  .p-xl-3 { padding: 16px !important; }
  .pt-xl-3 { padding-top: 16px !important; }
  .pr-xl-3 { padding-right: 16px !important; }
  .pb-xl-3 { padding-bottom: 16px !important; }
  .pl-xl-3, .px-xl-3 { padding-left: 16px !important; }
  .px-xl-3 { padding-right: 16px !important; }
  .py-xl-3 { padding-bottom: 16px !important; padding-top: 16px !important; }
  .p-xl-4 { padding: 24px !important; }
  .pt-xl-4 { padding-top: 24px !important; }
  .pr-xl-4 { padding-right: 24px !important; }
  .pb-xl-4 { padding-bottom: 24px !important; }
  .pl-xl-4, .px-xl-4 { padding-left: 24px !important; }
  .px-xl-4 { padding-right: 24px !important; }
  .py-xl-4 { padding-bottom: 24px !important; padding-top: 24px !important; }
  .p-xl-5 { padding: 32px !important; }
  .pt-xl-5 { padding-top: 32px !important; }
  .pr-xl-5 { padding-right: 32px !important; }
  .pb-xl-5 { padding-bottom: 32px !important; }
  .pl-xl-5, .px-xl-5 { padding-left: 32px !important; }
  .px-xl-5 { padding-right: 32px !important; }
  .py-xl-5 { padding-bottom: 32px !important; padding-top: 32px !important; }
  .p-xl-6 { padding: 40px !important; }
  .pt-xl-6 { padding-top: 40px !important; }
  .pr-xl-6 { padding-right: 40px !important; }
  .pb-xl-6 { padding-bottom: 40px !important; }
  .pl-xl-6, .px-xl-6 { padding-left: 40px !important; }
  .px-xl-6 { padding-right: 40px !important; }
  .py-xl-6 { padding-bottom: 40px !important; padding-top: 40px !important; }
}

.p-responsive { padding-left: 16px !important; padding-right: 16px !important; }

@media (min-width: 544px) {
  .p-responsive { padding-left: 40px !important; padding-right: 40px !important; }
}

@media (min-width: 1012px) {
  .p-responsive { padding-left: 16px !important; padding-right: 16px !important; }
}

.h1 { font-size: 26px !important; }

@media (min-width: 768px) {
  .h1 { font-size: 32px !important; }
}

.h2 { font-size: 22px !important; }

@media (min-width: 768px) {
  .h2 { font-size: 24px !important; }
}

.h3 { font-size: 18px !important; }

@media (min-width: 768px) {
  .h3 { font-size: 20px !important; }
}

.h4 { font-size: 16px !important; }

.h5 { font-size: 14px !important; }

.h6 { font-size: 12px !important; }

.h1, .h2, .h3, .h4, .h5, .h6 { font-weight: 600 !important; }

.f1 { font-size: 26px !important; }

@media (min-width: 768px) {
  .f1 { font-size: 32px !important; }
}

.f2 { font-size: 22px !important; }

@media (min-width: 768px) {
  .f2 { font-size: 24px !important; }
}

.f3 { font-size: 18px !important; }

@media (min-width: 768px) {
  .f3 { font-size: 20px !important; }
}

.f4 { font-size: 16px !important; }

@media (min-width: 768px) {
  .f4 { font-size: 16px !important; }
}

.f5 { font-size: 14px !important; }

.f6 { font-size: 12px !important; }

.f00-light { font-size: 40px !important; font-weight: 300 !important; }

@media (min-width: 768px) {
  .f00-light { font-size: 48px !important; }
}

.f0-light { font-size: 32px !important; font-weight: 300 !important; }

@media (min-width: 768px) {
  .f0-light { font-size: 40px !important; }
}

.f1-light { font-size: 26px !important; font-weight: 300 !important; }

@media (min-width: 768px) {
  .f1-light { font-size: 32px !important; }
}

.f2-light { font-size: 22px !important; font-weight: 300 !important; }

@media (min-width: 768px) {
  .f2-light { font-size: 24px !important; }
}

.f3-light { font-size: 18px !important; font-weight: 300 !important; }

@media (min-width: 768px) {
  .f3-light { font-size: 20px !important; }
}

.text-small { font-size: 12px !important; }

.lead { color: rgb(88, 96, 105); font-size: 20px; font-weight: 300; margin-bottom: 30px; }

.lh-condensed-ultra { line-height: 1 !important; }

.lh-condensed { line-height: 1.25 !important; }

.lh-default { line-height: 1.5 !important; }

.lh-0 { line-height: 0 !important; }

.text-right { text-align: right !important; }

.text-left { text-align: left !important; }

.text-center { text-align: center !important; }

@media (min-width: 544px) {
  .text-sm-right { text-align: right !important; }
  .text-sm-left { text-align: left !important; }
  .text-sm-center { text-align: center !important; }
}

@media (min-width: 768px) {
  .text-md-right { text-align: right !important; }
  .text-md-left { text-align: left !important; }
  .text-md-center { text-align: center !important; }
}

@media (min-width: 1012px) {
  .text-lg-right { text-align: right !important; }
  .text-lg-left { text-align: left !important; }
  .text-lg-center { text-align: center !important; }
}

@media (min-width: 1280px) {
  .text-xl-right { text-align: right !important; }
  .text-xl-left { text-align: left !important; }
  .text-xl-center { text-align: center !important; }
}

.text-normal { font-weight: 400 !important; }

.text-bold { font-weight: 600 !important; }

.text-italic { font-style: italic !important; }

.text-uppercase { text-transform: uppercase !important; }

.text-underline { text-decoration: underline !important; }

.no-underline { text-decoration: none !important; }

.no-wrap { white-space: nowrap !important; }

.ws-normal { white-space: normal !important; }

.wb-break-all { word-break: break-all !important; }

.text-emphasized { color: rgb(36, 41, 46); font-weight: 600; }

.list-style-none { list-style: none !important; }

.text-shadow-dark { text-shadow: rgba(27, 31, 35, 0.25) 0px 1px 1px, rgba(27, 31, 35, 0.75) 0px 1px 25px; }

.text-shadow-light { text-shadow: rgba(255, 255, 255, 0.5) 0px 1px 0px; }

.text-mono { font-family: SFMono-Regular, Consolas, "Liberation Mono", Menlo, Courier, monospace; }

.user-select-none { user-select: none !important; }

.d-block { display: block !important; }

.d-flex { display: flex !important; }

.d-inline { display: inline !important; }

.d-inline-block { display: inline-block !important; }

.d-inline-flex { display: inline-flex !important; }

.d-none { display: none !important; }

.d-table { display: table !important; }

.d-table-cell { display: table-cell !important; }

@media (min-width: 544px) {
  .d-sm-block { display: block !important; }
  .d-sm-flex { display: flex !important; }
  .d-sm-inline { display: inline !important; }
  .d-sm-inline-block { display: inline-block !important; }
  .d-sm-inline-flex { display: inline-flex !important; }
  .d-sm-none { display: none !important; }
  .d-sm-table { display: table !important; }
  .d-sm-table-cell { display: table-cell !important; }
}

@media (min-width: 768px) {
  .d-md-block { display: block !important; }
  .d-md-flex { display: flex !important; }
  .d-md-inline { display: inline !important; }
  .d-md-inline-block { display: inline-block !important; }
  .d-md-inline-flex { display: inline-flex !important; }
  .d-md-none { display: none !important; }
  .d-md-table { display: table !important; }
  .d-md-table-cell { display: table-cell !important; }
}

@media (min-width: 1012px) {
  .d-lg-block { display: block !important; }
  .d-lg-flex { display: flex !important; }
  .d-lg-inline { display: inline !important; }
  .d-lg-inline-block { display: inline-block !important; }
  .d-lg-inline-flex { display: inline-flex !important; }
  .d-lg-none { display: none !important; }
  .d-lg-table { display: table !important; }
  .d-lg-table-cell { display: table-cell !important; }
}

@media (min-width: 1280px) {
  .d-xl-block { display: block !important; }
  .d-xl-flex { display: flex !important; }
  .d-xl-inline { display: inline !important; }
  .d-xl-inline-block { display: inline-block !important; }
  .d-xl-inline-flex { display: inline-flex !important; }
  .d-xl-none { display: none !important; }
  .d-xl-table { display: table !important; }
  .d-xl-table-cell { display: table-cell !important; }
}

.v-hidden { visibility: hidden !important; }

.v-visible { visibility: visible !important; }

@media (max-width: 544px) {
  .hide-sm { display: none !important; }
}

@media (max-width: 768px) and (min-width: 544px) {
  .hide-md { display: none !important; }
}

@media (max-width: 1012px) and (min-width: 768px) {
  .hide-lg { display: none !important; }
}

@media (min-width: 1012px) {
  .hide-xl { display: none !important; }
}

.table-fixed { table-layout: fixed !important; }

.sr-only { border: 0px; clip: rect(0px, 0px, 0px, 0px); padding: 0px; overflow-wrap: normal; }

.show-on-focus, .sr-only { height: 1px; overflow: hidden; position: absolute; width: 1px; }

.show-on-focus { clip: rect(1px, 1px, 1px, 1px); margin: 0px; }

.show-on-focus:focus { clip: auto; height: auto; width: auto; z-index: 20; }

.col-1 { width: 8.33333%; }

.col-2 { width: 16.6667%; }

.col-3 { width: 25%; }

.col-4 { width: 33.3333%; }

.col-5 { width: 41.6667%; }

.col-6 { width: 50%; }

.col-7 { width: 58.3333%; }

.col-8 { width: 66.6667%; }

.col-9 { width: 75%; }

.col-10 { width: 83.3333%; }

.col-11 { width: 91.6667%; }

.col-12 { width: 100%; }

@media (min-width: 544px) {
  .col-sm-1 { width: 8.33333%; }
  .col-sm-2 { width: 16.6667%; }
  .col-sm-3 { width: 25%; }
  .col-sm-4 { width: 33.3333%; }
  .col-sm-5 { width: 41.6667%; }
  .col-sm-6 { width: 50%; }
  .col-sm-7 { width: 58.3333%; }
  .col-sm-8 { width: 66.6667%; }
  .col-sm-9 { width: 75%; }
  .col-sm-10 { width: 83.3333%; }
  .col-sm-11 { width: 91.6667%; }
  .col-sm-12 { width: 100%; }
}

@media (min-width: 768px) {
  .col-md-1 { width: 8.33333%; }
  .col-md-2 { width: 16.6667%; }
  .col-md-3 { width: 25%; }
  .col-md-4 { width: 33.3333%; }
  .col-md-5 { width: 41.6667%; }
  .col-md-6 { width: 50%; }
  .col-md-7 { width: 58.3333%; }
  .col-md-8 { width: 66.6667%; }
  .col-md-9 { width: 75%; }
  .col-md-10 { width: 83.3333%; }
  .col-md-11 { width: 91.6667%; }
  .col-md-12 { width: 100%; }
}

@media (min-width: 1012px) {
  .col-lg-1 { width: 8.33333%; }
  .col-lg-2 { width: 16.6667%; }
  .col-lg-3 { width: 25%; }
  .col-lg-4 { width: 33.3333%; }
  .col-lg-5 { width: 41.6667%; }
  .col-lg-6 { width: 50%; }
  .col-lg-7 { width: 58.3333%; }
  .col-lg-8 { width: 66.6667%; }
  .col-lg-9 { width: 75%; }
  .col-lg-10 { width: 83.3333%; }
  .col-lg-11 { width: 91.6667%; }
  .col-lg-12 { width: 100%; }
}

@media (min-width: 1280px) {
  .col-xl-1 { width: 8.33333%; }
  .col-xl-2 { width: 16.6667%; }
  .col-xl-3 { width: 25%; }
  .col-xl-4 { width: 33.3333%; }
  .col-xl-5 { width: 41.6667%; }
  .col-xl-6 { width: 50%; }
  .col-xl-7 { width: 58.3333%; }
  .col-xl-8 { width: 66.6667%; }
  .col-xl-9 { width: 75%; }
  .col-xl-10 { width: 83.3333%; }
  .col-xl-11 { width: 91.6667%; }
  .col-xl-12 { width: 100%; }
}

.gutter { margin-left: -16px; margin-right: -16px; }

.gutter > [class*="col-"] { padding-left: 16px !important; padding-right: 16px !important; }

.gutter-condensed { margin-left: -8px; margin-right: -8px; }

.gutter-condensed > [class*="col-"] { padding-left: 8px !important; padding-right: 8px !important; }

.gutter-spacious { margin-left: -24px; margin-right: -24px; }

.gutter-spacious > [class*="col-"] { padding-left: 24px !important; padding-right: 24px !important; }

@media (min-width: 544px) {
  .gutter-sm { margin-left: -16px; margin-right: -16px; }
  .gutter-sm > [class*="col-"] { padding-left: 16px !important; padding-right: 16px !important; }
  .gutter-sm-condensed { margin-left: -8px; margin-right: -8px; }
  .gutter-sm-condensed > [class*="col-"] { padding-left: 8px !important; padding-right: 8px !important; }
  .gutter-sm-spacious { margin-left: -24px; margin-right: -24px; }
  .gutter-sm-spacious > [class*="col-"] { padding-left: 24px !important; padding-right: 24px !important; }
}

@media (min-width: 768px) {
  .gutter-md { margin-left: -16px; margin-right: -16px; }
  .gutter-md > [class*="col-"] { padding-left: 16px !important; padding-right: 16px !important; }
  .gutter-md-condensed { margin-left: -8px; margin-right: -8px; }
  .gutter-md-condensed > [class*="col-"] { padding-left: 8px !important; padding-right: 8px !important; }
  .gutter-md-spacious { margin-left: -24px; margin-right: -24px; }
  .gutter-md-spacious > [class*="col-"] { padding-left: 24px !important; padding-right: 24px !important; }
}

@media (min-width: 1012px) {
  .gutter-lg { margin-left: -16px; margin-right: -16px; }
  .gutter-lg > [class*="col-"] { padding-left: 16px !important; padding-right: 16px !important; }
  .gutter-lg-condensed { margin-left: -8px; margin-right: -8px; }
  .gutter-lg-condensed > [class*="col-"] { padding-left: 8px !important; padding-right: 8px !important; }
  .gutter-lg-spacious { margin-left: -24px; margin-right: -24px; }
  .gutter-lg-spacious > [class*="col-"] { padding-left: 24px !important; padding-right: 24px !important; }
}

@media (min-width: 1280px) {
  .gutter-xl { margin-left: -16px; margin-right: -16px; }
  .gutter-xl > [class*="col-"] { padding-left: 16px !important; padding-right: 16px !important; }
  .gutter-xl-condensed { margin-left: -8px; margin-right: -8px; }
  .gutter-xl-condensed > [class*="col-"] { padding-left: 8px !important; padding-right: 8px !important; }
  .gutter-xl-spacious { margin-left: -24px; margin-right: -24px; }
  .gutter-xl-spacious > [class*="col-"] { padding-left: 24px !important; padding-right: 24px !important; }
}

fieldset { border: 0px; margin: 0px; padding: 0px; }

label { font-weight: 600; }

.form-control, .form-select { background-color: rgb(255, 255, 255); background-position: right 8px center; background-repeat: no-repeat; border: 1px solid rgb(209, 213, 218); border-radius: 3px; box-shadow: rgba(27, 31, 35, 0.075) 0px 1px 2px inset; color: rgb(36, 41, 46); font-size: 16px; line-height: 20px; min-height: 34px; outline: none; padding: 6px 8px; vertical-align: middle; }

.form-control.focus, .form-control:focus, .form-select.focus, .form-select:focus { border-color: rgb(33, 136, 255); box-shadow: rgba(27, 31, 35, 0.075) 0px 1px 2px inset, rgba(3, 102, 214, 0.3) 0px 0px 0px 0.2em; outline: none; }

@media (min-width: 768px) {
  .form-control, .form-select { font-size: 14px; }
}

.input-contrast { background-color: rgb(250, 251, 252); }

.input-contrast:focus { background-color: rgb(255, 255, 255); }

::placeholder { color: rgb(106, 115, 125); }

.input-sm { font-size: 12px; line-height: 20px; min-height: 28px; padding-bottom: 3px; padding-top: 3px; }

.input-lg { font-size: 16px; padding: 4px 10px; }

.input-block { display: block; width: 100%; }

.input-monospace { font-family: SFMono-Regular, Consolas, "Liberation Mono", Menlo, Courier, monospace; }

.input-hide-webkit-autofill::-webkit-contacts-auto-fill-button { pointer-events: none; position: absolute; right: 0px; visibility: hidden; display: none !important; }

.form-checkbox { margin: 15px 0px; padding-left: 20px; vertical-align: middle; }

.form-checkbox label em.highlight { background: rgb(255, 251, 221); border-radius: 3px; font-style: normal; left: -4px; padding: 2px 4px; position: relative; }

.form-checkbox input[type="checkbox"], .form-checkbox input[type="radio"] { float: left; margin: 5px 0px 0px -20px; vertical-align: middle; }

.form-checkbox .note { color: rgb(88, 96, 105); display: block; font-size: 12px; font-weight: 400; margin: 0px; }

.form-checkbox-details { display: none; }

.form-checkbox-details-trigger:checked ~ * .form-checkbox-details, .form-checkbox-details-trigger:checked ~ .form-checkbox-details { display: block; }

.hfields { margin: 15px 0px; }

.hfields::after, .hfields::before { content: ""; display: table; }

.hfields::after { clear: both; }

.hfields .form-group { float: left; margin: 0px 30px 0px 0px; }

.hfields .form-group dt label { color: rgb(88, 96, 105); display: inline-block; margin: 5px 0px 0px; }

.hfields .form-group dt img { position: relative; top: -2px; }

.hfields .btn { float: left; margin: 28px 25px 0px -20px; }

.hfields .form-select { margin-top: 5px; }

input::-webkit-inner-spin-button, input::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0px; }

.form-actions::after, .form-actions::before { content: ""; display: table; }

.form-actions::after { clear: both; }

.form-actions .btn { float: right; }

.form-actions .btn + .btn { margin-right: 5px; }

.form-warning { background: rgb(255, 251, 221); border: 1px solid rgb(217, 208, 165); border-radius: 3px; color: rgb(115, 92, 15); font-size: 14px; margin: 10px 0px; padding: 8px 10px; }

.form-warning p { line-height: 1.5; margin: 0px; }

.form-warning a { font-weight: 600; }

.form-select { -webkit-appearance: none; background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAUCAMAAACzvE1FAAAADFBMVEUzMzMzMzMzMzMzMzMKAG/3AAAAA3RSTlMAf4C/aSLHAAAAPElEQVR42q3NMQ4AIAgEQTn//2cLdRKppSGzBYwzVXvznNWs8C58CiussPJj8h6NwgorrKRdTvuV9v16Afn0AYFOB7aYAAAAAElFTkSuQmCC") right 8px center / 8px 10px no-repeat rgb(255, 255, 255); display: inline-block; height: 34px; max-width: 100%; padding-right: 24px; }

.form-select[multiple] { height: auto; }

.select-sm { font-size: 12px; height: 28px; min-height: 28px; padding-bottom: 3px; padding-top: 3px; }

.select-sm[multiple] { height: auto; min-height: 0px; }

.form-group { margin: 15px 0px; }

.form-group .form-control { background-color: rgb(250, 251, 252); margin-right: 5px; max-width: 100%; width: 440px; }

.form-group .form-control:focus { background-color: rgb(255, 255, 255); }

.form-group .form-control.shorter { width: 130px; }

.form-group .form-control.short { width: 250px; }

.form-group .form-control.long { width: 100%; }

.form-group textarea.form-control { height: 200px; min-height: 200px; width: 100%; }

.form-group textarea.form-control.short { height: 50px; min-height: 50px; }

.form-group dt { margin: 0px 0px 6px; }

.form-group label { position: relative; }

.form-group.flattened dt { float: left; line-height: 32px; margin: 0px; }

.form-group.flattened dd { line-height: 32px; }

.form-group dd h4 { margin: 4px 0px 0px; }

.form-group dd h4.is-error { color: rgb(203, 36, 49); }

.form-group dd h4.is-success { color: rgb(40, 167, 69); }

.form-group dd h4 + .note { margin-top: 0px; }

.form-group.required dt label::after { color: rgb(203, 36, 49); content: "*"; padding-left: 5px; }

.form-group .error, .form-group .indicator, .form-group .success { display: none; font-size: 12px; font-weight: 600; }

.form-group.loading { opacity: 0.5; }

.form-group.loading .indicator { display: inline; }

.form-group.loading .spinner { display: inline-block; vertical-align: middle; }

.form-group.successful .success { color: rgb(40, 167, 69); display: inline; }

.form-group.errored .error, .form-group.errored .warning, .form-group.warn .error, .form-group.warn .warning { border-radius: 3px; border-style: solid; border-width: 1px; display: block; font-size: 13px; font-weight: 400; margin: 4px 0px 0px; max-width: 450px; padding: 5px 8px; position: absolute; z-index: 10; }

.form-group.errored .error::after, .form-group.errored .error::before, .form-group.errored .warning::after, .form-group.errored .warning::before, .form-group.warn .error::after, .form-group.warn .error::before, .form-group.warn .warning::after, .form-group.warn .warning::before { border: solid transparent; bottom: 100%; content: " "; height: 0px; left: 10px; pointer-events: none; position: absolute; width: 0px; z-index: 15; }

.form-group.errored .error::after, .form-group.errored .warning::after, .form-group.warn .error::after, .form-group.warn .warning::after { border-width: 5px; }

.form-group.errored .error::before, .form-group.errored .warning::before, .form-group.warn .error::before, .form-group.warn .warning::before { border-width: 6px; margin-left: -1px; }

.form-group.warn .warning { background-color: rgb(255, 251, 221); border-color: rgb(217, 208, 165); color: rgb(115, 92, 15); }

.form-group.warn .warning::after { border-bottom-color: rgb(255, 251, 221); }

.form-group.warn .warning::before { border-bottom-color: rgb(217, 208, 165); }

.form-group.errored label { color: rgb(203, 36, 49); }

.form-group.errored .error { background-color: rgb(255, 220, 224); border-color: rgb(206, 160, 165); color: rgb(134, 24, 29); }

.form-group.errored .error::after { border-bottom-color: rgb(255, 220, 224); }

.form-group.errored .error::before { border-bottom-color: rgb(206, 160, 165); }

.note { color: rgb(88, 96, 105); font-size: 12px; margin: 4px 0px 2px; min-height: 17px; }

.note .spinner { margin-right: 3px; vertical-align: middle; }

.css-truncate.css-truncate-target, .css-truncate .css-truncate-target { display: inline-block; max-width: 125px; overflow: hidden; text-overflow: ellipsis; vertical-align: top; white-space: nowrap; }

.css-truncate.expandable.zeroclipboard-is-hover.css-truncate-target, .css-truncate.expandable.zeroclipboard-is-hover .css-truncate-target, .css-truncate.expandable:hover.css-truncate-target, .css-truncate.expandable:hover .css-truncate-target { max-width: 10000px !important; }

.TableObject { display: table; }

.TableObject-item { display: table-cell; vertical-align: middle; white-space: nowrap; width: 1%; }

.TableObject-item--primary { width: 99%; }

.label, .Label { border-radius: 2px; box-shadow: rgba(27, 31, 35, 0.12) 0px -1px 0px inset; color: rgb(255, 255, 255); display: inline-block; font-size: 12px; font-weight: 600; line-height: 1; padding: 3px 4px; }

.label:hover, .Label:hover { text-decoration: none; }

.Label--gray { background-color: rgb(234, 236, 239); color: rgb(88, 96, 105); }

.Label--outline { background-color: initial; border: 1px solid rgba(27, 31, 35, 0.15); box-shadow: none; color: rgb(88, 96, 105); font-weight: 400; margin-bottom: -1px; margin-top: -1px; }

.Label--outline-green { border: 1px solid rgb(52, 208, 88); color: rgb(40, 167, 69); }

.Label--gray-darker { background-color: rgb(106, 115, 125); }

.Label--orange { background-color: rgb(209, 87, 4); }

.state, .State { background-color: rgb(106, 115, 125); border-radius: 3px; color: rgb(255, 255, 255); display: inline-block; font-weight: 600; line-height: 20px; padding: 4px 8px; text-align: center; }

.State--green { background-color: rgb(44, 190, 78); }

.State--purple { background-color: rgb(111, 66, 193); }

.State--red { background-color: rgb(203, 36, 49); }

.State--small { font-size: 12px; padding: 0.125em 4px; }

.State--small .octicon { width: 1em; }

.Counter { background-color: rgba(27, 31, 35, 0.08); border-radius: 20px; color: rgb(88, 96, 105); display: inline-block; font-size: 12px; font-weight: 600; line-height: 1; padding: 2px 5px; }

.Counter:empty { visibility: hidden; }

.Counter--gray-light { background-color: rgba(27, 31, 35, 0.15); color: rgb(36, 41, 46); }

.Counter--gray { background-color: rgb(106, 115, 125); color: rgb(255, 255, 255); }

.avatar { border-radius: 3px; display: inline-block; line-height: 1; overflow: hidden; vertical-align: middle; }

.avatar-small { border-radius: 2px; }

.avatar-link { float: left; line-height: 1; }

.avatar-group-item { display: inline-block; margin-bottom: 3px; }

.avatar-parent-child { position: relative; }

.avatar-child { background-color: rgb(255, 255, 255); border-radius: 2px; bottom: -9%; box-shadow: rgba(255, 255, 255, 0.8) -2px -2px 0px; position: absolute; right: -15%; }

.subnav { margin-bottom: 20px; }

.subnav::after, .subnav::before { content: ""; display: table; }

.subnav::after { clear: both; }

.subnav-bordered { border-bottom: 1px solid rgb(234, 236, 239); padding-bottom: 20px; }

.subnav-flush { margin-bottom: 0px; }

.subnav-item { border: 1px solid rgb(225, 228, 232); color: rgb(88, 96, 105); float: left; font-weight: 600; line-height: 20px; padding: 6px 14px; position: relative; }

.subnav-item + .subnav-item { margin-left: -1px; }

.subnav-item:focus, .subnav-item:hover { background-color: rgb(246, 248, 250); text-decoration: none; }

.subnav-item.selected, .subnav-item.selected:focus, .subnav-item.selected:hover { background-color: rgb(3, 102, 214); border-color: rgb(3, 102, 214); color: rgb(255, 255, 255); z-index: 2; }

.subnav-item:first-child { border-bottom-left-radius: 3px; border-top-left-radius: 3px; }

.subnav-item:last-child { border-bottom-right-radius: 3px; border-top-right-radius: 3px; }

.subnav-search { margin-left: 10px; position: relative; }

.subnav-search-input { color: rgb(88, 96, 105); padding-left: 30px; width: 320px; }

.subnav-search-input-wide { width: 500px; }

.subnav-search-icon { color: rgb(198, 203, 209); display: block; left: 8px; pointer-events: none; position: absolute; text-align: center; top: 9px; }

.subnav-search-context .btn { border-bottom-right-radius: 0px; border-top-right-radius: 0px; color: rgb(68, 77, 86); }

.subnav-search-context .btn.selected, .subnav-search-context .btn:active, .subnav-search-context .btn:focus, .subnav-search-context .btn:hover { z-index: 2; }

.subnav-search-context + .subnav-search { margin-left: -1px; }

.subnav-search-context + .subnav-search .subnav-search-input { border-bottom-left-radius: 0px; border-top-left-radius: 0px; }

.subnav-search-context .select-menu-modal-holder { z-index: 30; }

.subnav-search-context .select-menu-modal { width: 220px; }

.subnav-search-context .select-menu-item-icon { color: inherit; }

.subnav-spacer-right { padding-right: 10px; }

.markdown-body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"; font-size: 16px; line-height: 1.5; overflow-wrap: break-word; }

.markdown-body::after, .markdown-body::before { content: ""; display: table; }

.markdown-body::after { clear: both; }

.markdown-body > :first-child { margin-top: 0px !important; }

.markdown-body > :last-child { margin-bottom: 0px !important; }

.markdown-body a:not([href]) { color: inherit; text-decoration: none; }

.markdown-body .absent { color: rgb(203, 36, 49); }

.markdown-body .anchor { float: left; line-height: 1; margin-left: -20px; padding-right: 4px; }

.markdown-body .anchor:focus { outline: none; }

.markdown-body blockquote, .markdown-body dl, .markdown-body ol, .markdown-body p, .markdown-body pre, .markdown-body table, .markdown-body ul { margin-bottom: 16px; margin-top: 0px; }

.markdown-body hr { background-color: rgb(225, 228, 232); border: 0px; height: 0.25em; margin: 24px 0px; padding: 0px; }

.markdown-body blockquote { border-left: 0.25em solid rgb(223, 226, 229); color: rgb(106, 115, 125); padding: 0px 1em; }

.markdown-body blockquote > :first-child { margin-top: 0px; }

.markdown-body blockquote > :last-child { margin-bottom: 0px; }

.markdown-body kbd { background-color: rgb(250, 251, 252); border-width: 1px; border-style: solid; border-color: rgb(198, 203, 209) rgb(198, 203, 209) rgb(149, 157, 165); border-image: initial; border-radius: 3px; box-shadow: rgb(149, 157, 165) 0px -1px 0px inset; color: rgb(68, 77, 86); display: inline-block; font-size: 11px; line-height: 10px; padding: 3px 5px; vertical-align: middle; }

.markdown-body h1, .markdown-body h2, .markdown-body h3, .markdown-body h4, .markdown-body h5, .markdown-body h6 { font-weight: 600; line-height: 1.25; margin-bottom: 16px; margin-top: 24px; }

.markdown-body h1 .octicon-link, .markdown-body h2 .octicon-link, .markdown-body h3 .octicon-link, .markdown-body h4 .octicon-link, .markdown-body h5 .octicon-link, .markdown-body h6 .octicon-link { color: rgb(27, 31, 35); vertical-align: middle; visibility: hidden; }

.markdown-body h1:hover .anchor, .markdown-body h2:hover .anchor, .markdown-body h3:hover .anchor, .markdown-body h4:hover .anchor, .markdown-body h5:hover .anchor, .markdown-body h6:hover .anchor { text-decoration: none; }

.markdown-body h1:hover .anchor .octicon-link, .markdown-body h2:hover .anchor .octicon-link, .markdown-body h3:hover .anchor .octicon-link, .markdown-body h4:hover .anchor .octicon-link, .markdown-body h5:hover .anchor .octicon-link, .markdown-body h6:hover .anchor .octicon-link { visibility: visible; }

.markdown-body h1 code, .markdown-body h1 tt, .markdown-body h2 code, .markdown-body h2 tt, .markdown-body h3 code, .markdown-body h3 tt, .markdown-body h4 code, .markdown-body h4 tt, .markdown-body h5 code, .markdown-body h5 tt, .markdown-body h6 code, .markdown-body h6 tt { font-size: inherit; }

.markdown-body h1 { font-size: 2em; }

.markdown-body h1, .markdown-body h2 { border-bottom: 1px solid rgb(234, 236, 239); padding-bottom: 0.3em; }

.markdown-body h2 { font-size: 1.5em; }

.markdown-body h3 { font-size: 1.25em; }

.markdown-body h4 { font-size: 1em; }

.markdown-body h5 { font-size: 0.875em; }

.markdown-body h6 { color: rgb(106, 115, 125); font-size: 0.85em; }

.markdown-body ol, .markdown-body ul { padding-left: 2em; }

.markdown-body ol.no-list, .markdown-body ul.no-list { list-style-type: none; padding: 0px; }

.markdown-body ol ol, .markdown-body ol ul, .markdown-body ul ol, .markdown-body ul ul { margin-bottom: 0px; margin-top: 0px; }

.markdown-body li { }

.markdown-body li > p { margin-top: 16px; }

.markdown-body li + li { margin-top: 0.25em; }

.markdown-body dl { padding: 0px; }

.markdown-body dl dt { font-size: 1em; font-style: italic; font-weight: 600; margin-top: 16px; padding: 0px; }

.markdown-body dl dd { margin-bottom: 16px; padding: 0px 16px; }

.markdown-body table { display: block; overflow: auto; width: 100%; }

.markdown-body table th { font-weight: 600; }

.markdown-body table td, .markdown-body table th { border: 1px solid rgb(223, 226, 229); padding: 6px 13px; }

.markdown-body table tr { background-color: rgb(255, 255, 255); border-top: 1px solid rgb(198, 203, 209); }

.markdown-body table tr:nth-child(2n) { background-color: rgb(246, 248, 250); }

.markdown-body table img { background-color: initial; }

.markdown-body img { background-color: rgb(255, 255, 255); box-sizing: initial; max-width: 100%; }

.markdown-body img[align="right"] { padding-left: 20px; }

.markdown-body img[align="left"] { padding-right: 20px; }

.markdown-body .emoji { background-color: initial; max-width: none; vertical-align: text-top; }

.markdown-body span.frame { display: block; overflow: hidden; }

.markdown-body span.frame > span { border: 1px solid rgb(223, 226, 229); display: block; float: left; margin: 13px 0px 0px; overflow: hidden; padding: 7px; width: auto; }

.markdown-body span.frame span img { display: block; float: left; }

.markdown-body span.frame span span { clear: both; color: rgb(36, 41, 46); display: block; padding: 5px 0px 0px; }

.markdown-body span.align-center { clear: both; display: block; overflow: hidden; }

.markdown-body span.align-center > span { display: block; margin: 13px auto 0px; overflow: hidden; text-align: center; }

.markdown-body span.align-center span img { margin: 0px auto; text-align: center; }

.markdown-body span.align-right { clear: both; display: block; overflow: hidden; }

.markdown-body span.align-right > span { display: block; margin: 13px 0px 0px; overflow: hidden; text-align: right; }

.markdown-body span.align-right span img { margin: 0px; text-align: right; }

.markdown-body span.float-left { display: block; float: left; margin-right: 13px; overflow: hidden; }

.markdown-body span.float-left span { margin: 13px 0px 0px; }

.markdown-body span.float-right { display: block; float: right; margin-left: 13px; overflow: hidden; }

.markdown-body span.float-right > span { display: block; margin: 13px auto 0px; overflow: hidden; text-align: right; }

.markdown-body code, .markdown-body tt { background-color: rgba(27, 31, 35, 0.05); border-radius: 3px; font-size: 85%; margin: 0px; padding: 0.2em 0.4em; }

.markdown-body code br, .markdown-body tt br { display: none; }

.markdown-body del code { text-decoration: inherit; }

.markdown-body pre { overflow-wrap: normal; }

.markdown-body pre > code { background: transparent; border: 0px; font-size: 100%; margin: 0px; padding: 0px; white-space: pre; word-break: normal; }

.markdown-body .highlight { margin-bottom: 16px; }

.markdown-body .highlight pre { margin-bottom: 0px; word-break: normal; }

.markdown-body .highlight pre, .markdown-body pre { background-color: rgb(246, 248, 250); border-radius: 3px; font-size: 85%; line-height: 1.45; overflow: auto; padding: 16px; }

.markdown-body pre code, .markdown-body pre tt { background-color: initial; border: 0px; display: inline; line-height: inherit; margin: 0px; overflow: visible; padding: 0px; overflow-wrap: normal; }

.markdown-body .csv-data td, .markdown-body .csv-data th { font-size: 12px; line-height: 1; overflow: hidden; padding: 5px; text-align: left; white-space: nowrap; }

.markdown-body .csv-data .blob-num { background: rgb(255, 255, 255); border: 0px; padding: 10px 8px 9px; text-align: right; }

.markdown-body .csv-data tr { border-top: 0px; }

.markdown-body .csv-data th { background: rgb(246, 248, 250); border-top: 0px; font-weight: 600; }

.pl-c { color: rgb(106, 115, 125); }

.pl-c1, .pl-s .pl-v { color: rgb(0, 92, 197); }

.pl-e, .pl-en { color: rgb(111, 66, 193); }

.pl-s .pl-s1, .pl-smi { color: rgb(36, 41, 46); }

.pl-ent { color: rgb(34, 134, 58); }

.pl-k { color: rgb(215, 58, 73); }

.pl-pds, .pl-s, .pl-s .pl-pse .pl-s1, .pl-sr, .pl-sr .pl-cce, .pl-sr .pl-sra, .pl-sr .pl-sre { color: rgb(3, 47, 98); }

.pl-smw, .pl-v { color: rgb(227, 98, 9); }

.pl-bu { color: rgb(179, 29, 40); }

.pl-ii { background-color: rgb(179, 29, 40); color: rgb(250, 251, 252); }

.pl-c2 { background-color: rgb(215, 58, 73); color: rgb(250, 251, 252); }

.pl-c2::before { content: "^M"; }

.pl-sr .pl-cce { color: rgb(34, 134, 58); font-weight: 700; }

.pl-ml { color: rgb(115, 92, 15); }

.pl-mh, .pl-mh .pl-en, .pl-ms { color: rgb(0, 92, 197); font-weight: 700; }

.pl-mi { color: rgb(36, 41, 46); font-style: italic; }

.pl-mb { color: rgb(36, 41, 46); font-weight: 700; }

.pl-md { background-color: rgb(255, 238, 240); color: rgb(179, 29, 40); }

.pl-mi1 { background-color: rgb(240, 255, 244); color: rgb(34, 134, 58); }

.pl-mc { background-color: rgb(255, 235, 218); color: rgb(227, 98, 9); }

.pl-mi2 { background-color: rgb(0, 92, 197); color: rgb(246, 248, 250); }

.pl-mdr { color: rgb(111, 66, 193); font-weight: 700; }

.pl-ba { color: rgb(88, 96, 105); }

.pl-sg { color: rgb(149, 157, 165); }

.pl-corl { color: rgb(3, 47, 98); text-decoration: underline; }

.ajax-pagination-form .ajax-pagination-btn { background: rgb(255, 255, 255); border: 1px solid rgb(225, 228, 232); border-radius: 3px; color: rgb(3, 102, 214); font-weight: 600; margin-top: 20px; padding: 6px; width: 100%; }

.ajax-pagination-form .ajax-pagination-btn:focus, .ajax-pagination-form .ajax-pagination-btn:hover { background-color: rgb(246, 248, 250); }

.ajax-pagination-form.loading .ajax-pagination-btn { background-color: rgb(246, 248, 250); background-image: url("/images/spinners/octocat-spinner-16px-EAF2F5.gif"); background-position: 50% center; background-repeat: no-repeat; border-color: rgb(209, 213, 218); text-indent: -3000px; }

@media not all, only screen and (-webkit-min-device-pixel-ratio: 2), not all, not all, only screen and (min-resolution: 2dppx), only screen and (min-resolution: 192dpi) {
  .ajax-pagination-form.loading .ajax-pagination-btn { background-image: url("/images/spinners/octocat-spinner-32-EAF2F5.gif"); background-size: 16px; }
}

.Box--overlay { background-clip: padding-box; background-color: rgb(255, 255, 255); border-color: rgb(68, 77, 86); box-shadow: rgba(0, 0, 0, 0.4) 0px 0px 18px; margin-left: auto; margin-right: auto; width: 448px; }

.Box--overlay .Box-header { border-top-left-radius: 2px; border-top-right-radius: 2px; border-width: 0px 0px 1px; margin: 0px; }

.Box-overlay--narrow { width: 320px; }

.Box-overlay--wide { width: 640px; }

.Overlay { bottom: 0px; left: 0px; overflow-y: auto; position: fixed; right: 0px; top: 0px; z-index: 99; }

.bg-transparent-dark { background-color: rgba(0, 0, 0, 0.5); }

.transition-in-out { transition: opacity 0.2s ease-in-out 0s; }

.transition-in-out[hidden] { opacity: 0; }

.Box-body.scrollable-overlay { max-height: 400px; overflow-y: scroll; }

.Box-body .help { color: rgb(88, 96, 105); margin: 0px; padding-top: 8px; text-align: center; }

kbd { background-color: rgb(250, 251, 252); border-width: 1px; border-style: solid; border-color: rgb(209, 213, 218) rgb(209, 213, 218) rgb(198, 203, 209); border-image: initial; border-radius: 3px; box-shadow: rgb(198, 203, 209) 0px -1px 0px inset; color: rgb(68, 77, 86); display: inline-block; font: 11px/10px SFMono-Regular, Consolas, "Liberation Mono", Menlo, Courier, monospace; padding: 3px 5px; vertical-align: middle; }

.badmono { font-family: sans-serif; font-weight: 600; }

.diffstat { color: rgb(88, 96, 105); cursor: default; font-size: 12px; font-weight: 600; white-space: nowrap; }

.block-diff-added, .block-diff-deleted, .block-diff-neutral { display: inline-block; height: 8px; margin-left: 1px; width: 8px; }

.block-diff-deleted, .text-red .block-diff-neutral { background-color: rgb(203, 36, 49); }

.block-diff-added, .block-diff-neutral { background-color: rgb(44, 190, 78); }

.block-diff-neutral { background-color: rgb(209, 213, 218); }

.IssueLabel { border-radius: 2px; box-shadow: rgba(27, 31, 35, 0.12) 0px -1px 0px inset; font-size: 12px; font-weight: 600; height: 20px; line-height: 15px; padding: 0.15em 4px; }

.IssueLabel .g-emoji { display: inline-block; font-size: 1em; top: -0.05em; }

.IssueLabel:hover { text-decoration: none; }

.IssueLabel--big { border-radius: 3px; font-size: 16px; font-weight: 600; line-height: 2; padding: 0px 8px; transition: opacity 0.2s linear 0s; }

.IssueLabel--big .g-emoji { display: inline-block; margin-top: -1px; }

.IssueLabel--big:hover { opacity: 0.85; }

.details-overlay[open] > .dropdown-item:hover { background: rgb(255, 255, 255); color: inherit; }

details-menu { display: block; }

.progress-bar { background-color: rgb(234, 236, 239); border-radius: 3px; display: block; height: 15px; overflow: hidden; }

.progress-bar .progress { background-color: rgb(44, 190, 78); display: block; height: 100%; }

.reverse-progress-container { background-color: rgb(225, 228, 232); background-image: linear-gradient(90deg, rgb(40, 167, 69), rgb(0, 92, 197), rgb(58, 29, 110), rgb(203, 36, 49), rgb(246, 106, 10)); background-size: 100% 3px; height: 3px; position: relative; }

.reverse-progress-bar { background-color: rgb(225, 228, 232); height: 100%; position: absolute; right: 0px; }

.progress-bar-small { height: 10px; }

.progress-bar-inline .progress-bar { border-width: 0px 1px 1px; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-right-color: rgb(225, 228, 232); border-bottom-color: rgb(225, 228, 232); border-left-color: rgb(225, 228, 232); border-image: initial; border-radius: 0px; border-top-style: initial; border-top-color: initial; width: 100%; }

.Header { background-color: rgb(36, 41, 46); color: rgba(255, 255, 255, 0.75); padding-bottom: 12px; padding-top: 12px; z-index: 32; }

.server-stats + .Header { box-shadow: rgba(255, 255, 255, 0.075) 0px 1px 0px inset; }

.Header .header-search-scope { border-right-color: rgb(40, 46, 52); color: rgba(255, 255, 255, 0.75); font-size: inherit; line-height: 28px; }

.Header .header-search-wrapper { background-color: rgba(255, 255, 255, 0.125); border: 0px; box-shadow: none; color: rgb(255, 255, 255); font-size: inherit; min-height: 30px; }

.Header .header-search-wrapper .truncate-repo-scope { max-width: 110px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.Header .header-search-wrapper.focus { background-color: rgba(255, 255, 255, 0.176); box-shadow: none; }

.Header .header-search-wrapper.focus .header-search-scope { background-color: rgba(255, 255, 255, 0.075); border-right-color: rgb(40, 46, 52); color: rgb(255, 255, 255); }

.Header .header-search-input { color: inherit; font-size: 16px; min-height: 30px; }

@media (min-width: 1012px) {
  .Header .header-search-input { font-size: inherit; }
}

.Header .header-search-input::placeholder { color: rgba(255, 255, 255, 0.75); }

.Header .dropdown-menu { width: 300px; }

.Header .notification-indicator:hover::after { content: none; }

@media (min-width: 1012px) {
  .Header .notification-indicator:hover::after { content: attr(aria-label); }
}

.page-responsive .HeaderMenu { clear: both; display: none; }

@media (min-width: 1012px) {
  .page-responsive .HeaderMenu { clear: none; display: block; }
}

.page-responsive .HeaderMenu .header-search { border-top: 1px solid rgb(68, 77, 86); float: none; margin-right: 0px; max-width: none; padding-bottom: 16px; padding-top: 16px; width: auto; }

@media (min-width: 1012px) {
  .page-responsive .HeaderMenu .header-search { border-top: 0px; float: left; padding-bottom: 4px; padding-top: 4px; width: 300px; }
}

.open .HeaderMenu { display: block; }

.HeaderMenu .header-search { font-size: 13px; padding-bottom: 3px; padding-top: 3px; width: 300px; }

.read-only-mode-banner { background-color: rgb(248, 228, 95); border-bottom-color: rgb(246, 220, 46); text-align: center; }

.header-logo-invertocat { color: rgb(255, 255, 255); margin: -1px 15px -1px -2px; white-space: nowrap; }

.header-logo-invertocat .octicon-mark-github { float: left; }

.header-logo-invertocat:hover { color: rgb(255, 255, 255); text-decoration: none; }

.header-logo-subbrand { float: left; font-size: 16px; font-weight: 600; line-height: 30px; margin-left: 6px; }

.header-logo-wordmark { color: rgb(255, 255, 255); float: left; height: 26px; margin-right: 15px; position: relative; }

.header-logo-wordmark .octicon { float: left; }

.header-logo-wordmark:hover { color: rgb(255, 255, 255); }

.header-actions { float: right; margin-bottom: -3px; margin-top: -3px; }

.header-actions .btn { margin-left: 5px; }

.notification-indicator { color: rgba(255, 255, 255, 0.75); }

.notification-indicator .mail-status { background-clip: padding-box; background-image: linear-gradient(rgb(84, 163, 255), rgb(0, 110, 237)); border: 2px solid rgb(36, 41, 46); border-radius: 50%; color: rgb(255, 255, 255); display: none; height: 14px; left: 6px; position: absolute; top: -6px; width: 14px; z-index: 2; }

.notification-indicator .mail-status.unread { display: inline-block; }

.notification-indicator:hover .mail-status { background-color: rgb(3, 102, 214); text-decoration: none; }

.HeaderNavlink { color: rgb(255, 255, 255); display: block; }

.page-responsive .HeaderNavlink { border-top: 1px solid rgb(68, 77, 86); }

@media (min-width: 1012px) {
  .page-responsive .HeaderNavlink { border-top: 0px; }
}

.HeaderNavlink:focus, .HeaderNavlink:hover { color: rgba(255, 255, 255, 0.75); text-decoration: none; }

.HeaderNavlink:focus .dropdown-caret, .HeaderNavlink:hover .dropdown-caret { border-top-color: rgba(255, 255, 255, 0.75); }

.HeaderNavlink.selected { color: rgb(255, 255, 255); }

.HeaderNavlink.selected.js-menu-target { border-bottom-color: transparent; }

.HeaderNavlink.selected.tooltipped::after, .HeaderNavlink.selected.tooltipped::before { display: none; }

.user-nav .octicon { width: 16px; }

.user-nav .octicon-plus { margin-right: 1px; }

.user-nav .dropdown-menu { margin-top: 8px; width: 180px; }

.header-nav-current-user { font-size: inherit; padding-bottom: 0px; }

.header-nav-current-user .css-truncate-target { max-width: 100%; }

.header-nav-current-user .user-profile-link { color: rgb(36, 41, 46); }

.unsupported-browser { background-image: linear-gradient(rgb(254, 239, 174), rgb(250, 230, 146)); border-bottom: 1px solid rgb(179, 165, 105); color: rgb(33, 30, 20); }

.mobile-banner button.switch-to-mobile { background-color: rgb(68, 68, 68); border: 0px; color: rgb(234, 234, 234); display: block; font-size: 60px; font-weight: 600; padding: 30px 0px 45px; text-align: center; width: 100%; }

.header-search-wrapper { display: table; font-weight: 400; max-width: 100%; min-height: 0px; padding: 0px; vertical-align: middle; width: 100%; }

.header-search-wrapper.header-search-wrapper-jump-to .header-search-scope { width: fit-content; }

.header-search-input { background: none; display: table-cell; min-height: 26px; padding-bottom: 0px; padding-top: 0px; width: 100%; }

.header-search-input, .header-search-input:focus { border: 0px; box-shadow: none; }

.header-search-input:focus ~ .header-search-key-slash { display: none !important; }

.header-search-scope { border-bottom-left-radius: 3px; border-right: 1px solid rgb(234, 236, 239); border-top-left-radius: 3px; color: rgb(88, 96, 105); display: none; font-size: 12px; padding-left: 8px; padding-right: 8px; vertical-align: middle; white-space: nowrap; width: 1%; }

.header-search-scope:empty + .header-search-input { width: 100%; }

.header-search-scope:hover { background-color: rgba(255, 255, 255, 0.12); color: rgb(255, 255, 255); }

.scoped-search .header-search-scope { display: table-cell; }

.scoped-search .form-control.focus .header-search-scope { background-color: rgb(192, 221, 254); border-color: rgb(142, 194, 253); color: rgb(3, 102, 214); }

.jump-to-field-active { background-color: rgb(250, 251, 252); color: rgb(36, 41, 46) !important; }

.jump-to-field-active::placeholder { color: rgb(88, 96, 105) !important; }

.jump-to-field-active ~ .header-search-key-slash { display: none; }

.jump-to-field-active.jump-to-dropdown-visible { border-bottom-left-radius: 0px; border-bottom-right-radius: 0px; }

.jump-to-suggestions { border-radius: 0px 0px 3px 3px; box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 10px; left: 0px; top: 30px; width: 100%; z-index: 35; }

.jump-to-suggestions-path { color: rgb(27, 31, 35); min-height: 44px; min-width: 0px; }

.jump-to-suggestions-path .jump-to-octicon { color: rgb(106, 115, 125); width: 28px; }

.jump-to-suggestions-path .jump-to-suggestion-name { max-width: none; }

.jump-to-suggestions-path mark { background-color: initial; font-weight: 600; }

.jump-to-suggestions-results-container .navigation-item { border-bottom: 1px solid rgb(225, 228, 232); }

.jump-to-suggestions-results-container .navigation-item:last-child { border-bottom: 0px; }

.jump-to-suggestions-results-container .d-on-nav-focus { display: none; }

.jump-to-suggestions-results-container .navigation-focus .jump-to-octicon, .jump-to-suggestions-results-container [aria-selected="true"] .jump-to-octicon { color: rgb(255, 255, 255); }

.jump-to-suggestions-results-container .navigation-focus .jump-to-suggestions-path, .jump-to-suggestions-results-container [aria-selected="true"] .jump-to-suggestions-path { background: rgb(3, 102, 214); color: rgb(255, 255, 255); }

.jump-to-suggestions-results-container .navigation-focus mark, .jump-to-suggestions-results-container [aria-selected="true"] mark { color: rgb(255, 255, 255); }

.jump-to-suggestions-results-container .navigation-focus .d-on-nav-focus, .jump-to-suggestions-results-container [aria-selected="true"] .d-on-nav-focus { display: block; }

.tab-size[data-tab-size="1"] { tab-size: 1; }

.tab-size[data-tab-size="2"] { tab-size: 2; }

.tab-size[data-tab-size="3"] { tab-size: 3; }

.tab-size[data-tab-size="4"] { tab-size: 4; }

.tab-size[data-tab-size="5"] { tab-size: 5; }

.tab-size[data-tab-size="6"] { tab-size: 6; }

.tab-size[data-tab-size="7"] { tab-size: 7; }

.tab-size[data-tab-size="8"] { tab-size: 8; }

.tab-size[data-tab-size="9"] { tab-size: 9; }

.tab-size[data-tab-size="10"] { tab-size: 10; }

.tab-size[data-tab-size="11"] { tab-size: 11; }

.tab-size[data-tab-size="12"] { tab-size: 12; }

.task-list-item { list-style-type: none; }

.task-list-item label { font-weight: 400; }

.task-list-item.enabled label { cursor: pointer; }

.task-list-item + .task-list-item { margin-top: 3px; }

.task-list-item .handle { display: none; }

.task-list-item-checkbox { margin: 0px 0.2em 0.25em -1.6em; vertical-align: middle; }

.reorderable-task-lists .markdown-body .contains-task-list { padding: 0px; }

.reorderable-task-lists .markdown-body li:not(.task-list-item) { margin-left: 26px; }

.reorderable-task-lists .markdown-body ol:not(.contains-task-list) li, .reorderable-task-lists .markdown-body ul:not(.contains-task-list) li { margin-left: 0px; }

.reorderable-task-lists .markdown-body li p { margin-top: 0px; }

.reorderable-task-lists .markdown-body .task-list-item { border: 1px solid transparent; margin-left: -15px; margin-right: -15px; padding-left: 42px; padding-right: 15px; }

.reorderable-task-lists .markdown-body .task-list-item + .task-list-item { margin-top: 0px; }

.reorderable-task-lists .markdown-body .task-list-item .contains-task-list { padding-top: 4px; }

.reorderable-task-lists .markdown-body .task-list-item .handle { display: block; float: left; margin-left: -43px; opacity: 0; padding: 2px 0px 0px 2px; width: 20px; }

.reorderable-task-lists .markdown-body .task-list-item .drag-handle { fill: rgb(51, 51, 51); }

.reorderable-task-lists .markdown-body .task-list-item.hovered > .handle { opacity: 1; }

.reorderable-task-lists .markdown-body .task-list-item.is-dragging { opacity: 0; }

.review-comment-contents .markdown-body .task-list-item { border-bottom-left-radius: 3px; border-top-left-radius: 3px; margin-left: -12px; margin-right: -12px; padding-left: 42px; }

.review-comment-contents .markdown-body .task-list-item.hovered { border-left-color: rgb(237, 237, 237); }

#user-content-toc { overflow: visible; }

#user-content-toc tr { border-top: 0px; }

#user-content-toc td { background-color: rgb(247, 247, 247); border: 0px; border-radius: 3px; padding: 0px 20px; }

#user-content-toc ul { font-weight: 600; list-style: none; padding-left: 0px; }

#user-content-toc ul li { padding-left: 0.2em; }

#user-content-toc ul ul { font-weight: 400; }

#user-content-toc ul ul li::before { color: rgb(170, 170, 170); content: "⌞"; float: left; font-size: 1.2em; line-height: 1; margin-right: 0.2em; margin-top: -0.2em; }

#user-content-toc ul ul ul { padding-left: 0.9em; }

#user-content-toctitle h2 { border-bottom: 0px; font-size: 1.25em; margin-bottom: 0.5em; margin-top: 1em; }

* { box-sizing: border-box; }

html { font-size: 14px; text-size-adjust: 100%; }

body { background-color: rgb(250, 251, 252); color: rgb(36, 41, 46); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"; line-height: 1.4; margin: 0px; padding: 0px; width: 100%; }

button, input, textarea { font-family: inherit; font-size: inherit; line-height: inherit; margin: 0px; }

button { background: none; border: 0px; margin: 0px; padding: 0px; }

table { border-collapse: collapse; border-spacing: 0px; }

.container { margin: 0px 15px; }

a { color: rgb(3, 102, 214); text-decoration: none; }

a:active { color: inherit; }

strong { font-weight: 600; }

pre { white-space: pre-wrap; overflow-wrap: break-word; }

code, pre { font-family: Consolas, "Liberation Mono", Courier, monospace; }

hr { background: rgb(225, 228, 232); border-color: transparent; }

input[type="checkbox"][disabled] { opacity: 0.25; }

textarea[disabled]::-webkit-input-placeholder { color: rgb(0, 0, 0); }

.color-icons .octicon-comment-discussion { color: rgb(36, 41, 46); }

.color-icons .octicon-issue-closed { color: rgb(203, 36, 49); }

.color-icons .octicon-git-branch, .color-icons .octicon-git-pull-request, .color-icons .octicon-issue-opened { color: rgb(40, 167, 69); }

.color-icons .octicon-git-commit { color: rgb(88, 96, 105); }

.color-icons .opened { color: rgb(40, 167, 69); }

.color-icons .closed { color: rgb(203, 36, 49); }

.color-icons .merged { color: rgb(111, 66, 193); }

footer { border-top: 1px solid rgb(209, 213, 218); font-size: 14px; padding: 12px 0px; }

footer .octicon { color: rgb(163, 170, 177); float: left; }

footer ul { float: right; margin-bottom: 0px; margin-top: 0px; padding-left: 0px; }

footer li { color: rgb(149, 157, 165); float: left; line-height: 32px; list-style-type: none; }

footer li + li { margin-left: 15px; }

footer li a { color: inherit; }

footer form { display: inline; }

footer .switch-to-desktop { color: inherit; display: inline; }

.clearfix::after, .clearfix::before { content: ""; display: table; line-height: 0; }

.clearfix::after { clear: both; }

.protip { color: rgb(88, 96, 105); font-size: 13px; margin: 20px 0px; text-align: center; }

.details-reset > summary { list-style: none; }

.details-reset > summary::before { display: none; }

.details-reset > summary::-webkit-details-marker { display: none; }

details summary { cursor: pointer; }

details:not([open]) > :not(summary) { display: none !important; }

.details-dialog { left: 50%; margin: 10vh auto; position: fixed; top: 0px; transform: translateX(-50%); width: 90%; z-index: 999; }

.labels { display: block; position: relative; }

.IssueLabel, .label { font-size: 10px; height: 18px; line-height: 1.5; }

.IssueLabel .g-emoji { font-size: 1.1em; line-height: 1; position: relative; top: 0.1em; }

.switcher { padding: 15px 15px 15px 35px; position: relative; }

.switcher.open .switcher-icon-open { display: none; }

.switcher.open .switcher-icon-close, .switcher.open .switcher-options { display: block; }

.switcher-toggle { color: inherit; display: block; font-weight: 600; }

.switcher-toggle-meta { color: rgb(88, 96, 105); display: block; font-size: 85%; font-weight: 400; }

.switcher-options { display: none; padding-top: 6px; position: relative; }

.switcher-option { display: block; font-weight: 600; padding: 6px 0px; }

.switcher-option .octicon-check { left: -19px; position: absolute; }

.switcher-option .css-truncate-target { max-width: 80%; }

.switcher-icon { color: rgb(88, 96, 105); float: left; margin-left: -20px; margin-top: 1px; }

.switcher-icon-close, .switcher-icon-open { color: rgb(88, 96, 105); float: right; position: relative; top: 1px; }

.octicon.switcher-icon-close, .switcher-icon-close { display: none; }

.octicon.switcher-icon-open { display: block; }

.bubble { background: rgb(255, 255, 255); border: 1px solid rgb(209, 213, 218); border-radius: 3px; margin: 0px 15px 15px; overflow: hidden; padding: 0px; white-space: normal; word-break: break-word; overflow-wrap: break-word; }

.nav-bar + .bubble, .tabs + .bubble { margin-top: 15px; }

.bubble.padded { padding: 10px; }

.bubble.no-padding .bubble-content { padding: 0px; }

.bubble.no-margin { margin: 0px; }

.bubble-title { border-bottom: 1px solid rgb(209, 213, 218); color: rgb(47, 54, 61); display: block; font-size: 14px; margin: 0px; padding: 10px 15px; }

.bubble-title .octicon { color: rgb(88, 96, 105); margin-left: -3px; margin-right: 2px; text-align: center; width: 16px; }

.bubble-title time { color: rgb(88, 96, 105); float: right; font-size: 12px; font-weight: 400; line-height: 20px; }

.bubble-content { padding: 15px; }

.bubble-content .markdown-body { padding: 0px; }

.bubble-actions { display: table; table-layout: fixed; text-align: center; width: 100%; }

.bubble-content + .bubble-actions, .repo-list + .bubble-actions { border-top: 1px solid rgb(209, 213, 218); }

.bubble-action, .bubble-action-form { display: table-cell; }

.bubble-action { color: rgb(3, 102, 214); font-weight: 500; line-height: 1.5; padding: 10px 15px; }

.bubble-action + .bubble-action, .bubble-action + .bubble-action-form, .bubble-action-form + .bubble-action, .bubble-action-form + .bubble-action-form { border-left: 1px solid rgb(209, 213, 218); }

.bubble-disabled { background: rgb(246, 248, 250); border-color: rgb(209, 213, 218); box-shadow: rgba(27, 31, 35, 0.1) 0px 0px 10px inset; }

.bubble-disabled .bubble-title { color: rgb(88, 96, 105); }

.bubble-disabled .bubble-content { color: rgb(88, 96, 105); font-size: 15px; text-align: center; }

.bubble-disabled .bubble-content.full-bleed { padding: 15px; }

.bubble-disabled .bubble-action { color: rgb(88, 96, 105); }

ol ol, ul ol { list-style-type: lower-roman; }

ol ol ol, ol ul ol, ul ol ol, ul ul ol { list-style-type: lower-alpha; }

.list { background-color: rgb(255, 255, 255); list-style: none; margin: 0px; padding: 0px; }

.list:first-child .list-heading:first-child { border-top: 0px; }

.list .list-item-template, .list.list-rendered:empty { display: none; }

.list-item, .list.list-rendered .list-item-template { display: block; }

.list-item { line-height: inherit; overflow-wrap: break-word; padding: 14px 15px 14px 35px; position: relative; text-align: left; width: 100%; }

.list-heading + .list-item, .list-item + .list-heading, .list-item + .list-item { border-top: 1px solid rgb(234, 236, 239); }

.list-item.with-avatar { padding-left: 45px; }

.list-item.no-padding { padding-left: 15px; }

.list-item > .octicon { left: 12px; position: absolute; text-align: center; top: 14px; vertical-align: bottom; width: 16px; }

.list-item > .list-item-chevron { color: rgb(88, 96, 105); font-size: 20px; left: auto; margin-top: -10px; right: 15px; top: 50%; }

.list-item .avatar { border-radius: 2px; left: 15px; position: absolute; top: 14px; }

.list-item .meta { color: rgb(106, 115, 125); float: right; font-size: 11px; margin-bottom: 5px; margin-left: 5px; }

.list-item .meta ~ .list-item-title { margin-right: 55px; }

.list-item .meta .octicon-star { vertical-align: top; }

.list-item .nwo-link { color: rgb(88, 96, 105); display: block; font-size: 12px; font-weight: 600; margin-bottom: 2px; }

.list-item .ref { color: rgb(88, 96, 105); }

.list-item .byline { color: rgb(88, 96, 105); display: block; font-size: 12px; margin: 0px; }

.list-item .byline strong { color: rgb(68, 77, 86); font-weight: 400; }

.list-item .labels { margin-top: 2px; }

.list-item.read { background-color: rgb(250, 251, 252); }

.list-item.read .list-item-title, .list-item.read > .octicon { color: rgb(88, 96, 105); }

.list-item.read .list-action-archive { visibility: hidden; }

.list-item .filename { max-width: 100%; }

.list-item mark { background-color: inherit; color: inherit; font-weight: 600; }

.list-item-title { color: rgb(3, 102, 214); display: block; font-weight: 600; line-height: 1.2; margin-bottom: 3px; margin-right: auto; word-break: break-word; }

.list-heading { background-color: rgb(246, 248, 250); border-top: 1px solid rgb(234, 236, 239); clear: both; color: rgb(88, 96, 105); font-size: 12px; font-weight: 600; padding: 7px 15px; position: relative; }

.list-heading::after, .list-heading::before { content: ""; display: table; }

.list-heading::after { clear: both; }

.list-heading .btn-link, .list-heading a { color: inherit; }

.list-heading .btn-link > .octicon { opacity: 0.65; }

.list-heading .path-item { float: left; }

.list-action-form { margin-top: -10px; }

.list-action-form:last-child { margin-right: -10px; }

.list-action-form > .btn-link { color: rgb(198, 203, 209); padding: 10px; }

.list-action-form ~ .list-item-title { margin-right: 30px; }

.list-empty .list-item { color: rgb(88, 96, 105); font-weight: 600; padding: 45px; text-align: center; }

.list-options .list-item .list-item-title { color: rgb(88, 96, 105); }

.list-options .list-item > .octicon { color: rgb(255, 255, 255); }

.list-options .selected .list-item-title { color: rgb(36, 41, 46); }

.list-options .selected > .octicon { color: rgb(68, 77, 86); }

.repo-recommendation-list-item > .octicon { top: 35px; }

.repo-list-item .repo-name { margin-right: 32px; max-width: 80%; }

.repo-list .private { background-color: rgb(255, 253, 239); }

.repo-list .octicon { color: rgb(88, 96, 105); }

.repo-list .octicon-lock { color: rgba(27, 31, 35, 0.7); }

.repo-list .no-repo { color: rgb(88, 96, 105); padding: 15px; text-align: center; }

.files-list { overflow-wrap: break-word; }

.files-list + .files-list { border-top: 1px solid rgb(223, 226, 229); }

.files-list .meta { float: none; margin: 5px 0px 0px; }

.files-list .warning { background-color: rgb(255, 251, 221); font-weight: 600; }

.files-list .simplified-path { color: rgb(106, 115, 125); }

.files-list .octicon { color: rgba(3, 47, 98, 0.5); top: 16px; }

.user-list .follow-list-info { color: rgb(88, 96, 105); font-size: 12px; }

.bubble.auth-form-container { margin-bottom: 30px; margin-top: 30px; }

.bubble.auth-form-container label { display: block; margin: 0px 0px 5px; }

.bubble.auth-form-container .bubble-title { background-color: rgb(246, 248, 250); color: rgb(36, 41, 46); }

.bubble.auth-form-container p { margin: 0px; }

.bubble.auth-form-container .form-control { display: block; margin: 0px 0px 15px; width: 100%; }

.auth-form-message { padding: 10px; }

.login-heading { font-size: 13px; margin-bottom: 5px; }

.login-heading + p { margin-top: 0px; }

.login-note { font-size: 13px; padding: 0px 15px; position: relative; }

.login-note p { color: rgb(88, 96, 105); padding-left: 22.5px; }

.login-note.no-icon p { padding-left: 0px; }

.login-note .octicon { color: rgb(88, 96, 105); left: 15px; position: absolute; top: 0px; }

.login-note .btn { margin-bottom: 15px; }

.u2f-auth-form-body { display: block; padding: 10px 20px 20px; }

.u2f-auth-form-body.unavailable { display: none; }

.btn { -webkit-appearance: none; background-position: -1px -1px; background-repeat: repeat-x; background-size: 110% 110%; border: 1px solid rgba(27, 31, 35, 0.2); border-radius: 0.25em; display: inline-block; font-size: 13px; font-weight: 600; line-height: 1.5; margin: 0px; padding: 9px 15px; text-align: center; vertical-align: middle; white-space: nowrap; }

.btn:active { background-image: none; }

.btn.disabled, .btn:disabled { pointer-events: none; }

.btn .count { border-radius: 10px; color: rgba(0, 0, 0, 0.4); font-size: 11px; font-weight: 100; margin: 0px 0px 0px 3px; position: relative; text-shadow: none; }

.btn { background-color: rgb(239, 243, 246); background-image: linear-gradient(-180deg, rgb(250, 251, 252), rgb(239, 243, 246) 90%); color: rgb(36, 41, 46); }

.btn.focus, .btn:focus { box-shadow: rgba(3, 102, 214, 0.3) 0px 0px 0px 0.2em; }

.btn.hover, .btn:hover { background-color: rgb(230, 235, 241); background-image: linear-gradient(-180deg, rgb(240, 243, 246), rgb(230, 235, 241) 90%); background-position: -0.5em center; border-color: rgba(27, 31, 35, 0.35); }

.btn.selected, .btn:active, [open] > .btn { background-color: rgb(233, 236, 239); background-image: none; border-color: rgba(27, 31, 35, 0.35); box-shadow: rgba(27, 31, 35, 0.15) 0px 0.15em 0.3em inset; }

.btn.disabled, .btn:disabled { background-color: rgb(239, 243, 246); background-image: none; border-color: rgba(27, 31, 35, 0.2); box-shadow: none; color: rgba(36, 41, 46, 0.4); }

.btn-primary { background-color: rgb(40, 167, 69); background-image: linear-gradient(-180deg, rgb(52, 208, 88), rgb(40, 167, 69) 90%); color: rgb(255, 255, 255); }

.btn-primary.focus, .btn-primary:focus { box-shadow: rgba(52, 208, 88, 0.4) 0px 0px 0px 0.2em; }

.btn-primary.hover, .btn-primary:hover { background-color: rgb(38, 159, 66); background-image: linear-gradient(-180deg, rgb(47, 203, 83), rgb(38, 159, 66) 90%); background-position: -0.5em center; border-color: rgba(27, 31, 35, 0.5); }

.btn-primary.selected, .btn-primary:active, [open] > .btn-primary { background-color: rgb(39, 159, 67); background-image: none; border-color: rgba(27, 31, 35, 0.5); box-shadow: rgba(27, 31, 35, 0.15) 0px 0.15em 0.3em inset; }

.btn-primary.disabled, .btn-primary:disabled { background-color: rgb(148, 211, 162); background-image: none; border-color: rgba(27, 31, 35, 0.2); box-shadow: none; color: rgba(255, 255, 255, 0.75); }

.btn-primary .Counter { background-color: rgb(255, 255, 255); color: rgb(41, 178, 73); }

.btn-danger { background-color: rgb(250, 251, 252); background-image: linear-gradient(-180deg, rgb(250, 251, 252), rgb(239, 243, 246) 90%); color: rgb(203, 36, 49); }

.btn-danger:focus { box-shadow: rgba(203, 36, 49, 0.4) 0px 0px 0px 0.2em; }

.btn-danger:hover { background-color: rgb(203, 36, 49); background-image: linear-gradient(-180deg, rgb(222, 68, 80), rgb(203, 36, 49) 90%); border-color: rgba(27, 31, 35, 0.5); color: rgb(255, 255, 255); }

.btn-danger:hover .Counter { color: rgb(255, 255, 255); }

.btn-danger.selected, .btn-danger:active, [open] > .btn-danger { background-color: rgb(181, 32, 44); background-image: none; border-color: rgba(27, 31, 35, 0.5); box-shadow: rgba(27, 31, 35, 0.15) 0px 0.15em 0.3em inset; color: rgb(255, 255, 255); }

.btn-danger.disabled, .btn-danger:disabled { background-color: rgb(239, 243, 246); background-image: none; border-color: rgba(27, 31, 35, 0.2); box-shadow: none; color: rgba(203, 36, 49, 0.4); }

.btn-block { display: block; text-align: center; width: 100%; }

.btn-block + .btn-block { margin-top: 10px; }

.section-title button { background: transparent; border: 0px; box-shadow: none; color: rgb(88, 96, 105); float: right; font-size: 12px; margin: 0px; padding: 0px; }

.section-title button .octicon { color: rgb(88, 96, 105); }

.btn-link { -webkit-appearance: none; background-color: initial; border: 0px; color: rgb(3, 102, 214); cursor: pointer; display: inline; font-size: inherit; padding: 0px; user-select: none; white-space: nowrap; }

.mobile.commit { background-color: rgb(241, 248, 255); border-bottom: 1px solid rgba(27, 31, 35, 0.15); color: rgb(5, 38, 76); display: block; float: none; padding: 15px; width: 100%; }

.mobile.commit .commit-desc pre { font-size: 12px; margin: 0px; padding: 0px; }

.commit-title { font-size: 13px; font-weight: 600; margin: 0px 0px 5px; }

.commit-list .message { color: rgb(36, 41, 46); }

.commit-authorship { background-color: rgb(255, 255, 255); color: rgb(88, 96, 105); font-size: 12px; line-height: 24px; padding: 7.5px 15px; }

.commit-authorship .avatar { border-radius: 3px; float: left; margin-left: 15px; margin-right: 8px; }

.commit-authorship a { font-weight: 600; }

.diff-view + .js-comments-holder .blob-code-addition { background-color: rgb(230, 255, 237); }

.diff-view + .js-comments-holder .blob-code-addition .x { background-color: rgb(172, 242, 189); }

.diff-view + .js-comments-holder .blob-num-addition { background-color: rgb(205, 255, 216); border-color: rgb(190, 245, 203); }

.diff-view + .js-comments-holder .blob-code-deletion { background-color: rgb(255, 238, 240); }

.diff-view + .js-comments-holder .blob-code-deletion .x { background-color: rgb(253, 184, 192); }

.diff-view + .js-comments-holder .blob-num-deletion { background-color: rgb(255, 220, 224); border-color: rgb(253, 174, 183); }

.diff-view + .js-comments-holder span.no-nl-marker { color: rgb(203, 36, 49); margin-left: 4px; position: relative; top: 1px; vertical-align: middle; }

.diff-view .file { border-bottom: 1px solid rgb(209, 213, 218); border-top: 1px solid rgb(209, 213, 218); margin-bottom: 15px; position: relative; }

.diff-view .file:last-child:not(:only-child) { border-bottom: 0px; }

.diff-view .file .meta { background-image: linear-gradient(rgb(255, 255, 255), rgb(246, 248, 250)); border-bottom: 1px solid rgb(209, 213, 218); color: rgb(68, 77, 86); font-size: 12px; padding: 5px 10px 3px; text-align: left; text-shadow: rgb(255, 255, 255) 0px 1px 0px; }

.diff-view .file .meta .info { font-family: SFMono-Regular, Consolas, "Liberation Mono", Menlo, Courier, monospace; line-height: 1.2; padding: 6px 0px 6px 30px; position: relative; }

.diff-view .file .meta .file-label { border-left: 0px; box-shadow: transparent 0px 0px 0px inset; margin-left: 0px; padding-left: 0px; word-break: break-all; }

.diff-view .file .meta span.icon { background: rgb(246, 248, 250); border-color: rgb(198, 203, 209) rgb(225, 228, 232) rgb(225, 228, 232) rgb(198, 203, 209); border-radius: 3px; border-style: solid; border-width: 1px; display: inline-block; line-height: 0; margin: 5px 5px 0px 0px; padding: 3px; }

.diff-view .file .meta .octicon-file { color: rgb(163, 170, 177); }

.diff-view .file .file-label a { color: inherit; }

.diff-view .file .highlight { overflow: auto hidden; }

.diff-view .file .empty { color: rgb(68, 77, 86); font-family: SFMono-Regular, Consolas, "Liberation Mono", Menlo, Courier, monospace; font-size: 12px; line-height: 24px; padding: 5px 10px; }

.diff-view .file .file-code { background-color: rgb(255, 255, 255); border-collapse: initial; border-spacing: 0px; width: 100%; }

.diff-view .file .file-diff-line { cursor: pointer; position: relative; }

.diff-view .file .blob-num { color: rgba(27, 31, 35, 0.3); font-family: SFMono-Regular, Consolas, "Liberation Mono", Menlo, Courier, monospace; font-size: 12px; line-height: 18px; padding: 0px 3px; text-align: right; vertical-align: top; white-space: nowrap; width: 1%; }

.diff-view .file .blob-num::before { content: attr(data-line-number); }

.diff-view .file .blob-code { padding-left: 10px; padding-right: 10px; }

.diff-view .file .blob-code-inner { color: rgb(36, 41, 46); font-family: SFMono-Regular, Consolas, "Liberation Mono", Menlo, Courier, monospace; font-size: 12px; white-space: pre; }

.diff-view .file .blob-code-inner .x-first { border-bottom-left-radius: 0.2em; border-top-left-radius: 0.2em; }

.diff-view .file .blob-code-inner .x-last { border-bottom-right-radius: 0.2em; border-top-right-radius: 0.2em; }

.diff-view .file.soft-wrap .blob-code-inner { white-space: pre-wrap; overflow-wrap: break-word; }

.diff-view .file .prose .blob-code-inner { white-space: pre-wrap; }

.diff-view .file .blob-code-hunk { background-color: rgb(248, 245, 255); color: rgb(88, 96, 105); }

.diff-view .file .blob-num-hunk { background-color: rgb(245, 240, 255); border-color: rgb(242, 235, 255); }

.diff-view .file .blob-code-addition { background-color: rgb(230, 255, 237); }

.diff-view .file .blob-code-addition .x { background-color: rgb(172, 242, 189); }

.diff-view .file .blob-num-addition { background-color: rgb(205, 255, 216); border-color: rgb(190, 245, 203); }

.diff-view .file .blob-code-deletion { background-color: rgb(255, 238, 240); }

.diff-view .file .blob-code-deletion .x { background-color: rgb(253, 184, 192); }

.diff-view .file .blob-num-deletion { background-color: rgb(255, 220, 224); border-color: rgb(253, 174, 183); }

.diff-view .file span.no-nl-marker { color: rgb(203, 36, 49); margin-left: 4px; position: relative; top: 1px; vertical-align: middle; }

.diff-view .inline-comments { background-color: rgb(250, 251, 252); }

.diff-view table .discussion-block { border-right: 1px solid rgb(209, 213, 218); }

.diff-view .inline-comment-form-container { border-right: 1px solid rgb(209, 213, 218); width: 100vw; }

.add-inline-comment { cursor: pointer; }

.inline-comment-form { background-color: rgb(250, 251, 252); }

.inline-comment-form .inline-note-reply { background-color: initial; border-top: 0px; }

.inline-comment-form-container { padding: 15px; }

.inline-comment-form-container .discussion-reply { padding: 0px; }

.comment-holder + .inline-comment-form-container { padding-top: 0px; }

.inline-comment-form-container .inline-comment-form, .inline-comment-form-container.open .inline-comment-form-actions { display: none; }

.inline-comment-form-container .inline-comment-form-actions, .inline-comment-form-container.open .inline-comment-form { display: block; }

.resolvable-content { display: none; }

.open .resolvable-content { display: block; }

.line-comments { border-style: solid; border-color: rgb(223, 226, 229); border-image: initial; border-width: 1px 0px; padding: 0px; }

.inline-comments .discussion-block { max-width: 100vw; }

.inline-comments .bubble-content { padding-bottom: 10px; padding-top: 10px; }

.inline-comments .markdown-body { font-size: 85%; }

.inline-comments:last-child .line-comments { border-bottom: 0px; }

.timeline-inline-comments { overflow: hidden; width: 100%; }

.timeline-inline-comments .inline-comment-form-container:last-child { border-bottom: 1px solid rgb(223, 226, 229); }

.timeline-review-comment-thread .diff-view .file { margin-bottom: 0px; }

.inline-note-sign-in-container { font-size: 85%; padding: 15px; text-align: center; }

.inline-note-sign-in-container .btn { margin-bottom: 15px; }

.inline-comment-form-template-container { display: none; }

.diffstat { left: 0px; position: absolute; top: 4px; }

.highlighted-blob { white-space: pre-wrap; }

.mobile-toc { background-color: rgb(255, 255, 255); padding-left: 15px; }

.mobile-toc .switcher-options, .mobile-toc .switcher-toggle { padding-left: 20px; }

.mobile-toc.open .switcher-options { display: block; }

.mobile-toc .diffstat { position: static; }

.mobile-toc .switcher-option { font-size: 85%; font-weight: 400; }

.mobile-toc .switcher-option .octicon { color: rgb(198, 203, 209); float: left; margin-left: -20px; }

.mobile-toc .switcher-option .octicon-diff-removed { color: rgb(203, 36, 49); }

.mobile-toc .switcher-option .octicon-diff-renamed { color: rgb(106, 115, 125); }

.mobile-toc .switcher-option .octicon-diff-modified { color: rgb(227, 206, 121); }

.mobile-toc .switcher-option .octicon-diff-added { color: rgb(44, 190, 78); }

.add-comment-label, .is-review-pending .start-review-label, .review-cancel-button { display: none; }

.is-review-pending .add-comment-label, .is-review-pending .review-cancel-button, .is-review-pending .submit-review-button, .start-review-label { display: inline-block; }

.is-review-pending .submit-review-button { width: auto; }

.discussion-header { background: rgb(255, 255, 255); padding: 15px 15px 0px; }

.discussion-header .state { border-radius: 2px; font-size: 12px; line-height: 16px; }

.discussion-header .discussion-block-title { padding: 10px 0px 15px; }

.discussion-header .pull-request-description-toggle .pull-request-description { display: block; }

.discussion-header .pull-request-description-toggle.open .pull-request-description, .discussion-header .pull-request-description-toggle .pull-request-description-full { display: none; }

.discussion-header .pull-request-description-toggle.open .pull-request-description-full { display: block; }

.discussion-header .branches { color: rgb(149, 157, 165); cursor: pointer; font-size: 12px; margin: 0px; padding: 7.5px 0px; }

.discussion-header .branches .branch-name { color: rgb(88, 96, 105); display: inline-block; font-family: SFMono-Regular, Consolas, "Liberation Mono", Menlo, Courier, monospace; padding-left: 20px; position: relative; }

.discussion-header .branches .branch-name .octicon { left: 0px; position: absolute; top: 0px; }

.discussion-header .branches .octicon-git-branch { text-align: left; width: 16px; }

.discussion-header .branches .octicon-arrow-up { display: block; margin-left: 20px; width: 100%; }

.discussion-header .branches .css-truncate-target { max-width: 90%; }

.discussion-title { font-size: 16px; margin-bottom: 0px; overflow-wrap: break-word; }

.discussion-labels, .discussion-projects { background-color: rgb(255, 255, 255); padding: 15px 15px 0px; }

.discussion-labels .octicon, .discussion-projects .octicon { color: rgb(88, 96, 105); margin-right: 2px; position: relative; top: 2px; }

.discussion-starting-comment { position: relative; }

.discussion-starting-comment + .discussion-reply-container { margin-top: -1px; }

.discussion-starting-comment .avatar { border-radius: 2px; left: 15px; margin-right: 10px; position: absolute; }

.discussion-starting-comment time { color: rgb(88, 96, 105); margin: 0px 15px; }

.discussion-starting-comment .num, .discussion-starting-comment .username { color: rgb(88, 96, 105); }

.discussion-starting-comment .discussion-title .num { color: rgb(149, 157, 165); font-weight: 100; }

.discussion-starting-comment .discussion-block-title { padding-left: 60px; }

.discussion-comment { background: rgb(255, 255, 255); border-bottom: 1px solid rgb(223, 226, 229); padding: 15px; }

.commit-comments-header { font-size: 14px; padding: 0px 15px; }

.commit-comments-header-sha { font-weight: 400; }

.discussion-block-title { background-color: rgb(255, 255, 255); border-bottom: 1px solid rgb(225, 228, 232); color: rgb(88, 96, 105); font-size: 12px; line-height: 16px; padding: 10px 15px; position: relative; }

.discussion-block-title::before { content: ""; display: table; }

.discussion-block-title::after { clear: both; content: ""; display: table; }

.discussion-block-title .avatar { border-radius: 3px; float: left; margin-right: 10px; }

.discussion-block-title .timestamp { color: rgb(88, 96, 105); }

.discussion-block-title .username { color: rgb(68, 77, 86); font-weight: 600; }

.discussion-block-meta { margin-left: 42px; }

.discussion-block-meta .editor { color: rgb(68, 77, 86); }

.commit { float: left; margin: 0px 10px 0px 0px; }

.bubble.is-pending { border-color: rgb(217, 208, 165); }

.bubble.is-pending .discussion-block-title { background-color: rgb(255, 251, 221); border-color: rgb(217, 208, 165); }

.bubble .commit-message { color: rgb(68, 77, 86); margin: 0px; padding: 0px; white-space: pre-wrap; }

.discussion-block { padding: 15px; }

.discussion-block > .bubble { margin: 0px; }

.discussion-block-header { background-color: rgb(246, 248, 250); border-top: 1px solid rgb(223, 226, 229); color: rgb(88, 96, 105); font-size: 12px; font-weight: 600; padding: 25px 15px 7.5px; }

.discussion-event { padding: 15px; position: relative; }

.discussion-event .branch { color: rgb(68, 77, 86); font-weight: 600; vertical-align: middle; white-space: nowrap; }

.discussion-event .branch.css-truncate-target { max-width: 165px; }

.discussion-event .timestamp { color: inherit; }

.timeline-truncation-container { padding-left: 0px; padding-right: 0px; }

.timeline-truncation-container + .discussion-block { border-top: 1px solid rgb(225, 228, 232); padding-top: 15px; }

.timeline-truncation-container .switch-to-desktop { color: rgb(3, 102, 214); }

.timeline-truncation-title { color: rgb(88, 96, 105); font-weight: 600; margin-bottom: 5px; margin-top: 0px; }

.issue-event { color: rgb(88, 96, 105); font-size: 13px; padding-left: 40px; position: relative; }

.issue-event:last-of-type { border-bottom: 0px; }

.issue-event .avatar { left: 15px; position: absolute; top: 0px; }

.issue-event strong { color: rgb(68, 77, 86); }

.issue-event .meta { color: rgb(88, 96, 105); font-size: 12px; margin: 0.5em 0px 0px; }

.issue-event-icon { color: rgb(149, 157, 165); left: 15px; position: absolute; text-align: center; top: 16px; width: 16px; }

.issue-event-icon-open { color: rgb(40, 167, 69); }

.issue-event-icon-closed { color: rgb(203, 36, 49); }

.issue-event-icon-merged { color: rgb(111, 66, 193); }

.issue-event-icon-locked { color: rgb(36, 41, 46); }

.issue-event-icon-unlocked { color: rgb(40, 167, 69); }

.closed-event { border-bottom: 5px solid rgb(223, 226, 229); padding-bottom: 15px; }

.dead-pull-request-review-comment { color: rgb(88, 96, 105); display: block; font-size: 12px; margin: 0px 15px 15px; padding-left: 20px; position: relative; }

.dead-pull-request-review-comment .octicon { left: 0px; position: absolute; top: 0px; }

.dead-pull-request-review-comment .username { color: rgb(88, 96, 105); font-weight: 600; }

.timeline-review-comment-thread-container.dead .octicon { color: rgb(149, 157, 165); }

.timeline-review-comment-thread-container.dead.open .octicon-unfold, .timeline-review-comment-thread-container.dead.open .show-diff, .timeline-review-comment-thread-container.dead:not(.open) .hide-diff, .timeline-review-comment-thread-container.dead:not(.open) .octicon-fold, .timeline-review-comment-thread-container.dead:not(.open) .timeline-review-comment-thread { display: none; }

.cross-reference .bubble-title { background-color: rgb(246, 248, 250); border-bottom: 1px solid rgb(225, 228, 232); color: rgb(106, 115, 125); font-size: 12px; }

.cross-reference .bubble-title a { color: rgb(106, 115, 125); }

.cross-reference .bubble-title.private { background-color: rgb(255, 253, 239); background-image: none; padding-left: 30px; }

.cross-reference .bubble-title .octicon-lock { color: rgba(27, 31, 35, 0.7); float: left; margin-left: -20px; }

.cross-reference .bubble-content a { color: rgb(68, 77, 86); }

.timeline-commits-container { color: rgb(88, 96, 105); font-size: 12px; line-height: 16px; padding: 15px; }

.timeline-commits-container .octicon-repo-push { color: rgb(149, 157, 165); left: 1px; margin-right: 10px; position: absolute; top: 1px; }

.timeline-commits-container .author { color: rgb(88, 96, 105); font-weight: 600; }

.timeline-commits-container .timestamp { color: rgb(88, 96, 105); }

.timeline-commits-container .timeline-commits { margin-top: 7.5px; width: 100%; }

.timeline-commits-container .timeline-commits td { padding: 4px 0px; }

.timeline-commits-container .commit-message a { color: rgb(88, 96, 105); word-break: break-word; }

.commit-meta { text-align: right; width: 36px; }

.commit-meta a { color: rgb(149, 157, 165); }

.commit-meta .octicon { }

.commit-meta .octicon-x { color: rgb(203, 36, 49); }

.commit-meta .octicon-check { color: rgb(40, 167, 69); margin-left: 3px; }

.commits-header { padding-left: 25px; position: relative; }

.timeline-review-container .file-header { background-color: rgb(246, 248, 250); border-radius: 0px; border-top: 1px solid rgb(209, 213, 218); padding: 3px 10px 5px; }

.timeline-review-container .file-header:first-child { border-radius: 3px 3px 0px 0px; border-top: 0px; }

.timeline-review-container .file-info { font-family: SFMono-Regular, Consolas, "Liberation Mono", Menlo, Courier, monospace; font-size: 12px; }

.timeline-review-container .bubble { margin-top: 15px; }

.timeline-review-container .inline-comment-form { background-color: rgb(255, 255, 255); }

.timeline-review-container .inline-comment-form-container { padding: 10px 15px; }

.timeline-review-container.is-pending { border-color: rgb(217, 208, 165); }

.timeline-review-container.is-pending .file-header, .timeline-review-container.is-pending .label { background-color: rgb(255, 251, 221); color: rgb(115, 92, 15); }

.timeline-review-container.is-pending .bubble { border-color: rgb(217, 208, 165); }

.timeline-review-header { color: rgb(88, 96, 105); display: table; font-size: 12px; }

.timeline-review-icon { display: table-cell; vertical-align: top; width: 24px; }

.timeline-review-icon .octicon { color: rgb(106, 115, 125); margin-top: -1px; }

.timeline-review-icon .octicon-eye { margin-top: 0px; }

.timeline-review-icon .octicon-x { margin-left: 2px; margin-top: 0px; }

.timeline-review-icon .octicon-check { margin-left: 2px; }

.timeline-review-avatar { display: table-cell; padding-right: 5px; }

.timeline-review-meta { display: table-cell; vertical-align: top; }

.timeline-review-meta .author { color: rgb(88, 96, 105); }

.discussion-item-review-comment { border-bottom: 1px solid rgb(234, 236, 239); }

.discussion-item-review-comment:last-child { border-bottom: 0px; }

.outdated-comment .hide-outdated-button, .outdated-comment .timeline-review-comment-thread { display: none; }

.outdated-comment .file-header { border-bottom: 0px; border-bottom-left-radius: 3px; border-bottom-right-radius: 3px; }

.outdated-comment.open .hide-outdated-button, .outdated-comment.open .timeline-review-comment-thread { display: block; }

.outdated-comment.open .show-outdated-button { display: none; }

.outdated-comment.open .file-header { border-bottom-left-radius: 0px; border-bottom-right-radius: 0px; }

.outdated-comment-label { line-height: 22px; }

.team-mention, .user-mention { color: rgb(36, 41, 46); font-weight: 600; }

.discussion-create { margin: 15px 15px 0px; }

.discussion-create .form-control { margin-bottom: 8px; }

.discussion-create .btn { margin-bottom: 15px; margin-top: 7.5px; }

.discussion-block + .discussion-block, .discussion-block + .discussion-event, .discussion-block + .timeline-commits-container, .discussion-event + .discussion-block, .discussion-event + .discussion-event, .discussion-event + .timeline-commits-container, .timeline-commits-container + .discussion-block, .timeline-commits-container + .discussion-event, .timeline-commits-container + .timeline-commits-container { border-top: 1px solid rgb(225, 228, 232); }

.discussion-reply { background-color: rgb(255, 255, 255); border-top: 1px solid rgb(223, 226, 229); padding: 15px; text-align: right; }

.discussion-reply .btn { margin-top: 8px; }

.discussion-reply .btn + .btn { margin-left: 8px; }

.comment-sign-in-container { font-size: 13px; padding: 15px; text-align: center; }

.comment-sign-in-container .btn { margin: 0px 0px 15px; }

.thread-subscription-status { background-color: rgb(255, 255, 255); border-top: 1px solid rgb(223, 226, 229); padding: 15px; }

.thread-subscription-status .octicon-radio-tower { color: rgb(198, 203, 209); float: left; }

.thread-subscription-description { color: rgb(88, 96, 105); font-size: 13px; margin-top: 0px; min-height: 30px; padding-left: 42px; position: relative; }

.thread-subscription-description .octicon { left: 0px; position: absolute; }

.line-comment-info { border-bottom: 1px solid rgb(223, 226, 229); color: rgb(88, 96, 105); font-size: 12px; padding: 7.5px 15px; position: relative; }

.line-comment-info::after, .line-comment-info::before { content: ""; height: 0px; position: absolute; width: 0px; }

.line-comment-info::before { border-left: 8px solid transparent; border-right: 8px solid transparent; border-top: 8px solid rgb(223, 226, 229); bottom: -8px; left: 15px; z-index: 10; }

.line-comment-info::after { border-left: 7px solid transparent; border-right: 7px solid transparent; border-top: 7px solid rgb(255, 255, 255); bottom: -7px; left: 16px; z-index: 20; }

.comment-edit-form, .is-comment-editing .hide-when-editing { display: none; }

.is-comment-editing .comment-edit-form { display: block; }

.flash { background-color: rgb(219, 237, 255); border-bottom: 1px solid rgba(27, 31, 35, 0.15); color: rgb(3, 47, 98); font-size: 14px; font-weight: 600; padding: 15px; position: relative; }

.flash + .flash { margin-top: 5px; }

.flash .container { margin-left: 0px; margin-right: 0px; }

.flash .octicon-x { display: none; }

.flash .flash-action { float: right; margin-top: -5px; }

.flash.flash-warn { background-color: rgb(255, 251, 221); border-color: rgba(27, 31, 35, 0.15); color: rgb(115, 92, 15); }

.flash.flash-error { background-color: rgb(255, 220, 224); border-color: rgba(27, 31, 35, 0.15); color: rgb(134, 24, 29); }

.flash.flash-length-limited { max-height: 105px; overflow-y: scroll; }

.flash-messages.container { margin: 0px 0px 15px; }

.touchable { -webkit-tap-highlight-color: rgba(0, 0, 0, 0); }

.Header .octicon { color: rgba(255, 255, 255, 0.75); vertical-align: text-bottom; }

.nav-bar { background-color: rgb(36, 41, 46); color: rgba(255, 255, 255, 0.75); overflow: visible; position: relative; user-select: none; }

.nav-bar-inner { height: 55px; line-height: 55px; margin: 0px 2px; text-align: center; }

.nav-bar-inner .header-button { background: transparent; border: 0px; border-radius: 5px; color: inherit; line-height: 1; padding: 5px 8px; position: absolute; }

.nav-bar-inner .header-button:active, .nav-bar-inner .header-button:focus { box-shadow: none; outline: 0px; }

.nav-bar-inner .header-context-button { right: 8px; top: 8px; }

.nav-bar-inner .brand-logo-invertocat .octicon, .nav-bar-inner .brand-logo-wordmark .octicon { color: rgb(255, 255, 255); margin-top: -8px; vertical-align: text-top; }

.nav-bar-title-text { font-size: 14px; margin: 0px auto; max-width: 75%; overflow: hidden; position: relative; text-align: center; text-overflow: ellipsis; white-space: nowrap; }

.nav-bar-title-text .octicon { vertical-align: text-bottom; }

.nav-bar-meta { border-top: 1px solid rgb(223, 226, 229); font-size: 75%; padding: 7.5px 15px; text-align: center; }

.markdown-body { font-size: 15px; }

.markdown-body blockquote { margin-left: 0px; margin-right: 0px; }

.markdown-body code { white-space: normal; }

.markdown-body.email-format { line-height: 1.5em !important; }

.markdown-body.email-format div { white-space: pre-wrap; }

.markdown-body .email-hidden-reply { display: none; white-space: pre-wrap; }

.markdown-body .email-hidden-reply.expanded { display: block; }

.markdown-body .email-quoted-reply, .markdown-body .email-signature-reply { border-left: 4px solid rgb(223, 226, 229); color: rgb(88, 96, 105); margin-bottom: 15px; padding: 0px 15px; }

.breadcrumb { border-bottom: 1px solid rgb(223, 226, 229); color: rgb(88, 96, 105); font-size: 12px; padding: 15px; }

.breadcrumb .separator { margin: 0px 0.25em; }

.breadcrumb .octicon { margin-right: 5px; margin-top: -1px; }

.breadcrumb a { font-weight: 600; }

.breadcrumb strong { color: rgb(68, 77, 86); }

.tabs { display: table; table-layout: fixed; width: 100%; }

.tabs > a { border-bottom: 1px solid rgb(223, 226, 229); display: table-cell; font-size: 14px; font-weight: 600; padding: 10px 0px; text-align: center; }

.tabs > a.selected { background-color: rgb(255, 255, 255); border-bottom-color: rgb(255, 255, 255); border-left: 1px solid rgb(223, 226, 229); border-right: 1px solid rgb(223, 226, 229); color: rgb(68, 77, 86); }

.tabs > a:first-child { border-left: 0px; }

.tabs > a:last-child { border-right: 0px; }

.pagination { background-color: rgb(250, 251, 252); display: table; margin-bottom: -1px; margin-top: 0px; padding: 0px; position: relative; z-index: 2; }

.pagination a, .pagination em, .pagination span { border-width: 1px; border-style: solid; border-color: rgb(209, 213, 218) rgb(209, 213, 218) rgb(209, 213, 218) rgb(255, 255, 255); border-image: initial; color: rgb(68, 77, 86); display: table-cell; padding: 10px 15px; text-align: center; width: 1%; }

.pagination a:first-child, .pagination em:first-child, .pagination span:first-child { border-left: 0px; }

.pagination a:last-child, .pagination em:last-child, .pagination span:last-child { border-right: 0px; }

.pagination span > a { padding: 0px; }

.pagination .current { background-color: rgb(106, 115, 125); background-image: linear-gradient(rgb(106, 115, 125), rgb(149, 157, 165)); border-color: rgb(106, 115, 125); color: rgb(255, 255, 255); font-style: normal; font-weight: 600; }

.pagination .disabled, .pagination .gap { color: rgb(198, 203, 209); }

.oauth-permissions-details .content { display: none; }

.oauth-permissions-details.open .content { display: block; }

.oauth-permissions-details.default .default-access, .oauth-permissions-details.full .full-access { display: inline; }

.oauth-user-permissions .full-access, .oauth-user-permissions .limited-access, .oauth-user-permissions .limited-access-emails, .oauth-user-permissions .limited-access-emails-followers, .oauth-user-permissions .limited-access-emails-profile, .oauth-user-permissions .limited-access-followers, .oauth-user-permissions .limited-access-followers-profile, .oauth-user-permissions .limited-access-profile, .oauth-user-permissions .no-access { display: none; }

.oauth-user-permissions.limited.limited-email .limited-access-emails { display: inline; }

.oauth-user-permissions.limited.limited-email.limited-profile .limited-access-emails, .oauth-user-permissions.limited.limited-email.limited-profile .limited-access-profile { display: none; }

.oauth-user-permissions.limited.limited-email.limited-profile .limited-access-emails-profile { display: inline; }

.oauth-user-permissions.limited.limited-email.limited-profile.limited-follow .limited-access-emails, .oauth-user-permissions.limited.limited-email.limited-profile.limited-follow .limited-access-emails-followers, .oauth-user-permissions.limited.limited-email.limited-profile.limited-follow .limited-access-emails-profile, .oauth-user-permissions.limited.limited-email.limited-profile.limited-follow .limited-access-followers, .oauth-user-permissions.limited.limited-email.limited-profile.limited-follow .limited-access-followers-profile, .oauth-user-permissions.limited.limited-email.limited-profile.limited-follow .limited-access-profile { display: none; }

.oauth-user-permissions.limited.limited-email.limited-profile.limited-follow .limited-access { display: inline; }

.oauth-user-permissions.limited.limited-email.limited-follow .limited-access-emails, .oauth-user-permissions.limited.limited-email.limited-follow .limited-access-followers { display: none; }

.oauth-user-permissions.limited.limited-email.limited-follow .limited-access-emails-followers, .oauth-user-permissions.limited.limited-follow .limited-access-followers { display: inline; }

.oauth-user-permissions.limited.limited-follow.limited-profile .limited-access-followers, .oauth-user-permissions.limited.limited-follow.limited-profile .limited-access-profile { display: none; }

.oauth-user-permissions.limited.limited-follow.limited-profile .limited-access-followers-profile, .oauth-user-permissions.limited.limited-profile .limited-access-profile { display: inline; }

.oauth-repo-permissions .default-access, .oauth-repo-permissions .full-access, .oauth-repo-permissions .public-access { display: none; }

.oauth-repo-permissions.public .public-access { display: inline; }

.oauth-delete-repo-permissions .octicon-alert { color: rgb(203, 36, 49); }

.oauth-notifications-permissions .no-access, .oauth-notifications-permissions .read-access, .oauth-notifications-permissions .via-full-access, .oauth-notifications-permissions .via-public-access, .oauth-repo-status-permissions .full-access, .oauth-repo-status-permissions .no-access { display: none; }

.oauth-notifications-permissions.read .read-access, .oauth-notifications-permissions.via-public .via-public-access { display: inline; }

.oauth-notifications-permissions.via-public .octicon { display: none; }

.oauth-notifications-permissions.via-full .via-full-access { display: inline; }

.oauth-gist-permissions .full-access, .oauth-gist-permissions .no-access, .oauth-granular-permissions .full-access, .oauth-granular-permissions .no-access, .oauth-granular-permissions .read-access, .oauth-granular-permissions .write-access { display: none; }

.oauth-granular-permissions.full .full-access, .oauth-granular-permissions.none .no-access, .oauth-granular-permissions.read .read-access, .oauth-granular-permissions.write .write-access { display: inline; }

.issues-reset-query-wrapper { background-color: rgb(255, 255, 255); border-bottom: 1px solid rgb(225, 228, 232); padding: 15px; }

.subset-files-tab { background-color: rgb(241, 248, 255); }

.branch-action { background-color: rgb(255, 255, 255); border-top: 1px solid rgb(225, 228, 232); color: rgb(88, 96, 105); font-size: 12px; padding: 15px; }

.discussion-block-header + .branch-action { border-top-color: rgb(223, 226, 229); }

.branch-action-with-icon { padding-left: 35px; }

.branch-action-heading { color: rgb(36, 41, 46); font-size: 14px; margin-bottom: 0px; margin-top: 0px; }

.branch-action-icon { float: left; margin-left: -23px; text-align: center; width: 16px; }

.branch-action-expandable { border-top: 1px solid rgb(225, 228, 232); }

.discussion-block-header + .branch-action-expandable { border-top-color: rgb(223, 226, 229); }

.branch-action-expandable .list-item { padding-right: 40px; }

.branch-action-expandable .list-items-overflow { background-color: rgb(246, 248, 250); border-top: 1px solid rgb(225, 228, 232); font-size: 13px; max-height: 170px; overflow-y: auto; }

.branch-action-expandable .list-items-overflow .list-item { padding-bottom: 7px; padding-top: 7px; }

.branch-action-expandable .list-items-overflow .list-item-state-icon { top: 8px; }

.branch-action-expandable .list-items-overflow, .branch-action-expandable .octicon-fold { display: none; }

.branch-action-expandable.open .list-items-overflow, .branch-action-expandable.open .octicon-fold { display: block; }

.branch-action-expandable.open .octicon-unfold { display: none; }

.branch-action-expandable .list-item:first-child .list-item-chevron { font-size: 18px; margin-top: 2px; top: 14px; }

.branch-actions-details { margin-right: -25px; }

.merge-branch { position: relative; }

.merge-branch .is-loading .octicon { display: none; }

.merge-branch .is-loading .mergeable-state-loading { background-image: url("/images/spinners/octocat-spinner-16px.gif"); display: inline-block; height: 16px; width: 16px; }

.merge-branch .mergeable-state-message { color: rgb(88, 96, 105); font-size: 12px; margin-bottom: 0px; margin-top: 0px; }

.merge-branch .mergeable-state-message.required { color: rgb(88, 96, 105); display: block; }

.merge-branch .merge-branch-form, .merge-branch .mergeable-state-message { display: none; }

.merge-branch.open { border-top: 3px solid rgb(223, 226, 229); }

.merge-branch.open .merge-message, .merge-branch.open .octicon-git-pull-request { display: none; }

.merge-branch.mergeable-state-error .mergeable-state-message.error, .merge-branch.open.mergeable-state-blocked .mergeable-state-message.blocked, .merge-branch.open.mergeable-state-clean .merge-branch-form, .merge-branch.open.mergeable-state-dirty .mergeable-state-message.dirty, .merge-branch.open.mergeable-state-unstable .mergeable-state-message.unstable { display: block; }

.merge-commit-message { margin: 7.5px 0px; }

.merge-commit-title { font-weight: 600; }

.merge-form-author { color: rgb(88, 96, 105); font-size: 12px; line-height: 20px; margin-bottom: 15px; }

.merge-form-author .avatar { margin-right: 5px; }

.merge-options { color: rgb(36, 41, 46); margin-left: 0px; margin-right: 0px; }

.merge-options .list-item { padding-bottom: 10px; padding-top: 10px; }

.merge-options .byline { font-weight: 400; }

.merge-option-radio { left: 12px; margin-right: 3px; position: absolute; top: 12px; }

.merge-branch-form .btn-merge { display: block; }

.merge-branch-form .btn-rebase, .merge-branch-form .btn-squash, .merge-branch-form.is-squashing .btn-merge, .merge-branch-form.is-squashing .btn-rebase { display: none; }

.merge-branch-form.is-squashing .btn-squash { display: block; }

.merge-branch-form.is-rebasing .btn-merge, .merge-branch-form.is-rebasing .btn-squash, .merge-branch-form.is-rebasing .merge-commit-message, .merge-branch-form.is-rebasing .merge-commit-title { display: none; }

.merge-branch-form.is-rebasing .btn-rebase { display: block; }

.repository-meta { color: rgb(88, 96, 105); font-size: 13px; margin: 15px; }

.repository-meta-url { overflow-wrap: break-word; }

.branch-selector { font-weight: 600; padding-left: 19px; position: relative; }

.branch-selector .octicon.octicon-git-branch { left: 0px; position: absolute; top: 1px; }

.branch-selector .octicon.octicon-chevron-down, .branch-selector .octicon.octicon-chevron-up { float: right; margin-left: 0px; margin-right: 0px; position: relative; top: 1px; width: auto; }

.branch-selector:not([open]) .octicon.octicon-chevron-up, .branch-selector[open] .octicon.octicon-chevron-down { display: none; }

.branch-selector-options { font-size: 13px; font-weight: 400; padding-top: 6px; position: relative; }

.branch-selector-option { display: block; font-size: 14px; font-weight: 600; padding: 6px 0px; }

.branch-selector-option .octicon-check { left: -19px; position: absolute; }

.branch-selector-all-branches { display: block; padding: 6px 0px; }

.latest-commit .commit-author { background: rgb(255, 255, 255); color: rgb(88, 96, 105); font-size: 12px; line-height: 20px; padding-bottom: 8px; padding-top: 8px; position: relative; }

.latest-commit .bubble-content strong { color: rgb(68, 77, 86); }

.pulse-control { font-size: 11px; padding: 15px; text-align: right; }

.pulse-summary { margin: 0px 0px 30px; }

.pulse-summary:last-of-type { margin-bottom: 0px; }

.pulse-summary .summary-title { font-size: 14px; margin: 0px 0px 5px; padding: 0px; }

.pulse-summary .bar-graph { border-radius: 3px; display: table; margin: 0px; width: 100%; }

.pulse-summary .bar { background-color: rgb(106, 115, 125); display: table-cell; height: 15px; }

.pulse-summary .bar.closed { background-color: rgb(203, 36, 49); }

.pulse-summary .bar.open { background-color: rgb(40, 167, 69); }

.pulse-summary .bar.merged { background-color: rgb(111, 66, 193); }

.pulse-summary .bar.proposed { background-color: rgb(40, 167, 69); }

.pulse-summary .summary-box { border: 1px solid rgb(234, 236, 239); color: rgb(88, 96, 105); display: table; margin: 0px; padding: 0px; width: 100%; }

.pulse-summary .summary-box li { display: table-cell; padding: 15px 0px; text-align: center; width: 50%; }

.pulse-summary .summary-box li:first-child { border-right: 1px solid rgb(234, 236, 239); }

.pulse-summary .summary-box .count { color: rgb(68, 77, 86); display: block; font-size: 16px; }

.pulse-summary .summary-box .count .octicon { margin-top: 2px; }

.user-bar-graph { background: rgb(255, 255, 255); height: 103px; position: relative; }

.max-commits { color: rgb(88, 96, 105); font-size: 10px; position: absolute; right: 15px; top: 3px; }

.user-bar-item { float: left; height: 75px; margin: 0px 5px 5px 0px; position: relative; width: 20px; }

.user-bar-item img { border-bottom-left-radius: 3px; border-bottom-right-radius: 3px; bottom: -28px; margin-right: 5px; position: absolute; }

.user-bar { background-color: rgb(251, 133, 50); border-top-left-radius: 3px; border-top-right-radius: 3px; bottom: 0px; color: rgb(36, 41, 46); font-size: 12px; margin: 0px; max-height: 75px; opacity: 0.8; padding: 0px 0px 3px; position: absolute; width: 20px; }

.y-axis-bar { background: rgb(246, 248, 250); height: 1px; left: 0px; position: absolute; width: 100%; }

.y-axis-bar.top { top: 0px; }

.y-axis-bar.middle { top: 36px; }

.y-axis-bar.bottom { border-color: rgb(198, 203, 209); bottom: 27px; }

.bar-graph { height: 30px; margin: 15px 0px; padding: 0px; }

.bar-graph a { display: block; float: left; height: 10px; margin: 0px; padding: 0px; position: relative; }

.bar-graph a .label { bottom: -23px; color: rgb(88, 96, 105); font-size: 13px; position: absolute; }

.bar-graph a:first-child { border-bottom-left-radius: 2px; border-top-left-radius: 2px; }

.bar-graph a:first-child .label { left: 0px; }

.bar-graph a:last-child { border-bottom-right-radius: 2px; border-top-right-radius: 2px; }

.bar-graph a:last-child .label { right: 0px; }

.file-browser-header { border-bottom: 1px solid rgb(223, 226, 229); max-width: 100%; }

.file-browser-header > .TableObject-item { padding: 15px; }

.file-browser-header > .TableObject-item:first-child { border-right: 1px solid rgb(223, 226, 229); white-space: normal; }

.file-browser-header .octicon { color: rgb(88, 96, 105); }

.history-link { color: rgb(88, 96, 105); font-size: 12px; font-weight: 600; margin-top: 4px; vertical-align: top; }

p.history-link { border-bottom: 1px solid rgb(223, 226, 229); font-size: 13px; margin: 0px; padding: 15px; }

p.history-link a { color: rgb(88, 96, 105); }

.blob-breadcrumb { padding-left: 40px; position: relative; }

.blob-breadcrumb .filetype-icon { left: 15px; position: absolute; top: 15px; }

.blob-history { background: rgb(246, 248, 250); border-bottom: 1px solid rgb(209, 213, 218); color: rgb(106, 115, 125); display: none; position: relative; }

.blob-history a { color: rgb(3, 102, 214); display: block; font-size: 13px; padding: 15px 15px 15px 41px; }

.blob-history .octicon { color: rgb(106, 115, 125); }

.blob-history .octicon-history { left: 15px; position: absolute; top: 16px; }

.blob-history .commit-ref { color: rgb(106, 115, 125); float: right; font-family: SFMono-Regular, Consolas, "Liberation Mono", Menlo, Courier, monospace; font-size: 12px; font-weight: 600; margin: 2px 0px 0px 10px; }

.blob-history-label { color: rgb(3, 102, 214); float: right; }

.blob-history-checkbox { left: 0px; opacity: 0; position: absolute; top: 0px; }

.blob-history-checkbox:checked ~ .blob-history { display: block; }

.blob-file-content { background-color: rgb(255, 255, 255); }

.blob-file-content pre { margin: 0px; overflow: scroll; white-space: pre; overflow-wrap: normal; }

.blob-file-content .code-body pre { padding: 15px 0px; }

.blob-file-content .code-body pre .line { padding: 0px 15px; }

.blob-file-content-blankslate { margin-bottom: 0px; margin-top: 0px; padding: 15px; }

.blob-code-inner { font-family: Consolas, "Liberation Mono", Courier, monospace; font-size: 14px; line-height: 1.4; overflow: scroll; white-space: pre; overflow-wrap: normal; }

.markdown-body { padding: 15px; }

.subscription-settings-bubble .bubble-content { padding: 0px 15px; }

.reponav-wrapper { background-color: rgb(36, 41, 46); margin-top: -1px; overflow-y: hidden; padding-top: 1px; position: relative; z-index: 2; }

.reponav { overflow-x: auto; padding-left: 8px; padding-right: 8px; text-align: center; white-space: nowrap; }

.reponav, .reponav-item { color: rgba(255, 255, 255, 0.75); }

.reponav-item { display: inline-block; padding: 4px 8px 16px; }

.reponav-item .Counter { background-color: rgba(255, 255, 255, 0.15); color: inherit; }

.reponav-item.selected { color: rgb(255, 255, 255); font-weight: 600; }

.server-stats { background: rgb(36, 41, 46); color: rgb(88, 96, 105); }

.server-stats .stats { margin: 0px; padding-left: 0px; }

.server-stats .stats li { border-bottom: 1px solid rgba(27, 31, 35, 0.7); box-shadow: rgba(255, 255, 255, 0.1) 0px 1px 0px; list-style: none; padding: 15px; }

.server-stats a, .server-stats strong { color: rgb(255, 255, 255); font-weight: 600; }

.server-stats .serverstats-branch { font-family: SFMono-Regular, Consolas, "Liberation Mono", Menlo, Courier, monospace; margin: 0px; padding: 15px; }

.server-stats .serverstats-branch .current-branch { max-width: 90%; }

.octicon { display: inline-block; fill: currentcolor; vertical-align: text-top; }

.profile-header { line-height: 1.5; min-height: 140px; overflow: visible; padding: 15px 15px 10px 140px; position: relative; }

.profile-header .avatar { border-radius: 3px; left: 15px; margin-right: 15px; position: absolute; top: 15px; }

.profile-header h1 { color: rgb(36, 41, 46); font-size: 16px; margin: 0px; }

.profile-header h3 { color: rgb(88, 96, 105); font-size: 12px; font-weight: 400; margin: 0px; }

.user-profile-bio { padding: 0px 15px 15px; white-space: pre-wrap; }

.user-profile-company > div { display: inline-block; }

.details { margin: 7.5px 0px 0px; padding: 0px; }

.details li { font-size: 12px; line-height: 1.8; margin-bottom: 0px; }

.details-item { font-size: 13px; line-height: 24px; list-style: none; }

.details-item .css-truncate-target { max-width: 88%; }

.details-item .octicon { color: rgb(88, 96, 105); text-align: center; width: 16px; }

.user-following-container { display: block; padding: 0px 15px 15px; }

.user-following-container.loading { opacity: 0.5; }

.user-following-container .follow, .user-following-container.on .unfollow { display: block; }

.user-following-container.on .follow, .user-following-container .unfollow { display: none; }

.language-color { border-radius: 50%; display: inline-block; height: 12px; position: relative; top: 1px; width: 12px; }

.profile-timeline-wrapper { background-color: rgb(255, 255, 255); overflow: hidden; position: relative; white-space: normal; word-break: break-word; overflow-wrap: break-word; z-index: 0; }

.profile-timeline-wrapper .form-select { width: 116px; }

.profile-timeline .closed.octicon, .profile-timeline .reverted.octicon { color: rgb(203, 36, 49); }

.profile-timeline .open.octicon { color: rgb(40, 167, 69); }

.profile-timeline .merged.octicon { color: rgb(111, 66, 193); }

.profile-timeline .timeline-item-icon { background-color: rgb(246, 248, 250); border: 2px solid rgb(255, 255, 255); border-radius: 50%; color: rgb(88, 96, 105); float: left; height: 32px; line-height: 29px; margin-left: -40px; margin-top: -7px; text-align: center; width: 32px; }

.profile-timeline .profile-timeline-month-line { background-color: rgb(255, 255, 255); }

.profile-timeline .profile-timeline-month-line .profile-timeline-month-heading { top: -10px; }

.profile-timeline .profile-timeline-month-line::after { background-color: rgb(246, 248, 250); content: ""; display: block; height: 1px; margin-top: -4px; width: 100%; }

.profile-timeline .profile-timeline-line::before { background-color: rgb(246, 248, 250); bottom: 0px; content: ""; display: block; left: 15px; position: absolute; top: 0px; width: 2px; z-index: -1; }

.profile-timeline .profile-timeline-card-wrapper { border-bottom: 2px solid rgb(255, 255, 255); border-top: 2px solid rgb(255, 255, 255); }

.profile-timeline .profile-timeline-card-wrapper h4 { margin: 0px; }

.profile-timeline .progress-bar { border-radius: 2px; height: 10px; }

.profile-timeline .col-5 { width: 30%; }

.profile-rollup-wrapper .css-truncate-target { max-width: 72%; }

.profile-rollup-icon .octicon { vertical-align: middle; }

.profile-rollup-event-title.css-truncate-target { max-width: 100%; }

.profile-rollup-wrapper + .profile-rollup-wrapper { border-top: 1px solid rgb(246, 248, 250); }

.profile-timeline-card-wrapper + .profile-timeline-card-wrapper { margin-top: 8px; }

.profile-rollup-wrapper + .profile-timeline-card-wrapper { margin-top: 0px; }

.profile-timeline-month-line + .profile-timeline-card-wrapper { margin-top: 8px; }

.profile-rollup-content { display: none; }

.profile-rollup-toggle .css-truncate-target { max-width: 90%; }

.profile-rollup-toggle-closed { display: none; }

.profile-rollup-toggle-open { display: inline-block; }

.open .profile-rollup-content, .open .profile-rollup-toggle-closed { display: block; }

.open .btn-link .profile-rollup-toggle-closed { display: inline-block; }

.open .profile-rollup-toggle-open { display: none; }

.inbox-unavailable, .inbox-zero { background-color: rgb(255, 255, 255); border-top: 1px solid rgb(225, 228, 232); color: rgb(88, 96, 105); padding: 30px 15px; text-align: center; }

.subscription-settings-bubble .form-checkbox { padding: 0px 15px 0px 40px; }

.subscription-settings-bubble .form-checkbox input[type="radio"] { position: relative; top: 2px; }

.subscription-settings-bubble .form-checkbox .note { padding-left: 0px; }

.dashboard-search { padding: 15px; }

.topic-tag { background-color: rgb(231, 243, 255); border-radius: 3px; display: inline-block; margin: 0.25em 0.5em 0.25em 0px; padding: 0.3em 0.9em; }

.branch-groups { background-color: rgb(255, 255, 255); padding-top: 15px; }

.branch-groups .bubble-title { background-color: rgb(246, 248, 250); }

.branches-list { border-bottom: 1px solid rgb(209, 213, 218); }

.branches-list:last-child { border-bottom: 0px; }

.branches-list .branch-name { background-color: rgb(234, 245, 255); border-radius: 3px; color: rgba(27, 31, 35, 0.6); display: inline-block; font: 12px SFMono-Regular, Consolas, "Liberation Mono", Menlo, Courier, monospace; margin-left: 15px; padding: 2px 6px; }

.branches-list .branch-name .octicon { color: rgb(168, 187, 208); margin: 1px -2px 0px 0px; }

.branches-list a.branch-name { color: rgb(3, 102, 214); }

.branch-list-item .branch-name { margin-right: 10px; max-width: 80%; }

.branch-list-item .meta { margin-top: 3px; }

.branch-list-item .branch-meta { color: rgb(88, 96, 105); display: block; font-size: 12px; margin-left: 0px; margin-top: 3px; }

.gist-mobile-blob { border-top: 1px solid rgb(223, 226, 229); }

.gist-meta { margin-top: 15px; }

.annotation-block { max-width: 100vw; }

.check-annotation { border-bottom-left-radius: 0px; border-top-left-radius: 0px; }

.check-annotation::after { bottom: -1px; content: " "; display: block; left: 0px; position: absolute; top: -1px; width: 4px; }

.check-annotation .annotation-octicon { width: 16px; }

.check-annotation.Details--on .Details-content--hidden { display: block !important; }

.annotation-title { overflow-wrap: break-word; }

.check-annotation-failure::after { background-color: rgb(215, 58, 73); }

.check-annotation-failure .annotation-title { color: rgb(215, 58, 73); }

.check-annotation-warning::after { background-color: rgb(246, 106, 10); }

.check-annotation-warning .annotation-title { color: rgb(246, 106, 10); }

.check-annotation-notice::after { background-color: rgb(106, 115, 125); }

.check-annotation-notice .annotation-title { color: rgb(106, 115, 125); }

.render-container { background: rgb(223, 226, 229); line-height: 0; padding: 30px; text-align: center; }

.render-container .render-viewer { border: 0px; display: none; height: 100%; width: 100%; }

.render-container .octospinner, .render-container .render-fullscreen, .render-container .render-viewer-error, .render-container .render-viewer-fatal, .render-container .render-viewer-invalid { display: none; }

.render-container.is-render-automatic .octospinner, .render-container.is-render-requested.is-render-failed .render-viewer-error, .render-container.is-render-requested .octospinner { display: inline-block; }

.render-container.is-render-requested.is-render-failed .octospinner, .render-container.is-render-requested.is-render-failed .render-viewer, .render-container.is-render-requested.is-render-failed .render-viewer-fatal, .render-container.is-render-requested.is-render-failed .render-viewer-invalid { display: none; }

.render-container.is-render-requested.is-render-failed-fatal .render-viewer-fatal { display: inline-block; }

.render-container.is-render-requested.is-render-failed-fatal .octospinner, .render-container.is-render-requested.is-render-failed-fatal .render-viewer, .render-container.is-render-requested.is-render-failed-fatal .render-viewer-error, .render-container.is-render-requested.is-render-failed-fatal .render-viewer-invalid { display: none; }

.render-container.is-render-requested.is-render-failed-invalid .render-viewer-invalid { display: inline-block; }

.render-container.is-render-requested.is-render-failed-invalid .octospinner, .render-container.is-render-requested.is-render-failed-invalid .render-viewer, .render-container.is-render-requested.is-render-failed-invalid .render-viewer-error, .render-container.is-render-requested.is-render-failed-invalid .render-viewer-fatal { display: none; }

.render-container.is-render-ready.is-render-requested:not(.is-render-failed) { background: none; height: 500px; padding: 0px; }

.render-container.is-render-ready.is-render-requested:not(.is-render-failed) .render-viewer { display: block; }

.render-container.is-render-ready.is-render-requested:not(.is-render-failed) .render-fullscreen { display: flex; }

.render-container.is-render-ready.is-render-requested:not(.is-render-failed) .octospinner, .render-container.is-render-ready.is-render-requested:not(.is-render-failed) .render-viewer-error, .render-container.is-render-ready.is-render-requested:not(.is-render-failed) .render-viewer-fatal { display: none; }

.render-notice { background-color: rgb(246, 248, 250); border-color: rgba(27, 31, 35, 0.15); color: rgb(68, 77, 86); font-size: 14px; padding: 20px 15px; }
------MultipartBoundary--kTQgBUfc6f4BLSFiT9rvMhqXUu6noRxQRXYfZgCqVt----
Content-Type: image/png
Content-Transfer-Encoding: binary
Content-Location: https://avatars1.githubusercontent.com/u/44693518?s=40&v=4

�PNG

   IHDR  �  �   �.�b  �IDATx������@ F��C�F˰F���,��{N��9���qc� �t?g x��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	��/v���	�>{�+y�	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	�㙓��z� �]�m�/; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A쀄e�1{����H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A쀄�����z���>{�WrG�?w�ϼ���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A쀄u��w;�k�����2Ƙ��>�+:�}������o,� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$����1fo �v^v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@¯   ��ˇ*�e�`�    IEND�B`�
------MultipartBoundary--kTQgBUfc6f4BLSFiT9rvMhqXUu6noRxQRXYfZgCqVt------
